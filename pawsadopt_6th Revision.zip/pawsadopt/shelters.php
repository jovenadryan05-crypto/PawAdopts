<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Shelters'; $page = 'shelterdir';
// Public directory + transparency numbers for every verified shelter.
$search = trim($_GET['q'] ?? '');
$where = "s.verification_status = 'approved' AND s.account_status = 'active'"; $args = [];
if ($search !== '') { $where .= ' AND (s.shelter_name LIKE ? OR s.city LIKE ? OR s.province LIKE ?)'; array_push($args, "%$search%", "%$search%", "%$search%"); }
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM shelters s WHERE $where", $args)->fetchColumn(), 12);
$rows = q("SELECT s.* FROM shelters s WHERE $where ORDER BY s.shelter_name LIMIT 12 OFFSET $off", $args)->fetchAll();
$stats = shelter_stats(array_column($rows, 'shelter_id'));
include __DIR__ . '/includes/header.php';
?>
<h1>Verified shelters</h1>
<p class="muted">Every shelter here was checked by a PawsAdopt administrator. The numbers are counted automatically from real adoptions, so you can compare shelters before you reach out.</p>
<form class="filters" method="get"><label class="grow">Search<input type="search" name="q" value="<?= e($search) ?>" placeholder="Shelter name, city or province"></label><button class="btn">Search</button><?php if ($search !== ''): ?><a class="btn btn-ghost" href="<?= url('shelters.php') ?>">Clear</a><?php endif; ?></form>
<?php if (!$rows): ?><div class="empty"><h2>No shelters found</h2></div><?php endif; ?>
<div class="shelter-grid">
<?php foreach ($rows as $s): $t = $stats[(int)$s['shelter_id']] ?? null; ?>
  <a class="card shelter-card" href="<?= url('shelter.php?id=' . $s['shelter_id']) ?>">
    <div class="card-body"><div class="who"><?= shelter_logo($s) ?><div><h3><?= e($s['shelter_name']) ?></h3><p class="muted small"><?= e(trim(($s['city'] ?? '') . ', ' . ($s['province'] ?? ''), ', ')) ?></p></div></div>
    <?php if ($t): ?><dl class="mini-stats"><div><dt>Adopted in <?= date('Y') ?></dt><dd><?= (int)$t['adopted_year'] ?></dd></div><div><dt>Waiting now</dt><dd><?= (int)$t['waiting'] ?></dd></div><div><dt>Avg. days to adoption</dt><dd><?= $t['avg_days'] === null ? '-' : (int)$t['avg_days'] ?></dd></div></dl><?php endif; ?></div>
  </a>
<?php endforeach; ?>
</div>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
