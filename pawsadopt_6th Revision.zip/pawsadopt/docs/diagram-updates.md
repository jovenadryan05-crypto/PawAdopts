# Diagram updates for batches 1 to 4

Your submitted diagrams (6 tables, 15 use cases, DFD D1 to D6) describe the original scope. These additions bring them in line with the system you now have.
Use whichever you need; the **business** additions (D7, UC-16/17) are the ones your instructor will care about. The support tables are infrastructure.

## 1. ERD (Mermaid) - new entity and relationships
```mermaid
erDiagram
    ADOPTION_INQUIRIES ||--o{ INQUIRY_MESSAGES : "has"
    USERS ||--o{ INQUIRY_MESSAGES : "sends"
    INQUIRY_MESSAGES {
        int message_id PK
        int inquiry_id FK
        int sender_id FK
        varchar body
        datetime created_at
        datetime read_at "NULL until the other side reads it"
    }
```
**Columns to add to existing entities**
- USERS: `varchar profile_photo`, `varchar bio`, `varchar city`, `varchar position` (staff job title), `enum housing_type`, `varchar other_pets`, `enum pet_experience`, `datetime consent_at`, `varchar terms_version`, `tinyint must_change_password`, `int session_version`. `account_status` now also allows `deleted`.
- SHELTERS: `char invite_code` (lets additional staff join, so "employs 1..*" is real).
- ADOPTION_INQUIRIES: `tinyint chat_locked`, `datetime chat_reported_at`, `int chat_reported_by`, `varchar chat_report_reason` (generated unique keys also enforce one active inquiry per adopter+pet and one approved inquiry per pet).

**System tables (optional, show as a separate "infrastructure" group):** `rate_limits(bucket, created_at)`, `password_resets(user_id FK, code_hash, expires_at, attempts, used_at)`, `admin_audit_log(admin_id FK, action, target_type, target_id, details, ip)`.

## 2. Level 0 DFD
- Add data store **D7 | INQUIRY_MESSAGES**.
- Process **5.0 Adoption Inquiry Management** (rename: *Adoption Inquiry & Conversation Management*):
  - ADOPTER --"Message"--> P5 --"Message / Read status"--> D7 ;  D7 --"Conversation"--> P5 --"Conversation / Unread count"--> ADOPTER
  - STAFF --"Message / Report conversation"--> P5 ; P5 --"Conversation / Unread count"--> STAFF
- Process **7.0 Administration & Content Moderation**: STAFF/ADOPTER --"Report"--> P7 ; D5/D7 --"Reported conversation"--> P7 --"Lock / Dismiss decision"--> D5
- Process **1.0 Account & Authentication**: add flows "Consent record" (to D1) and "Data export / Erasure request".

## 3. Use case diagram (PlantUML additions)
```plantuml
usecase "UC-16: Chat About an Inquiry" as UC16
usecase "UC-17: Report a Conversation" as UC17
usecase "UC-18: Manage My Data (Download / Delete)" as UC18
ACT01 --> UC16
ACT02 --> UC16
ACT01 --> UC17
ACT02 --> UC17
ACT01 --> UC18
ACT02 --> UC18
ACT03 --> UC15
UC16 ..> UC02 : <<include>>
UC16 ..> UC10 : <<extend>>
```
UC-15 (Moderate Content & Manage Accounts) now also covers "review, lock or dismiss a reported conversation".

## 4. Class diagram (Mermaid additions)
```mermaid
classDiagram
    class InquiryMessage {
        -int messageId
        -String body
        -DateTime createdAt
        -DateTime readAt
        +markRead() void
    }
    Adopter : +sendMessage(inquiryId, body) InquiryMessage
    Adopter : +viewConversation(inquiryId) List~InquiryMessage~
    Adopter : +reportConversation(inquiryId, reason) void
    Adopter : +downloadMyData() File
    Adopter : +deleteMyAccount() void
    ShelterStaff : +sendMessage(inquiryId, body) InquiryMessage
    ShelterStaff : +reportConversation(inquiryId, reason) void
    SystemAdmin : +reviewReportedConversation(inquiryId) List~InquiryMessage~
    SystemAdmin : +lockConversation(inquiryId) boolean
    AdoptionInquiry "1" *-- "0..*" InquiryMessage : has
    User "1" --> "0..*" InquiryMessage : sends
```

---
# Batch 4 additions

## ERD (Mermaid)
```mermaid
erDiagram
    ADOPTION_INQUIRIES ||--o{ INQUIRY_EVENTS : "records"
    USERS |o--o{ INQUIRY_EVENTS : "acts in"
    ADOPTION_INQUIRIES ||--o| SUCCESS_STORIES : "may become"
    SHELTERS ||--o{ SUCCESS_STORIES : "publishes"
    USERS ||--o{ SUCCESS_STORIES : "writes"
    USERS ||--o{ NOTIFICATIONS : "receives"
    INQUIRY_EVENTS {
        int event_id PK
        int inquiry_id FK
        enum event_type "submitted, under_review, approved, rejected, approval_revoked, withdrawn, meeting_scheduled, adopted, closed_adopted, closed_removed"
        int actor_id FK "NULL for system events"
        varchar note
        datetime meeting_at "only for meeting_scheduled"
        datetime created_at
    }
    SUCCESS_STORIES {
        int story_id PK
        int inquiry_id FK "unique"
        int shelter_id FK
        int posted_by FK
        varchar title
        text body
        enum consent "requested, full, anonymous, declined"
        datetime consent_at
        enum status "published, hidden"
        datetime created_at
    }
    NOTIFICATIONS {
        int notification_id PK
        int user_id FK
        varchar type
        varchar title
        varchar body
        varchar link
        datetime read_at
        datetime created_at
    }
```
**Columns to add:** USERS `email_verified_at`; SHELTERS `city`, `province`; PETS `size`, `vaccinated`, `neutered`, `good_with_kids`; PASSWORD_RESETS `purpose` (reset, verify, admin_login).
`adoption_inquiries.status` keeps its four values on purpose: the timeline lives in INQUIRY_EVENTS.

## Level 0 DFD
- New stores: **D8 | INQUIRY_EVENTS**, **D9 | SUCCESS_STORIES**. (NOTIFICATIONS is infrastructure; show it as a store only if your instructor wants every table.)
- 5.0 Adoption Inquiry Management: writes "Timeline event" to D8; STAFF --"Meeting / review decision"--> P5; P5 --"Timeline / meeting date"--> ADOPTER.
- 6.0 Announcement & Donation Request: add "Success story" (STAFF -> P6 -> D9), "Story consent request" (P6 -> ADOPTER) and "Consent decision" (ADOPTER -> P6 -> D9); public flow "Published stories" (D9 -> P6 -> ADOPTER).
- 1.0 Account & Authentication: add "Verification code" (P1 -> user email, user -> P1), "Security check answer" and, for ADMIN, "Sign-in code".

## Use cases (PlantUML)
```plantuml
usecase "UC-19: Verify Email" as UC19
usecase "UC-20: View Notifications" as UC20
usecase "UC-21: Track Adoption Timeline" as UC21
usecase "UC-22: Share and Consent to a Success Story" as UC22
usecase "UC-23: Confirm Admin Sign-in Code" as UC23
ACT01 --> UC19
ACT02 --> UC19
ACT01 --> UC20
ACT02 --> UC20
ACT03 --> UC20
ACT01 --> UC21
ACT02 --> UC21
ACT01 --> UC22
ACT02 --> UC22
ACT03 --> UC23
UC10 ..> UC19 : <<include>>
UC16 ..> UC19 : <<include>>
UC23 ..> UC02 : <<extend>>
UC12 ..> UC21 : <<include>>
```
Also update **UC-01 Register Account** (security check) and **UC-03 Reset Password** (security check).

## Class diagram (Mermaid)
```mermaid
classDiagram
    class InquiryEvent {
        -int eventId
        -String eventType
        -String note
        -DateTime meetingAt
        -DateTime createdAt
    }
    class SuccessStory {
        -int storyId
        -String title
        -String body
        -String consent
        -String status
        +requestConsent() void
        +setConsent(choice) void
    }
    class Notification {
        -int notificationId
        -String type
        -String title
        -String link
        -DateTime readAt
        +markRead() void
    }
    AdoptionInquiry "1" *-- "1..*" InquiryEvent : timeline
    AdoptionInquiry "1" o-- "0..1" SuccessStory : may become
    User "1" --> "0..*" Notification : receives
    User : -DateTime emailVerifiedAt
    User : +verifyEmail(code) boolean
    ShelterStaff : +scheduleMeeting(inquiryId, when) InquiryEvent
    ShelterStaff : +markUnderReview(inquiryId) void
    ShelterStaff : +writeSuccessStory(inquiryId, text) SuccessStory
    Adopter : +answerStoryConsent(storyId, choice) void
    SystemAdmin : +hideStory(storyId) boolean
    Shelter : -String city
    Shelter : -String province
    Pet : -String size
    Pet : -String vaccinated
    Pet : -String neutered
    Pet : -String goodWithKids
```


# Batch 5 additions
**New tables:** `adopter_readiness(user_id PK/FK, landlord_permission, monthly_budget, caregiver)`, `adoption_followups(inquiry_id FK, milestone, due_at, submitted_at, wellbeing, notes, photo, share_ok)`,
`rescue_cases(shelter_id FK, case_type, urgency, title, description, pet_id FK, donation_post_id FK, status)`, `foster_volunteers(user_id PK/FK, species_ok, capacity, medical_ok, availability, status)`,
`case_offers(case_id FK, user_id FK, message, status)`, `password_history(user_id FK, password_hash)`.
**New columns:** USERS `is_shelter_admin`, `created_by`; SHELTERS `logo`, `about`; PETS `good_with_pets`, `needs_yard`, `energy_level`, `experience_needed`, status `draft`; PET_PHOTOS `content_hash`; ADOPTION_INQUIRIES `readiness` (JSON snapshot).
**Use cases:** UC-24 Complete home-readiness check; UC-25 Post-adoption check-in; UC-26 Post / answer a foster or rescue case; UC-27 View shelter profile and transparency stats; UC-28 Manage shelter employee accounts (shelter administrator creates credentials).
**Actors:** the Shelter Staff actor now splits into *Shelter Administrator* (registers the shelter, creates employee accounts) and *Shelter Employee*.


# Batch 6 additions
**New tables:** `welfare_checks(inquiry_id FK, staff_id FK, method, outcome, note)`, `shelter_petitions(shelter_id FK, opened_by FK, status open/approved/denied, resolved_by FK, resolved_at)`, `shelter_petition_messages(petition_id FK, sender_id FK, sender_side shelter/admin, body)`.
**New columns:** SHELTERS `latitude`, `longitude`, `suspension_reason`, `suspended_at`; ADOPTION_INQUIRIES `no_response_flagged_at`.
**Use cases:** UC-29 Choose account type; UC-30 Request shelter reactivation (Shelter Administrator; System Administrator decides, extends UC-15); UC-31 Read a success story (extends the public Success Stories view); UC-32 Record a welfare check (extends UC-25 Post-adoption check-in when all three go unanswered).
**Scope note for the use case diagram:** the adoption itself (requirements, interview, contract, fee, hand-over) is outside the system boundary; it happens between the Adopter and the Shelter.

```mermaid
erDiagram
    SHELTERS ||--o{ SHELTER_PETITIONS : "may open"
    SHELTER_PETITIONS ||--o{ SHELTER_PETITION_MESSAGES : "has"
    ADOPTION_INQUIRIES ||--o{ WELFARE_CHECKS : "may have"
    USERS ||--o{ WELFARE_CHECKS : "logs"
```
