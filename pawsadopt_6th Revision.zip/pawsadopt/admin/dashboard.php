<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = require_role('admin');
$title = 'Admin dashboard'; $page = 'dash';
$c = fn($sql) => (int)q($sql)->fetchColumn();
$stats = [
  'Reactivation petitions' => petition_open_count(),
  'Shelters awaiting review' => $c("SELECT COUNT(*) FROM shelters WHERE verification_status='pending'"),
  'Approved shelters' => $c("SELECT COUNT(*) FROM shelters WHERE verification_status='approved'"),
  'Adopters' => $c("SELECT COUNT(*) FROM users WHERE role='adopter'"),
  'Shelter staff' => $c("SELECT COUNT(*) FROM users WHERE role='staff'"),
  'Available pets' => $c("SELECT COUNT(*) FROM pets WHERE status='available'"),
  'Adopted pets' => $c("SELECT COUNT(*) FROM pets WHERE status='adopted'"),
  'Open inquiries' => $c("SELECT COUNT(*) FROM adoption_inquiries WHERE status='pending'"),
  'Live posts' => $c("SELECT COUNT(*) FROM announcements_donations WHERE status='published'"),
];
$months = []; for ($k = 5; $k >= 0; $k--) $months[] = date('Y-m', strtotime("first day of -$k month"));
$labels = array_map(fn($m) => date('M', strtotime($m . '-01')), $months);
$series = function (string $sql) use ($months) { $o = array_fill_keys($months, 0); foreach (q($sql)->fetchAll() as $r) if (isset($o[$r['m']])) $o[$r['m']] = (int)$r['c']; return array_values($o); };
$inqSeries = $series("SELECT DATE_FORMAT(submitted_at, '%Y-%m') m, COUNT(*) c FROM adoption_inquiries WHERE submitted_at >= DATE_FORMAT(NOW() - INTERVAL 5 MONTH, '%Y-%m-01') GROUP BY m");
$adoptSeries = $series("SELECT DATE_FORMAT(created_at, '%Y-%m') m, COUNT(*) c FROM inquiry_events WHERE event_type = 'adopted' AND created_at >= DATE_FORMAT(NOW() - INTERVAL 5 MONTH, '%Y-%m-01') GROUP BY m");
include __DIR__ . '/../includes/header.php';
?>
<h1>Admin dashboard</h1>
<?php if (ADMIN_2FA && !email_verified($u)): ?><div class="flash flash-info"><strong>Two-step sign-in is off.</strong> Set your real email in <a href="<?= url('profile.php') ?>">Profile</a>, then <a href="<?= url('verify_email.php') ?>">verify it</a>. After that every admin sign-in also needs a code emailed to you.</div><?php endif; ?>
<div class="stats"><?php foreach ($stats as $k => $v): ?><div class="stat"><b><?= $v ?></b><span><?= e($k) ?></span></div><?php endforeach; ?></div>
<div class="charts">
  <div class="panel"><h2>Inquiries per month</h2><?= svg_bar_chart($labels, $inqSeries, 'Inquiries sent per month, last 6 months') ?></div>
  <div class="panel"><h2>Adoptions per month</h2><?= svg_bar_chart($labels, $adoptSeries, 'Adoptions completed per month, last 6 months') ?></div>
</div>
<?php if ($stats['Shelters awaiting review']): ?><div class="panel"><h2>Shelters need your review</h2><p><?= $stats['Shelters awaiting review'] ?> shelter(s) submitted documents for verification.</p><a class="btn" href="<?= url('admin/shelters.php') ?>">Review shelters</a></div><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
