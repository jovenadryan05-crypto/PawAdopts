<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Success stories'; $page = 'stories';
$updates = public_checkins(9);           // adopter check-ins (note + photo) shared with the adopter's permission
// Public: only published stories whose adopter explicitly consented. The adopter's name and photo appear only with "full" consent.
$cond = "st.status='published' AND st.consent IN ('full','anonymous') AND sh.verification_status='approved' AND sh.account_status='active'";
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM success_stories st JOIN shelters sh ON sh.shelter_id=st.shelter_id WHERE $cond")->fetchColumn(), 12);
$rows = q("SELECT st.*, p.pet_name, p.species, sh.shelter_name, sh.shelter_id, sh.city, a.first_name, a.last_name, a.profile_photo,
             (SELECT photo_url FROM pet_photos WHERE pet_id=p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
           FROM success_stories st JOIN adoption_inquiries i ON i.inquiry_id=st.inquiry_id JOIN pets p ON p.pet_id=i.pet_id
           JOIN shelters sh ON sh.shelter_id=st.shelter_id JOIN users a ON a.user_id=i.adopter_id
           WHERE $cond ORDER BY st.created_at DESC LIMIT 12 OFFSET $off")->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<h1>Success stories</h1>
<p class="muted">Happy endings from our partner shelters, shared with the adopters' permission.</p>
<?php if (!$rows): ?><div class="empty"><h2>No stories yet</h2><p>When an adoption is completed and the family agrees, the story appears here.</p></div><?php endif; ?>
<div class="stories-grid">
<?php foreach ($rows as $r): ?>
  <article class="story">
    <a class="thumb" href="<?= url('story.php?id=' . (int)$r['story_id']) ?>" tabindex="-1" aria-hidden="true"><?php if ($r['photo']): ?><img src="<?= url($r['photo']) ?>" alt="" loading="lazy"><?php else: ?><span class="ph">&#128062;</span><?php endif; ?></a>
    <div class="story-body">
      <h2><a class="story-link" href="<?= url('story.php?id=' . (int)$r['story_id']) ?>"><?= e($r['title']) ?></a></h2>
      <p class="small muted"><?= e($r['pet_name']) ?> the <?= e(strtolower($r['species'])) ?> &middot; <a href="<?= url('shelter.php?id=' . $r['shelter_id']) ?>"><?= e($r['shelter_name']) ?></a><?= $r['city'] ? ', ' . e($r['city']) : '' ?></p>
      <p class="prose"><?= e(story_excerpt($r['body'], 180)) ?></p>
      <p><a href="<?= url('story.php?id=' . (int)$r['story_id']) ?>">Read the full story &rarr;</a></p>
      <div class="who">
        <?php if ($r['consent'] === 'full'): ?><?= avatar($r) ?><span>Adopted by <b><?= e($r['first_name']) ?></b></span>
        <?php else: ?><span class="muted">Adopted by a loving family</span><?php endif; ?>
      </div>
    </div>
  </article>
<?php endforeach; ?>
</div>
<?= pager($pg, $pages) ?>
<?php if ($updates): ?>
<h2 class="sec">Where are they now?</h2>
<p class="muted">Updates from adopters, shared with their permission.</p>
<div class="stories-grid">
<?php foreach ($updates as $r): ?>
  <article class="story"><a class="thumb" href="<?= url('story.php?update=' . (int)$r['followup_id']) ?>" tabindex="-1" aria-hidden="true"><?php $img = $r['photo'] ?: $r['pet_photo']; if ($img): ?><img src="<?= url($img) ?>" alt="" loading="lazy"><?php else: ?><span class="ph">&#128062;</span><?php endif; ?></a>
    <div class="story-body"><h3><a class="story-link" href="<?= url('story.php?update=' . (int)$r['followup_id']) ?>"><?= e($r['pet_name']) ?>, <?= e(followup_milestones()[$r['milestone']][0]) ?> after adoption</a></h3>
      <p class="small muted"><?= e($r['species']) ?> &middot; <a href="<?= url('shelter.php?id=' . $r['shelter_id']) ?>"><?= e($r['shelter_name']) ?></a> &middot; <?= e(explode(':', wellbeing_options()[$r['wellbeing']])[0]) ?></p>
      <?php if ($r['notes']): ?><p class="prose"><?= e(story_excerpt($r['notes'], 180)) ?></p><?php endif; ?>
      <p><a href="<?= url('story.php?update=' . (int)$r['followup_id']) ?>">Read more &rarr;</a></p>
      <p class="small muted">Update from <?= e($r['first_name']) ?></p></div></article>
<?php endforeach; ?></div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
