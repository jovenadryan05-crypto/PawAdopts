<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_role();
$title = 'Notifications'; $page = 'notif';
if (isset($_GET['go'])) {                                   // open one notification: mark it read and follow its link
    $n = q('SELECT * FROM notifications WHERE notification_id = ? AND user_id = ?', [(int)$_GET['go'], $u['user_id']])->fetch();
    if ($n) {
        q('UPDATE notifications SET read_at = COALESCE(read_at, NOW()) WHERE notification_id = ?', [$n['notification_id']]);
        $l = (string)$n['link'];
        if ($l !== '' && !preg_match('#^[a-z]+:|^//#i', $l)) redirect($l);   // stored links are always site-relative
    }
    redirect('notifications.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    q('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$u['user_id']]);
    flash('success', 'All notifications marked as read.'); redirect('notifications.php');
}
[$pg, $pages, $off] = paginate((int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$u['user_id']])->fetchColumn(), 20);
$rows = q("SELECT * FROM notifications WHERE user_id = ? ORDER BY notification_id DESC LIMIT 20 OFFSET $off", [$u['user_id']])->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<div class="split"><h1>Notifications</h1>
  <?php if (notif_count($u)): ?><form method="post"><?= csrf_field() ?><button class="btn btn-ghost btn-sm">Mark all as read</button></form><?php endif; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>Nothing yet</h2><p>Updates about inquiries, messages and your shelter will show up here.</p></div>
<?php else: ?><div class="panel notif-list">
  <?php foreach ($rows as $n): ?>
    <a class="notif <?= $n['read_at'] ? '' : 'unread' ?>" href="<?= url('notifications.php?go=' . $n['notification_id']) ?>">
      <strong><?= e($n['title']) ?></strong><?php if ($n['body']): ?><span class="muted"> &middot; <?= e($n['body']) ?></span><?php endif; ?>
      <span class="small muted block"><?= e(date('M j, g:i A', strtotime($n['created_at']))) ?></span>
    </a>
  <?php endforeach; ?></div>
  <p class="small muted">Notifications are kept for 90 days.</p>
<?= pager($pg, $pages) ?><?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
