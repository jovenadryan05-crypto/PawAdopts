<?php
// One-time codes (table password_resets, column purpose): reset | verify | admin_login.
// 6 digits, stored hashed, valid 10 minutes, 5 tries, single use, rate limited.

/** Email a fresh code. Returns false when rate limited. Any earlier code for the same purpose is replaced. */
function otp_issue(array $user, string $purpose, string $subject, string $intro, int $maxPerHour = 3): bool {
    $uid = (int)$user['user_id'];
    $b1 = "otp:$purpose:$uid"; $b2 = "otp:ip:$purpose:" . client_ip();
    if (rate_blocked($b1, $maxPerHour, 3600) || rate_blocked($b2, 10, 3600)) return false;
    rate_hit($b1); rate_hit($b2);
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    q('DELETE FROM password_resets WHERE user_id = ? AND purpose = ?', [$uid, $purpose]);
    q('INSERT INTO password_resets (user_id, purpose, code_hash, expires_at) VALUES (?,?,?, NOW() + INTERVAL 10 MINUTE)', [$uid, $purpose, password_hash($code, PASSWORD_DEFAULT)]);
    send_mail_later($user['email'], $subject, mail_layout($subject,
        '<p>Hi ' . e($user['first_name']) . ',</p><p>' . e($intro) . '</p><p>Your code is <b style="font-size:22px;letter-spacing:3px">' . $code . '</b></p>'
        . '<p>It expires in 10 minutes. If you did not ask for it, you can ignore this email.</p>', user_sender($user, 'Your PawsAdopt account')));
    return true;
}
/** @return string 'ok' | 'bad' (wrong code) | 'expired' (no live code: expired, used, or 5 wrong tries) */
function otp_verify(int $userId, string $purpose, string $code, bool $consume = true): string {
    $r = q('SELECT * FROM password_resets WHERE user_id = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW() AND attempts < 5 ORDER BY reset_id DESC LIMIT 1', [$userId, $purpose])->fetch();
    if (!$r) return 'expired';
    if (!password_verify(trim($code), $r['code_hash'])) { q('UPDATE password_resets SET attempts = attempts + 1 WHERE reset_id = ?', [$r['reset_id']]); return 'bad'; }
    if ($consume) q('UPDATE password_resets SET used_at = NOW() WHERE reset_id = ?', [$r['reset_id']]);
    return 'ok';
}
/** Burn a code that was checked with $consume = false (used once the rest of the form has also been accepted). */
function otp_consume(int $userId, string $purpose): void { q('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND purpose = ? AND used_at IS NULL', [$userId, $purpose]); }
