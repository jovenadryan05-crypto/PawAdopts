</main>
<footer class="site-footer"><div class="wrap foot"><span>PawsAdopt connects adopters with verified animal shelters. Adopt, don't shop.</span>
  <span class="legal-links"><a href="<?= url('terms.php') ?>">Terms</a><a href="<?= url('privacy.php') ?>">Privacy Notice</a></span></div></footer>
<div id="pageLoader" class="page-loader" hidden aria-hidden="true"><svg viewBox="0 0 64 64"><circle cx="13" cy="30" r="6"/><circle cx="25" cy="17" r="6.5"/><circle cx="40" cy="17" r="6.5"/><circle cx="52" cy="30" r="6"/><path d="M32 34c-9 0-17 8-17 15 0 5 4 7 9 6 3-.7 5-1.5 8-1.5s5 .8 8 1.5c5 1 9-1 9-6 0-7-8-15-17-15z"/></svg></div>
<script src="<?= url('assets/js/app.js') ?>"></script>
<?php foreach (($scripts ?? []) as $sc): ?><script src="<?= url($sc) ?>"></script>
<?php endforeach; ?>
</body>
</html>
