<?php $u = user(); $page = $page ?? ''; $unread = $u ? nav_unread($u) : 0; $notifs = $u ? notif_count($u) : 0;
// adopters who adopted through PawsAdopt see a Check-ins link; reminders are created here (in-app) when a check-in is due
$navPetitions = ($u && $u['role'] === 'admin') ? petition_open_count() : 0; $checkins = null; $navNoResp = ($u && shelter_ready($u)) ? followups_no_response_count((int)$u['shelter_id']) : 0;
if ($u && $u['role'] === 'adopter') {
    $hasAdoption = (bool)q("SELECT 1 FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id WHERE i.adopter_id = ? LIMIT 1", [$u['user_id']])->fetch();
    if ($hasAdoption) { followups_process($u, false); $checkins = followups_due_count((int)$u['user_id']); $notifs = notif_count($u); }
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'PawsAdopt') ?> | PawsAdopt</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body<?= $u ? ' data-unread-url="' . e(url('chat_api.php?unread=1')) . '"' : '' ?>>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?= url($u ? home_for($u) : 'index.php') ?>"><span class="paw" aria-hidden="true">&#128062;</span>PawsAdopt</a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="nav">Menu</button>
    <nav id="nav" class="nav">
      <?php if (!$u): ?><a href="<?= url('index.php') ?>" class="<?= $page==='home'?'on':'' ?>">Home</a><?php endif; ?>
      <a href="<?= url('pets.php') ?>" class="<?= $page==='browse'?'on':'' ?>">Find a pet</a>
      <a href="<?= url('shelters.php') ?>" class="<?= $page==='shelterdir'?'on':'' ?>">Shelters</a>
      <a href="<?= url('board.php') ?>" class="<?= $page==='board'?'on':'' ?>">Foster &amp; rescue</a>
      <a href="<?= url('announcements.php') ?>" class="<?= $page==='news'?'on':'' ?>">Announcements</a>
      <a href="<?= url('stories.php') ?>" class="<?= $page==='stories'?'on':'' ?>">Success stories</a>
      <?php if ($u && $u['role']==='adopter'): ?>
        <a href="<?= url('adopter/inquiries.php') ?>" class="<?= $page==='inq'?'on':'' ?>">My inquiries<?= count_badge($unread) ?></a>
        <?php if ($checkins !== null): ?><a href="<?= url('adopter/checkins.php') ?>" class="<?= $page==='checkins'?'on':'' ?>">Check-ins<?= $checkins ? '<span class="count">' . $checkins . '</span>' : '' ?></a><?php endif; ?>
      <?php elseif ($u && $u['role']==='staff'): ?>
        <a href="<?= url('staff/dashboard.php') ?>" class="<?= $page==='dash'?'on':'' ?>">Dashboard</a>
        <?php if (shelter_suspended($u)): ?><a href="<?= url('staff/petition.php') ?>" class="<?= $page==='petition'?'on':'' ?>">Reactivation</a><?php endif; ?>
        <a href="<?= url('staff/pets.php') ?>" class="<?= $page==='pets'?'on':'' ?>">Pet listings</a>
        <a href="<?= url('staff/inquiries.php') ?>" class="<?= $page==='inq'?'on':'' ?>">Inquiries<?= count_badge($unread) ?></a>
        <a href="<?= url('staff/posts.php') ?>" class="<?= $page==='posts'?'on':'' ?>">Posts</a>
        <a href="<?= url('staff/board.php') ?>" class="<?= $page==='sboard'?'on':'' ?>">Rescue board</a>
        <a href="<?= url('staff/followups.php') ?>" class="<?= $page==='sfollow'?'on':'' ?>">Welfare<?= $navNoResp ? '<span class="count">' . $navNoResp . '</span>' : '' ?></a>
        <?php if (!empty($u['is_shelter_admin'])): ?><a href="<?= url('staff/team.php') ?>" class="<?= $page==='team'?'on':'' ?>">Team</a><?php endif; ?>
        <a href="<?= url('staff/stories.php') ?>" class="<?= $page==='sstories'?'on':'' ?>">Stories</a>
      <?php elseif ($u && $u['role']==='admin'): ?>
        <a href="<?= url('admin/dashboard.php') ?>" class="<?= $page==='dash'?'on':'' ?>">Dashboard</a>
        <a href="<?= url('admin/shelters.php') ?>" class="<?= $page==='shelters'?'on':'' ?>">Shelters</a>
        <a href="<?= url('admin/petitions.php') ?>" class="<?= $page==='petitions'?'on':'' ?>">Petitions<?= $navPetitions ? '<span class="count">' . $navPetitions . '</span>' : '' ?></a>
        <a href="<?= url('admin/users.php') ?>" class="<?= $page==='users'?'on':'' ?>">Users</a>
        <a href="<?= url('admin/moderation.php') ?>" class="<?= $page==='mod'?'on':'' ?>">Moderation<?= count_badge($unread) ?></a>
        <a href="<?= url('admin/audit.php') ?>" class="<?= $page==='audit'?'on':'' ?>">Audit log</a>
      <?php endif; ?>
      <span class="nav-sep"></span>
      <?php if ($u): ?>
        <a href="<?= url('notifications.php') ?>" class="bell <?= $page==='notif'?'on':'' ?>" aria-label="Notifications"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg><?= notif_badge($notifs) ?></a>
        <a href="<?= url('profile.php') ?>" class="<?= $page==='profile'?'on':'' ?> me"><?= avatar($u, 'sm') ?><?= e($u['first_name']) ?></a>
        <form method="post" action="<?= url('logout.php') ?>" class="inline"><?= csrf_field() ?><button class="linklike">Log out</button></form>
      <?php else: ?>
        <a href="<?= url('login.php') ?>">Log in</a>
        <a href="<?= url('register.php') ?>" class="btn btn-sm">Sign up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php include __DIR__ . '/login_popup.php'; ?>
<?php if ($u && $u['role'] !== 'admin' && !email_verified($u) && basename($_SERVER['SCRIPT_NAME']) !== 'verify_email.php'): ?>
<div class="verify-banner"><div class="wrap">Your email is not verified yet, so you cannot send inquiries or messages. <a href="<?= url('verify_email.php') ?>">Verify it now</a></div></div>
<?php endif; ?>
<main class="wrap main">
<?php foreach (flash() as [$t, $m]): ?>
  <div class="flash flash-<?= e($t) ?>" role="status"><?= e($m) ?></div>
<?php endforeach; ?>
