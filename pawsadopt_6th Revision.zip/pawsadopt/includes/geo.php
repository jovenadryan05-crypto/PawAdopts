<?php
// Exact map pins for shelters. The shelter administrator sets latitude/longitude (browser location button, or pasting coordinates
// or a Google Maps / OpenStreetMap link), and the public map shows a pin at exactly that point instead of guessing from the address.

/** Roughly the Philippines. Anything outside is rejected as a typo (for example latitude and longitude swapped). */
function ph_coords_ok(float $lat, float $lng): bool { return $lat >= 4.5 && $lat <= 21.5 && $lng >= 116.0 && $lng <= 127.0; }

/**
 * Read a coordinate pair from what a person pastes: "14.5995, 120.9842", a long Google Maps link (@lat,lng  or  !3dlat!4dlng  or  q=lat,lng),
 * or an OpenStreetMap link (#map=zoom/lat/lng  or  mlat=..&mlon=..). Returns [lat, lng] rounded to 6 decimals, or null.
 * Short links (maps.app.goo.gl) cannot be read without visiting them, so they are not accepted.
 */
function parse_coords(string $raw): ?array {
    $s = trim(rawurldecode($raw));
    if ($s === '' || strlen($s) > 600) return null;
    $n = '(-?\d{1,3}(?:\.\d+)?)';
    $patterns = [
        '/^\s*' . $n . '\s*[,;\s]\s*' . $n . '\s*$/',              // 14.5995, 120.9842
        '/!3d' . $n . '!4d' . $n . '/',                              // Google place link
        '/@' . $n . ',' . $n . '/',                                  // Google map view link
        '/[?&](?:q|ll|query|center)=' . $n . ',\s*' . $n . '/',     // ?q=lat,lng
        '/#map=\d{1,2}\/' . $n . '\/' . $n . '/',                    // OpenStreetMap
        '/mlat=' . $n . '&(?:amp;)?mlon=' . $n . '/',                // OpenStreetMap marker
    ];
    foreach ($patterns as $p) {
        if (preg_match($p, $s, $m)) {
            $lat = (float)$m[1]; $lng = (float)$m[2];
            return ph_coords_ok($lat, $lng) ? [round($lat, 6), round($lng, 6)] : null;
        }
    }
    return null;
}

function has_pin(array $sh): bool { return isset($sh['latitude'], $sh['longitude']) && $sh['latitude'] !== null && $sh['longitude'] !== null && $sh['latitude'] !== ''; }
function pin_text(array $sh): string { return number_format((float)$sh['latitude'], 6, '.', '') . ',' . number_format((float)$sh['longitude'], 6, '.', ''); }
/** Embeddable map. With a pin: centred on, and marked at, the exact point. Without: Google's best guess from the address (labelled as approximate). */
function map_embed_url(array $sh, string $addressQuery): string {
    $q = has_pin($sh) ? pin_text($sh) : $addressQuery;
    return 'https://maps.google.com/maps?q=' . rawurlencode($q) . '&z=' . (has_pin($sh) ? 18 : 15) . '&output=embed';
}
function map_open_url(array $sh, string $addressQuery): string {
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(has_pin($sh) ? pin_text($sh) : $addressQuery);
}
function map_osm_url(array $sh, string $addressQuery): string {
    return has_pin($sh) ? 'https://www.openstreetmap.org/?mlat=' . rawurlencode((string)(float)$sh['latitude']) . '&mlon=' . rawurlencode((string)(float)$sh['longitude']) . '#map=18/' . rawurlencode((string)(float)$sh['latitude']) . '/' . rawurlencode((string)(float)$sh['longitude'])
                        : 'https://www.openstreetmap.org/search?query=' . rawurlencode($addressQuery);
}

/**
 * The pin input used on the shelter sign-up form and the shelter profile form (behaviour is in assets/js/app.js, [data-pin-field]).
 * $required: 'yes' = always required, 'role' = required only when the sign-up role is shelter (data-req-shelter), 'no' = optional.
 */
function pin_field(string $value = '', string $required = 'yes'): string {
    $ok = parse_coords($value);
    $src = $ok ? 'https://maps.google.com/maps?q=' . rawurlencode($ok[0] . ',' . $ok[1]) . '&amp;z=18&amp;output=embed' : '';
    $req = $required === 'yes' ? ' required' : ($required === 'role' ? ' data-req-shelter' : '');
    return '<div class="pin-field" data-pin-field>'
        . '<label>Exact map pin (latitude, longitude)<input name="pin" value="' . e($value) . '" placeholder="e.g. 14.599500, 120.984200" maxlength="600" autocomplete="off" data-pin-input' . $req . '></label>'
        . '<div class="actions"><button type="button" class="btn btn-ghost btn-sm" data-geo>&#128205; Use my current location</button><span class="small muted" data-geo-status role="status"></span></div>'
        . '<p class="hint">Best accuracy: tap the button while you are at the shelter (on a phone, with location turned on). Or open Google Maps, right-click (long-press on a phone) your shelter, copy the coordinates shown at the top of the menu and paste them here. '
        . 'A full Google Maps or OpenStreetMap link also works; shortened links (maps.app.goo.gl) do not. Philippine locations only.</p>'
        . '<iframe class="map-frame" data-pin-preview title="Preview of the pin you chose" loading="lazy" referrerpolicy="no-referrer-when-downgrade"' . ($src ? ' src="' . $src . '"' : ' hidden') . '></iframe>'
        . '</div>';
}
/** Validate the pin input. Returns [lat, lng, error]. Empty input gives [null, null, null] (caller decides if that is allowed). */
function pin_from_post(string $raw): array {
    $raw = trim($raw);
    if ($raw === '') return [null, null, null];
    $c = parse_coords($raw);
    return $c ? [$c[0], $c[1], null] : [null, null, 'The map pin was not understood or is outside the Philippines. Use "latitude, longitude" (for example 14.5995, 120.9842) or a full Google Maps link.'];
}
