<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$title = 'Foster & emergency rescue board'; $page = 'board';
$u = user(); $adopter = $u && $u['role'] === 'adopter' ? $u : null;
// Public board: urgent rescue cases and foster needs from verified shelters. Adopters who registered as foster volunteers can offer to help.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adopter = require_role('adopter'); require_verified($adopter);
    $caseId = (int)($_POST['case_id'] ?? 0); $msg = trim($_POST['message'] ?? '');
    $case = q("SELECT c.*, s.shelter_name, s.contact_email, s.logo FROM rescue_cases c JOIN shelters s ON s.shelter_id = c.shelter_id
               WHERE c.case_id = ? AND c.status = 'open' AND s.verification_status = 'approved' AND s.account_status = 'active'", [$caseId])->fetch();
    $vol = q("SELECT 1 FROM foster_volunteers WHERE user_id = ? AND status = 'active'", [$adopter['user_id']])->fetch();
    if (!$case) flash('error', 'That request is no longer open.');
    elseif (!$vol) flash('info', 'Register as a foster volunteer first, so shelters know what you can offer.');
    elseif (str_len($msg) > 500) flash('error', 'Please keep your message under 500 characters.');
    elseif (rate_blocked('offer:user:' . $adopter['user_id'], 10, 3600)) flash('error', 'You sent several offers recently. Please wait a while.');
    elseif (q('SELECT 1 FROM case_offers WHERE case_id = ? AND user_id = ? AND status IN (\'offered\',\'accepted\')', [$caseId, $adopter['user_id']])->fetch()) flash('info', 'You already offered to help with this one.');
    else {
        q('INSERT INTO case_offers (case_id, user_id, message) VALUES (?,?,?) ON DUPLICATE KEY UPDATE status = \'offered\', message = VALUES(message), created_at = NOW()', [$caseId, $adopter['user_id'], $msg ?: null]);
        rate_hit('offer:user:' . $adopter['user_id']);
        $subj = 'A volunteer offered to help: ' . $case['title'];
        send_mail_later($case['contact_email'], $subj, mail_layout($subj, '<p><b>' . e($adopter['first_name'] . ' ' . $adopter['last_name']) . '</b> offered to help with your ' . ($case['case_type'] === 'foster_needed' ? 'foster request' : 'rescue case') . '.</p>'
            . ($msg ? mail_quote($msg) : '') . '<p>Their contact details and what they can offer are on your rescue board.</p>' . mail_button('Open the rescue board', 'staff/board.php'), user_sender($adopter, 'Foster volunteer')));
        notify_users(shelter_staff_ids((int)$case['shelter_id']), 'offer', 'New volunteer offer', $case['title'], 'staff/board.php');
        flash('success', 'Thank you! Your offer was sent to ' . $case['shelter_name'] . '. They will contact you directly.');
    }
    redirect('board.php');
}
$type = $_GET['type'] ?? ''; $shelter = (int)($_GET['shelter'] ?? 0);
$where = "c.status = 'open' AND s.verification_status = 'approved' AND s.account_status = 'active'"; $args = [];
if (in_array($type, ['emergency_rescue', 'foster_needed'], true)) { $where .= ' AND c.case_type = ?'; $args[] = $type; }
if ($shelter) { $where .= ' AND c.shelter_id = ?'; $args[] = $shelter; }
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM rescue_cases c JOIN shelters s ON s.shelter_id = c.shelter_id WHERE $where", $args)->fetchColumn(), 10);
$cases = q("SELECT c.*, s.shelter_name, s.city, s.province, s.logo, s.contact_email, s.contact_number, p.pet_name,
              (SELECT photo_url FROM pet_photos WHERE pet_id = c.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo,
              d.title AS donation_title, d.target_amount AS donation_target, d.status AS donation_status
            FROM rescue_cases c JOIN shelters s ON s.shelter_id = c.shelter_id LEFT JOIN pets p ON p.pet_id = c.pet_id LEFT JOIN announcements_donations d ON d.post_id = c.donation_post_id
            WHERE $where ORDER BY FIELD(c.urgency,'critical','high','normal'), c.created_at DESC LIMIT 10 OFFSET $off", $args)->fetchAll();
$vol = $adopter ? q('SELECT * FROM foster_volunteers WHERE user_id = ?', [$adopter['user_id']])->fetch() : null;
$mine = [];
if ($adopter && $cases) foreach (q('SELECT case_id, status FROM case_offers WHERE user_id = ? AND case_id IN (' . implode(',', array_map('intval', array_column($cases, 'case_id'))) . ')', [$adopter['user_id']])->fetchAll() as $o) $mine[$o['case_id']] = $o['status'];
$nVol = (int)q("SELECT COUNT(*) FROM foster_volunteers WHERE status = 'active'")->fetchColumn();
include __DIR__ . '/includes/header.php';
?>
<h1>Foster &amp; emergency rescue board</h1>
<p class="muted">Urgent cases and foster needs from verified shelters. A few weeks in a foster home can save a life and free up space for the next rescue. <?= $nVol ?> volunteer<?= $nVol === 1 ? ' is' : 's are' ?> registered.</p>
<div class="actions">
  <?php if ($adopter): ?><a class="btn" href="<?= url('foster.php') ?>"><?= $vol ? 'My foster volunteer profile' : 'Become a foster volunteer' ?></a>
  <?php elseif (!$u): ?><a class="btn" href="<?= url('register.php?as=adopter') ?>">Create an account to volunteer</a> <a class="btn btn-ghost" href="<?= url('login.php') ?>">Log in</a>
  <?php elseif ($u['role'] === 'staff'): ?><a class="btn" href="<?= url('staff/board.php') ?>">Post a case for your shelter</a><?php endif; ?>
</div>
<div class="tabs">
  <a class="<?= $type === '' ? 'on' : '' ?>" href="<?= url('board.php' . ($shelter ? '?shelter=' . $shelter : '')) ?>">All</a>
  <a class="<?= $type === 'emergency_rescue' ? 'on' : '' ?>" href="?type=emergency_rescue<?= $shelter ? '&amp;shelter=' . $shelter : '' ?>">Emergency rescue</a>
  <a class="<?= $type === 'foster_needed' ? 'on' : '' ?>" href="?type=foster_needed<?= $shelter ? '&amp;shelter=' . $shelter : '' ?>">Foster needed</a>
</div>
<?php if (!$cases): ?><div class="empty"><h2>Nothing urgent right now</h2><p>When a shelter needs a rescue hand or a foster home, it will show up here.</p></div><?php endif; ?>
<div class="posts wide">
<?php foreach ($cases as $c): ?>
  <article class="post case-<?= e($c['urgency']) ?>">
    <div class="post-head"><span class="badge b-<?= $c['urgency'] === 'normal' ? 'announcement' : 'rejected' ?>"><?= e(['critical' => 'Critical', 'high' => 'Urgent', 'normal' => 'Needed'][$c['urgency']]) ?></span>
      <span class="badge"><?= $c['case_type'] === 'foster_needed' ? 'Foster needed' : 'Emergency rescue' ?></span><?php if ($c['species']): ?><span class="badge"><?= e($c['species']) ?></span><?php endif; ?></div>
    <div class="case-body"><?php if ($c['photo']): ?><img class="case-photo" src="<?= url($c['photo']) ?>" alt="<?= e($c['pet_name'] ?? '') ?>" loading="lazy"><?php endif; ?>
      <div><h2><?= e($c['title']) ?></h2><p class="prose"><?= nl2br(e($c['description'])) ?></p></div></div>
    <dl class="facts">
      <?php if ($c['needs']): ?><div><dt>What is needed</dt><dd><?= e($c['needs']) ?></dd></div><?php endif; ?>
      <?php if ($c['needed_by']): ?><div><dt>Needed by</dt><dd><?= fdate($c['needed_by']) ?></dd></div><?php endif; ?>
      <?php if ($c['duration_weeks']): ?><div><dt>Foster length</dt><dd>About <?= (int)$c['duration_weeks'] ?> week<?= (int)$c['duration_weeks'] === 1 ? '' : 's' ?></dd></div><?php endif; ?>
      <div><dt>Shelter</dt><dd><a href="<?= url('shelter.php?id=' . $c['shelter_id']) ?>"><?= e($c['shelter_name']) ?></a><?= $c['city'] ? ', ' . e($c['city']) : '' ?></dd></div>
    </dl>
    <?php if ($c['donation_title'] && $c['donation_status'] === 'published'): ?><p class="small donation-link">&#128155; Supplies and vet costs: see the donation request <a href="<?= url('announcements.php?type=donation') ?>"><?= e($c['donation_title']) ?></a><?= $c['donation_target'] !== null ? ' (target &#8369;' . number_format((float)$c['donation_target'], 2) . ')' : '' ?>. PawsAdopt does not handle money; contact the shelter: <?= e($c['contact_email']) ?> &middot; <?= e($c['contact_number']) ?></p><?php endif; ?>
    <p class="small muted">Posted <?= fdate($c['created_at']) ?></p>
    <?php if ($adopter): $st = $mine[$c['case_id']] ?? null; ?>
      <?php if ($st === 'accepted'): ?><p><span class="badge b-approved">Your offer was accepted</span> The shelter will contact you.</p>
      <?php elseif ($st === 'offered'): ?><p><span class="badge b-pending">Offer sent</span> Waiting for the shelter's reply.</p>
      <?php elseif (!$vol || $vol['status'] !== 'active'): ?><p><a class="btn btn-sm" href="<?= url('foster.php') ?>">Register as a volunteer to offer help</a></p>
      <?php else: ?><details class="more"><summary>I can help</summary><form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="case_id" value="<?= $c['case_id'] ?>">
        <label>Message to the shelter (optional)<textarea name="message" rows="3" maxlength="500" placeholder="When you are free, what you can offer, any questions."></textarea></label>
        <p class="hint">The shelter receives your name, email, mobile number and your volunteer profile.</p><button class="btn btn-sm">Send my offer</button></form></details><?php endif; ?>
    <?php elseif (!$u): ?><p><a href="<?= url('login.php') ?>">Log in</a> or <a href="<?= url('register.php?as=adopter') ?>">create an adopter account</a> to offer help.</p><?php endif; ?>
  </article>
<?php endforeach; ?>
</div>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
