<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_role('adopter');
$title = 'Foster volunteer'; $page = 'board'; $error = '';
// Adopters can register as foster volunteers. Verified shelters see this profile (with contact details) only when the volunteer offers to help
// on a case, and in the shelter's volunteer list.
$vol = q('SELECT * FROM foster_volunteers WHERE user_id = ?', [$u['user_id']])->fetch();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? 'save';
    if ($act === 'withdraw') {
        $n = q("UPDATE case_offers SET status = 'withdrawn' WHERE offer_id = ? AND user_id = ? AND status = 'offered'", [(int)($_POST['offer_id'] ?? 0), $u['user_id']])->rowCount();
        flash($n ? 'success' : 'error', $n ? 'Offer withdrawn.' : 'Only offers that are waiting for a reply can be withdrawn.'); redirect('foster.php');
    }
    $species = trim($_POST['species_ok'] ?? ''); $cap = (int)($_POST['capacity'] ?? 0); $avail = trim($_POST['availability'] ?? ''); $status = ($_POST['status'] ?? 'active') === 'paused' ? 'paused' : 'active';
    if ($species === '' || str_len($species) > 100) $error = 'Tell us which animals you can foster (up to 100 characters).';
    elseif ($cap < 1 || $cap > 20) $error = 'How many animals can you take at once? Enter a number from 1 to 20.';
    elseif (str_len($avail) > 255) $error = 'Availability must be 255 characters or fewer.';
    elseif (empty($_POST['consent'])) $error = 'Please tick the box to allow verified shelters to see your details.';
    else {
        q('INSERT INTO foster_volunteers (user_id, species_ok, capacity, medical_ok, availability, status) VALUES (?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE species_ok = VALUES(species_ok), capacity = VALUES(capacity), medical_ok = VALUES(medical_ok), availability = VALUES(availability), status = VALUES(status)',
          [$u['user_id'], $species, $cap, empty($_POST['medical_ok']) ? 0 : 1, $avail ?: null, $status]);
        flash('success', $vol ? 'Volunteer profile updated.' : 'You are now a foster volunteer. Browse the board and offer to help.'); redirect('board.php');
    }
}
$v = fn($k, $d = '') => e($_POST[$k] ?? ($vol[$k] ?? $d));
$offers = q('SELECT o.*, c.title, c.status AS case_status, s.shelter_name FROM case_offers o JOIN rescue_cases c ON c.case_id = o.case_id JOIN shelters s ON s.shelter_id = c.shelter_id WHERE o.user_id = ? ORDER BY o.created_at DESC LIMIT 20', [$u['user_id']])->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<h1>Foster volunteer profile</h1>
<p class="muted">Fostering gives a rescued animal a safe home until it is adopted. Tell shelters what you can offer.</p>
<?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
<div class="cols">
<form method="post" class="stack panel"><?= csrf_field() ?>
  <label>Animals you can foster<input name="species_ok" maxlength="100" value="<?= $v('species_ok') ?>" placeholder="e.g. Dogs, cats, puppies and kittens" required></label>
  <label>How many at once?<input type="number" name="capacity" min="1" max="20" value="<?= $v('capacity', '1') ?>" required></label>
  <label class="check"><input type="checkbox" name="medical_ok" value="1" <?= !empty($_POST) ? (!empty($_POST['medical_ok']) ? 'checked' : '') : (!empty($vol['medical_ok']) ? 'checked' : '') ?>> I can care for animals that need medication or recovery care.</label>
  <label>When are you available? (optional)<input name="availability" maxlength="255" value="<?= $v('availability') ?>" placeholder="e.g. Weekends, or for up to 3 months from November"></label>
  <label>Status<select name="status"><?php $cur = $_POST['status'] ?? ($vol['status'] ?? 'active'); foreach (['active' => 'Active: shelters can see me', 'paused' => 'Paused: not available right now'] as $k => $t): ?><option value="<?= $k ?>" <?= $cur === $k ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  <label class="check"><input type="checkbox" name="consent" value="1" <?= $vol ? 'checked' : '' ?> required> <span>I allow verified shelters to see this profile together with my name, email, mobile number and city.</span></label>
  <button class="btn"><?= $vol ? 'Save changes' : 'Become a foster volunteer' ?></button>
</form>
<div><h2>My offers</h2>
<?php if (!$offers): ?><div class="empty"><p>You have not offered to help yet. <a href="<?= url('board.php') ?>">See the board</a>.</p></div><?php endif; ?>
<?php foreach ($offers as $o): ?><article class="panel"><div class="split"><strong><?= e($o['title']) ?></strong><?= badge($o['status'] === 'offered' ? 'pending' : ($o['status'] === 'accepted' ? 'approved' : ($o['status'] === 'declined' ? 'rejected' : 'withdrawn'))) ?></div>
  <p class="small muted"><?= e($o['shelter_name']) ?> &middot; <?= fdate($o['created_at']) ?> &middot; <?= e(ucfirst($o['status'])) ?></p>
  <?php if ($o['status'] === 'offered'): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="withdraw"><input type="hidden" name="offer_id" value="<?= $o['offer_id'] ?>"><button class="btn btn-sm btn-ghost" data-confirm="Withdraw this offer?">Withdraw</button></form><?php endif; ?></article><?php endforeach; ?>
</div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
