<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Foster & rescue board'; $page = 'sboard'; $errors = []; $sid = (int)$u['shelter_id'];
// Foster and emergency-rescue board: post urgent cases, review volunteer offers. It builds on announcements & donations:
// a case can link one of your donation requests and can also be published as an announcement.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? 'create';
    if ($act === 'create') {
        $f = fn($k) => trim($_POST[$k] ?? '');
        $type = $f('case_type'); $urg = $f('urgency'); $weeks = (int)$f('duration_weeks'); $by = $f('needed_by');
        if (!in_array($type, ['emergency_rescue', 'foster_needed'], true)) $errors[] = 'Choose the type of case.';
        if (!in_array($urg, ['critical', 'high', 'normal'], true)) $errors[] = 'Choose how urgent it is.';
        if ($f('title') === '' || str_len($f('title')) > 150) $errors[] = 'Give the case a title (up to 150 characters).';
        if (str_len($f('description')) < 20 || str_len($f('description')) > 2000) $errors[] = 'Describe the case in 20 to 2000 characters.';
        if (str_len($f('needs')) > 255 || str_len($f('species')) > 40) $errors[] = 'Needs (255) and species (40) are too long.';
        if ($by !== '' && !(DateTime::createFromFormat('Y-m-d', $by) && $by >= date('Y-m-d'))) $errors[] = 'The needed-by date must be today or later.';
        if ($weeks < 0 || $weeks > 104) $errors[] = 'Foster length must be between 1 and 104 weeks.';
        $petId = (int)$f('pet_id'); if ($petId && !q("SELECT 1 FROM pets WHERE pet_id = ? AND shelter_id = ? AND status <> 'removed'", [$petId, $sid])->fetch()) $errors[] = 'That pet is not in your shelter.';
        $postId = (int)$f('donation_post_id'); if ($postId && !q("SELECT 1 FROM announcements_donations WHERE post_id = ? AND shelter_id = ? AND status = 'published'", [$postId, $sid])->fetch()) $errors[] = 'That donation request was not found.';
        if (!$errors) {
            q('INSERT INTO rescue_cases (shelter_id, posted_by, case_type, urgency, title, description, species, needs, needed_by, duration_weeks, pet_id, donation_post_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
              [$sid, $u['user_id'], $type, $urg, $f('title'), $f('description'), $f('species') ?: null, $f('needs') ?: null, $by ?: null, $weeks ?: null, $petId ?: null, $postId ?: null]);
            if (!empty($_POST['announce']))      // re-use the announcements feature so the case also appears there
                q('INSERT INTO announcements_donations (shelter_id, posted_by, post_type, title, content) VALUES (?,?,?,?,?)',
                  [$sid, $u['user_id'], 'announcement', ($urg === 'normal' ? '' : ($urg === 'critical' ? 'CRITICAL: ' : 'URGENT: ')) . $f('title'), cut_text($f('description'), 1500) . "\n\nSee the Foster & rescue board to help."]);
            // tell active volunteers who said they can take this kind of animal (in-app only: no email blast)
            $vols = q("SELECT v.user_id, v.species_ok FROM foster_volunteers v JOIN users x ON x.user_id = v.user_id WHERE v.status = 'active' AND x.account_status = 'active'")->fetchAll();
            $sp = strtolower($f('species'));
            foreach ($vols as $v) if ($sp === '' || stripos($v['species_ok'], rtrim($sp, 's')) !== false)
                notify_user((int)$v['user_id'], 'case', ($urg === 'normal' ? '' : 'Urgent: ') . $f('title'), $u['shelter_name'] . ' needs ' . ($type === 'foster_needed' ? 'a foster home.' : 'rescue help.'), 'board.php');
            flash('success', 'Posted to the board.'); redirect('staff/board.php');
        }
    } elseif ($act === 'offer') {
        $o = q('SELECT o.*, c.shelter_id, c.title, x.first_name, x.last_name, x.email FROM case_offers o JOIN rescue_cases c ON c.case_id = o.case_id JOIN users x ON x.user_id = o.user_id WHERE o.offer_id = ? AND c.shelter_id = ?', [(int)($_POST['offer_id'] ?? 0), $sid])->fetch();
        $to = $_POST['decision'] ?? '';
        if (!$o || $o['status'] !== 'offered' || !in_array($to, ['accepted', 'declined'], true)) flash('error', 'That offer was already handled.');
        else {
            q('UPDATE case_offers SET status = ? WHERE offer_id = ?', [$to, $o['offer_id']]);
            $subj = $to === 'accepted' ? 'Your offer to help was accepted' : 'Update on your offer to help';
            send_mail_later($o['email'], $subj, mail_layout($subj, '<p>Hi ' . e($o['first_name']) . ',</p><p><b>' . e($u['shelter_name']) . '</b> ' . ($to === 'accepted' ? 'accepted your offer for <b>' . e($o['title']) . '</b>. They will contact you on the details in your profile. Thank you!' : 'is not able to use your offer for <b>' . e($o['title']) . '</b> this time. Thank you for stepping up; please watch the board for other needs.') . '</p>' . mail_button('See the board', 'board.php'),
                shelter_sender(['shelter_id' => $sid, 'shelter_name' => $u['shelter_name'], 'logo' => $u['shelter_logo'] ?? null], $u)));
            notify_user((int)$o['user_id'], 'offer', $subj, $o['title'], 'foster.php');
            flash('success', 'Volunteer notified.');
        }
        redirect('staff/board.php');
    } else {
        $id = (int)($_POST['id'] ?? 0); $map = ['filled' => 'filled', 'close' => 'closed', 'reopen' => 'open'];
        if (isset($map[$act])) q("UPDATE rescue_cases SET status = ? WHERE case_id = ? AND shelter_id = ? AND status <> 'hidden'", [$map[$act], $id, $sid]);
        if ($act === 'delete') q('DELETE FROM rescue_cases WHERE case_id = ? AND shelter_id = ?', [$id, $sid]);
        flash('success', 'Case updated.'); redirect('staff/board.php');
    }
}
$cases = q('SELECT c.* FROM rescue_cases c WHERE c.shelter_id = ? ORDER BY FIELD(c.status,\'open\',\'filled\',\'closed\',\'hidden\'), c.created_at DESC', [$sid])->fetchAll();
$offers = [];
if ($cases) foreach (q('SELECT o.*, x.first_name, x.last_name, x.email, x.contact_number, x.city, x.profile_photo, v.species_ok, v.capacity, v.medical_ok, v.availability FROM case_offers o JOIN users x ON x.user_id = o.user_id
        LEFT JOIN foster_volunteers v ON v.user_id = o.user_id WHERE o.status <> \'withdrawn\' AND o.case_id IN (' . implode(',', array_map('intval', array_column($cases, 'case_id'))) . ') ORDER BY o.created_at')->fetchAll() as $o) $offers[$o['case_id']][] = $o;
$myPets = q("SELECT pet_id, pet_name, species FROM pets WHERE shelter_id = ? AND status <> 'removed' ORDER BY pet_name", [$sid])->fetchAll();
$donPosts = q("SELECT post_id, title FROM announcements_donations WHERE shelter_id = ? AND post_type = 'donation' AND status = 'published' ORDER BY created_at DESC", [$sid])->fetchAll();
$volunteers = q("SELECT x.first_name, x.last_name, x.email, x.contact_number, x.city, v.species_ok, v.capacity, v.medical_ok, v.availability FROM foster_volunteers v JOIN users x ON x.user_id = v.user_id
                 WHERE v.status = 'active' AND x.account_status = 'active' ORDER BY (x.city = ?) DESC, v.created_at DESC LIMIT 30", [$u['shelter_city'] ?? ''])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Foster &amp; emergency rescue board</h1>
<p class="muted">Post urgent cases and foster needs. Registered volunteers who can take that kind of animal get a notification, and the public board shows your case with a link to its donation request.</p>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<div class="cols">
<form method="post" class="stack panel"><?= csrf_field() ?><input type="hidden" name="action" value="create"><h2>New case</h2>
  <div class="two"><label>Type<select name="case_type"><?php foreach (['foster_needed' => 'Foster home needed', 'emergency_rescue' => 'Emergency rescue'] as $k => $t): ?><option value="<?= $k ?>" <?= ($_POST['case_type'] ?? '') === $k ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  <label>Urgency<select name="urgency"><?php foreach (['normal' => 'Needed soon', 'high' => 'Urgent', 'critical' => 'Critical (today)'] as $k => $t): ?><option value="<?= $k ?>" <?= ($_POST['urgency'] ?? '') === $k ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label></div>
  <label>Title<input name="title" maxlength="150" value="<?= old('title') ?>" placeholder="e.g. Injured dog found near the highway" required></label>
  <label>What happened and what is needed<textarea name="description" rows="5" maxlength="2000" required><?= old('description') ?></textarea></label>
  <div class="two"><label>Animal (species)<input name="species" maxlength="40" value="<?= old('species') ?>" placeholder="Dog, Cat..."></label>
  <label>Needed by (optional)<input type="date" name="needed_by" min="<?= date('Y-m-d') ?>" value="<?= old('needed_by') ?>"></label></div>
  <div class="two"><label>Foster length in weeks (optional)<input type="number" name="duration_weeks" min="1" max="104" value="<?= old('duration_weeks') ?>"></label>
  <label>Supplies or care needed<input name="needs" maxlength="255" value="<?= old('needs') ?>" placeholder="Crate, food, vet transport..."></label></div>
  <div class="two"><label>Link a pet (optional)<select name="pet_id"><option value="">None</option><?php foreach ($myPets as $p): ?><option value="<?= $p['pet_id'] ?>" <?= (int)($_POST['pet_id'] ?? 0) === (int)$p['pet_id'] ? 'selected' : '' ?>><?= e($p['pet_name'] . ' (' . $p['species'] . ')') ?></option><?php endforeach; ?></select></label>
  <label>Link a donation request (optional)<select name="donation_post_id"><option value="">None</option><?php foreach ($donPosts as $d): ?><option value="<?= $d['post_id'] ?>"><?= e($d['title']) ?></option><?php endforeach; ?></select><span class="hint">Create one under Posts first.</span></label></div>
  <label class="check"><input type="checkbox" name="announce" value="1"> Also publish this as an announcement</label>
  <button class="btn">Post to the board</button>
</form>
<div><h2>Your cases</h2>
<?php if (!$cases): ?><div class="empty"><p>No cases yet.</p></div><?php endif; ?>
<?php foreach ($cases as $c): $os = $offers[$c['case_id']] ?? []; ?>
<article class="panel"><div class="split"><strong><?= e($c['title']) ?></strong><span><?= badge($c['status']) ?></span></div>
  <p class="small muted"><?= $c['case_type'] === 'foster_needed' ? 'Foster needed' : 'Emergency rescue' ?> &middot; <?= e(['critical' => 'Critical', 'high' => 'Urgent', 'normal' => 'Needed soon'][$c['urgency']]) ?> &middot; <?= fdate($c['created_at']) ?> &middot; <?= count($os) ?> offer<?= count($os) === 1 ? '' : 's' ?></p>
  <?php foreach ($os as $o): ?><div class="about"><?= avatar($o) ?><div><p><strong><?= e($o['first_name'] . ' ' . $o['last_name']) ?></strong> <?= badge($o['status'] === 'offered' ? 'pending' : ($o['status'] === 'accepted' ? 'approved' : 'rejected')) ?></p>
    <p class="small"><?= e($o['email']) ?> &middot; <?= e($o['contact_number']) ?><?= $o['city'] ? ' &middot; ' . e($o['city']) : '' ?></p>
    <?php if ($o['species_ok']): ?><p class="small">Can foster: <?= e($o['species_ok']) ?> (up to <?= (int)$o['capacity'] ?>)<?= $o['medical_ok'] ? ', can do medical care' : '' ?><?= $o['availability'] ? '. ' . e($o['availability']) : '' ?></p><?php endif; ?>
    <?php if ($o['message']): ?><p class="quote"><?= nl2br(e($o['message'])) ?></p><?php endif; ?>
    <?php if ($o['status'] === 'offered'): ?><form method="post" class="actions"><?= csrf_field() ?><input type="hidden" name="action" value="offer"><input type="hidden" name="offer_id" value="<?= $o['offer_id'] ?>">
      <button class="btn btn-sm" name="decision" value="accepted">Accept</button><button class="btn btn-sm btn-ghost" name="decision" value="declined">Decline</button></form><?php endif; ?></div></div><?php endforeach; ?>
  <form method="post" class="inline-actions"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['case_id'] ?>">
    <?php if ($c['status'] === 'open'): ?><button class="btn btn-sm" name="action" value="filled">Mark as filled</button><button class="btn btn-sm btn-ghost" name="action" value="close">Close</button>
    <?php elseif ($c['status'] !== 'hidden'): ?><button class="btn btn-sm btn-ghost" name="action" value="reopen">Reopen</button><?php endif; ?>
    <button class="btn btn-sm btn-danger" name="action" value="delete" data-confirm="Delete this case and its offers?">Delete</button></form></article>
<?php endforeach; ?></div></div>
<h2>Registered foster volunteers</h2>
<?php if (!$volunteers): ?><p class="muted">No volunteers have registered yet. Your public board posts invite them.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Volunteer</th><th>City</th><th>Can foster</th><th>Capacity</th><th>Contact</th></tr></thead><tbody>
<?php foreach ($volunteers as $v): ?><tr><td><?= e($v['first_name'] . ' ' . $v['last_name']) ?></td><td><?= e($v['city'] ?: '-') ?></td><td><?= e($v['species_ok']) ?><?= $v['medical_ok'] ? ' (medical OK)' : '' ?></td><td><?= (int)$v['capacity'] ?></td><td class="small"><?= e($v['email']) ?><br><?= e($v['contact_number']) ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
