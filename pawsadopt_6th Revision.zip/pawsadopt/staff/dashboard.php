<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = require_role('staff');
$title = 'Shelter dashboard'; $page = 'dash';
$stats = null;
$noResp = [];
if (shelter_ready($u)) {
    $sid = $u['shelter_id'];
    followups_flag_no_response((int)$sid); $noResp = followups_no_response((int)$sid);
    $stats = [
        'Available pets' => q("SELECT COUNT(*) FROM pets WHERE shelter_id=? AND status='available'", [$sid])->fetchColumn(),
        'Pending inquiries' => q("SELECT COUNT(*) FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id WHERE p.shelter_id=? AND i.status='pending'", [$sid])->fetchColumn(),
        'Adopted' => q("SELECT COUNT(*) FROM pets WHERE shelter_id=? AND status='adopted'", [$sid])->fetchColumn(),
        'Drafts (no photo yet)' => q("SELECT COUNT(*) FROM pets WHERE shelter_id=? AND status='draft'", [$sid])->fetchColumn(),
        'Active posts' => q("SELECT COUNT(*) FROM announcements_donations WHERE shelter_id=? AND status='published'", [$sid])->fetchColumn(),
    ];
}
include __DIR__ . '/../includes/header.php';
?>
<h1>Shelter dashboard</h1>
<?php if (!$u['shelter_id']): ?>
  <div class="panel"><h2>Register your shelter</h2><p>Before you can list pets, an administrator must verify your shelter. Submit its details and a verification document.</p>
  <a class="btn" href="<?= url('staff/shelter.php') ?>">Register shelter profile</a></div>
<?php elseif ($u['verification_status'] === 'pending'): ?>
  <div class="panel"><h2><?= e($u['shelter_name']) ?> <?= badge('pending') ?></h2><p>Your shelter is waiting for administrator review. You can list pets as soon as it is approved.</p></div>
<?php elseif ($u['verification_status'] === 'rejected'): ?>
  <div class="panel"><h2><?= e($u['shelter_name']) ?> <?= badge('rejected') ?></h2><p><strong>Reason:</strong> <?= e($u['rejection_reason']) ?></p>
  <a class="btn" href="<?= url('staff/shelter.php') ?>">Update and resubmit</a></div>
<?php elseif ($u['shelter_status'] === 'suspended'): ?>
  <div class="panel"><h2><?= e($u['shelter_name']) ?> <?= badge('suspended') ?></h2><p>Your shelter is suspended by an administrator. Its listings are hidden from the public.</p>
  <?php $susp = q('SELECT suspension_reason FROM shelters WHERE shelter_id=?', [$u['shelter_id']])->fetchColumn(); if ($susp): ?><p><strong>Reason:</strong> <?= e($susp) ?></p><?php endif; ?>
  <a class="btn" href="<?= url('staff/petition.php') ?>"><?= !empty($u['is_shelter_admin']) ? 'Request reactivation' : 'View reactivation status' ?></a></div>
<?php else: ?>
  <p class="muted"><?= e($u['shelter_name']) ?> <?= badge('approved') ?> <?php if (!empty($u['is_shelter_admin'])): ?>&middot; <a href="<?= url('staff/shelter.php') ?>">Edit shelter details</a><?php endif; ?></p>
  <?php if (!q('SELECT city FROM shelters WHERE shelter_id=?', [$u['shelter_id']])->fetchColumn()): ?><div class="flash flash-info">Add your city and province so adopters can find your pets by location. <a href="<?= url('staff/shelter.php') ?>">Update shelter details</a></div><?php endif; ?>
  <?php if (!empty($u['is_shelter_admin']) && !has_pin(q('SELECT latitude, longitude FROM shelters WHERE shelter_id=?', [$u['shelter_id']])->fetch() ?: [])): ?><div class="flash flash-info">Your shelter has no exact map pin yet, so adopters only see an approximate location. <a href="<?= url('staff/shelter.php') ?>">Set your pin</a></div><?php endif; ?>
  <p class="small muted"><a href="<?= url('shelter.php?id=' . (int)$u['shelter_id']) ?>">View your public profile</a><?php if (!empty($u['is_shelter_admin'])): ?> &middot; <a href="<?= url('staff/team.php') ?>">Manage employee accounts</a> (employees cannot sign up on their own; you create their accounts and give them their credentials)<?php endif; ?></p>
  <?php if ($noResp): ?><div class="flash flash-error"><strong><?= count($noResp) ?> adoption<?= count($noResp) === 1 ? '' : 's' ?> with no response.</strong> The adopter<?= count($noResp) === 1 ? '' : 's' ?> of <?= e(implode(', ', array_slice(array_column($noResp, 'pet_name'), 0, 3))) ?><?= count($noResp) > 3 ? ' and more' : '' ?> did not answer any of the three check-ins. We suggest a welfare call or visit. <a href="<?= url('staff/followups.php?s=noresponse') ?>">Review now</a></div><?php endif; ?>
  <div class="stats"><?php foreach ($stats as $k => $v): ?><div class="stat"><b><?= (int)$v ?></b><span><?= e($k) ?></span></div><?php endforeach; ?></div>
  <div class="actions"><a class="btn" href="<?= url('staff/pet_form.php') ?>">List a new pet</a> <a class="btn btn-ghost" href="<?= url('staff/inquiries.php') ?>">Review inquiries</a> <a class="btn btn-ghost" href="<?= url('staff/posts.php') ?>">Post an announcement</a> <a class="btn btn-ghost" href="<?= url('staff/board.php') ?>">Rescue &amp; foster board</a></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
