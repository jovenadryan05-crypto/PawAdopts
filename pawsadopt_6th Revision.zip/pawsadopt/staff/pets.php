<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved before you can manage listings.'); redirect('staff/dashboard.php'); }
$title = 'Pet listings'; $page = 'pets';
// UC-07 Manage pet listings: quick status change / remove
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $own = q("SELECT 1 FROM pets WHERE pet_id=? AND shelter_id=? AND status<>'removed'", [$id, $u['shelter_id']])->fetch();
    if ($own) { set_pet_status($id, 'removed'); flash('success', 'Listing removed. Open inquiries for it were closed.'); }
    else flash('error', 'No change made.');
    redirect('staff/pets.php');
}
$pets = q("SELECT p.*, (SELECT COUNT(*) FROM pet_photos ph WHERE ph.pet_id=p.pet_id) AS photo_count, (SELECT photo_url FROM pet_photos WHERE pet_id=p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo,
           (SELECT COUNT(*) FROM adoption_inquiries i WHERE i.pet_id=p.pet_id AND i.status='pending') AS open_inq
           FROM pets p WHERE p.shelter_id=? ORDER BY p.created_at DESC", [$u['shelter_id']])->fetchAll();
$dups = []; $drafts = 0;
foreach ($pets as $p) { if ($p['status'] === 'draft') $drafts++; if ($p['status'] !== 'removed' && $p['status'] !== 'adopted') $dups[$p['pet_id']] = pet_duplicates((int)$p['pet_id']); }
include __DIR__ . '/../includes/header.php';
?>
<div class="split"><h1>Pet listings</h1><a class="btn" href="<?= url('staff/pet_form.php') ?>">List a new pet</a></div>
<?php if ($drafts): ?><div class="flash flash-info"><strong><?= $drafts ?> listing<?= $drafts === 1 ? ' is' : 's are' ?> a draft.</strong> A pet needs at least one photo before it goes live, and drafts are hidden from adopters. Open <em>Edit</em> and add a photo.</div><?php endif; ?>
<?php if (!$pets): ?><div class="empty"><h2>No pets listed yet</h2><p>Add your first animal with a photo so adopters can find it.</p></div><?php else: ?>
<div class="table-wrap"><table>
<thead><tr><th>Pet</th><th>Details</th><th>Status</th><th>Photos</th><th>Open inquiries</th><th></th></tr></thead><tbody>
<?php foreach ($pets as $p): ?>
<tr>
  <td class="who"><span class="mini"><?php if ($p['photo']): ?><img src="<?= url($p['photo']) ?>" alt=""><?php else: ?>&#128062;<?php endif; ?></span><a href="<?= url('pet.php?id=' . $p['pet_id']) ?>"><?= e($p['pet_name']) ?></a></td>
  <td><?= e($p['species']) ?><?= $p['breed'] ? ' / ' . e($p['breed']) : '' ?> &middot; <?= e(ucfirst($p['sex'])) ?> &middot; <?= age_label((int)$p['age_months']) ?></td>
  <td><?= badge($p['status']) ?></td>
  <td><?= (int)$p['photo_count'] ?: '<span class="badge b-rejected">No photo</span>' ?><?php foreach ($dups[$p['pet_id']] ?? [] as $w): ?><div class="small warn-text"><?= e($w) ?></div><?php endforeach; ?></td>
  <td><?= (int)$p['open_inq'] ?></td>
  <td class="row-actions">
    <a class="btn btn-sm btn-ghost" href="<?= url('staff/pet_form.php?id=' . $p['pet_id']) ?>">Edit</a>
    <?php if ($p['status'] !== 'removed'): ?>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['pet_id'] ?>">
      <button class="btn btn-sm btn-danger" data-confirm="Remove this listing from the site?">Remove</button></form>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
