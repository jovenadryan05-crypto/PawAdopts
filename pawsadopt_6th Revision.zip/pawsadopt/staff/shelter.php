<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
$title = 'Shelter profile'; $page = 'dash'; $errors = [];
$shelter = $u['shelter_id'] ? q('SELECT * FROM shelters WHERE shelter_id=?', [$u['shelter_id']])->fetch() : null;
if ($shelter && $shelter['verification_status'] === 'pending') { flash('info', 'Your shelter is already awaiting review.'); redirect('staff/dashboard.php'); }

// Only the shelter administrator edits the shelter. Employees do not register or join on their own: the administrator creates their accounts (staff/team.php).
if ($shelter && empty($u['is_shelter_admin'])) { flash('info', 'Only your shelter administrator can edit the shelter details.'); redirect('staff/dashboard.php'); }

// UC-05 Register shelter profile (also used to edit details or resubmit after rejection)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    $phone = ph_contact($f('contact_number'));
    if ($f('shelter_name') === '' || $f('address') === '') $errors[] = 'Shelter name and address are required.';
    if ($f('city') === '' || $f('province') === '') $errors[] = 'City and province are required, so adopters can find your pets by location.';
    if (str_len($f('city')) > 80 || str_len($f('province')) > 80) $errors[] = 'City and province must be 80 characters or fewer.';
    if (!filter_var($f('contact_email'), FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid shelter email.';
    if (!$phone) $errors[] = 'Enter a Philippine mobile number (09XXXXXXXXX) or a landline with area code (e.g. 02 8123 4567).';
    [$lat, $lng, $pinErr] = pin_from_post($_POST['pin'] ?? '');
    if ($pinErr) $errors[] = $pinErr;
    elseif ($lat === null) $errors[] = 'Set the exact map pin of your shelter, so adopters can find you.';
    $doc = null;
    if (!$errors) {
        $doc = save_upload($_FILES['document'] ?? [], 'docs', true);
        if (!$doc && !$shelter) $errors[] = 'Upload a verification document (business permit, registration or similar).';
        if (!$doc && $shelter && !empty($_FILES['document']['name'])) $errors[] = 'The document could not be saved.';
    }
    if (!$errors) {
        if (!$shelter) {
            q('INSERT INTO shelters (shelter_name,address,city,province,latitude,longitude,contact_email,contact_number,verification_documents,invite_code) VALUES (?,?,?,?,?,?,?,?,?,?)',
              [$f('shelter_name'), $f('address'), $f('city'), $f('province'), $lat, $lng, $f('contact_email'), $phone, $doc, strtoupper(bin2hex(random_bytes(4)))]);
            q('UPDATE users SET shelter_id=?, is_shelter_admin=1, position=COALESCE(position, \'Shelter administrator\') WHERE user_id=?', [db()->lastInsertId(), $u['user_id']]);
            notify_users(admin_ids(), 'shelter_review', 'New shelter awaiting review', $f('shelter_name'), 'admin/shelters.php');
            flash('success', 'Shelter submitted for verification.');
        } else {
            $resubmit = (int)($shelter['verification_status'] === 'rejected');
            $logo = save_upload($_FILES['logo'] ?? [], 'logos', false, 400);              // shelter logo / photo, cropped square (also shown in emails)
            if ($logo) { delete_public_file($shelter['logo']); q('UPDATE shelters SET logo=? WHERE shelter_id=?', [$logo, $shelter['shelter_id']]); }
            q('UPDATE shelters SET about=? WHERE shelter_id=?', [$f('about') ?: null, $shelter['shelter_id']]);
            q('UPDATE shelters SET latitude=?, longitude=?, shelter_name=?, address=?, contact_email=?, contact_number=?, city=?, province=?, verification_documents=COALESCE(?, verification_documents),
               verification_status = IF(?, "pending", verification_status), rejection_reason = IF(?, NULL, rejection_reason), reviewed_by = IF(?, NULL, reviewed_by), reviewed_at = IF(?, NULL, reviewed_at)
               WHERE shelter_id=?', [$lat, $lng, $f('shelter_name'), $f('address'), $f('contact_email'), $phone, $f('city'), $f('province'), $doc, $resubmit, $resubmit, $resubmit, $resubmit, $shelter['shelter_id']]);
            flash('success', $resubmit ? 'Shelter resubmitted for verification.' : 'Shelter details updated.');
        }
        redirect('staff/dashboard.php');
    }
}
$v = fn($k) => e($_POST[$k] ?? ($shelter[$k] ?? ''));
include __DIR__ . '/../includes/header.php';
?>
<h1><?= $shelter ? 'Edit shelter details' : 'Register your shelter' ?></h1>
<?php if ($shelter && $shelter['verification_status'] === 'rejected'): ?><div class="flash flash-error">Rejected: <?= e($shelter['rejection_reason']) ?>. Fix the details and resubmit.</div><?php endif; ?>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="stack panel narrow-form"><?= csrf_field() ?>
  <label>Shelter name<input name="shelter_name" value="<?= $v('shelter_name') ?>" required></label>
  <label>Street address<input name="address" value="<?= $v('address') ?>" required></label>
  <div class="two"><label>City or municipality<input name="city" maxlength="80" value="<?= $v('city') ?>" required></label>
  <label>Province<input name="province" maxlength="80" value="<?= $v('province') ?>" required></label></div>
  <p class="hint">Your pets inherit this location, so you never retype it for each listing.</p>
  <?= pin_field($_POST["pin"] ?? (is_array($shelter) && has_pin($shelter) ? pin_text($shelter) : "")) ?>
  <div class="two"><label>Contact email<input type="email" name="contact_email" value="<?= $v('contact_email') ?>" required></label>
  <label>Contact number<input type="tel" name="contact_number" value="<?= $v('contact_number') ?>" inputmode="numeric" maxlength="13" placeholder="09XXXXXXXXX" required><span class="hint">Mobile (09XXXXXXXXX) or landline with area code.</span></label></div>
  <label>Verification document (PDF, JPG, PNG; max 5 MB)<input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png,.webp" <?= $shelter ? '' : 'required' ?>></label>
  <?php if ($shelter): ?><p class="small muted">Leave the file empty to keep the document already on file.</p><?php endif; ?>
  <?php if ($shelter): ?>
  <label>About your shelter (shown on your public profile)<textarea name="about" rows="5" maxlength="1500" placeholder="Your story, how you rescue and care for animals, how adoption works with you."><?= $v('about') ?></textarea></label>
  <label>Shelter logo or photo (JPG, PNG, WEBP; max 5 MB)<input type="file" name="logo" accept="image/*"><span class="hint">Shown on your profile and in emails PawsAdopt sends on your behalf.</span></label>
  <?php endif; ?>
  <button class="btn"><?= $shelter && $shelter['verification_status'] === 'rejected' ? 'Resubmit for verification' : ($shelter ? 'Save changes' : 'Submit for verification') ?></button>
</form>
<?php if (!$shelter): ?><p class="muted">Registering a shelter makes you its administrator. You can then create accounts for your employees.</p><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
