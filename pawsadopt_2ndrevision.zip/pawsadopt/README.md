# PawsAdopt: Pet Adoption System (PHP + MySQL + CSS + JS)

Built from the project's UML use case, Level 0 DFD, class diagram and ERD.
Plain PHP 8+ with PDO, MySQL/MariaDB, vanilla CSS and JS. PHPMailer is bundled (includes/PHPMailer).

## Fresh install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\pawsadopt`.
2. Copy `config/config.example.php` to `config/config.php` and edit it (database, BASE_URL, email).
3. Start Apache and MySQL. In phpMyAdmin > Import, choose `database/schema.sql`
   (WARNING: it starts with DROP DATABASE, so only use it on a fresh install).
4. Make sure `extension=gd` is enabled in `php.ini` (it is by default in XAMPP). Photos are re-encoded with GD.
5. Visit http://localhost/pawsadopt
   Default admin: `admin@pawsadopt.local` / `Admin@12345`. You are forced to change it at first login.

## Updating an existing install (batch 1: security, logic, PH validation)
1. **Back up first**: phpMyAdmin > pawsadopt > Export.
2. phpMyAdmin > pawsadopt > SQL: paste and run `database/migrations/001_security_and_validation.sql`
   (do NOT import schema.sql; it would erase your data). The last query lists contact numbers that still need fixing.
3. Unzip this package over your project folder. `config/config.php` is not in the package, so your settings are kept.
   Optionally add the new settings shown in `config/config.example.php` (APP_DEBUG, SESSION_IDLE, PRIVATE_DIR).
4. Existing verification documents keep working (they are read from their old folder). New ones are stored outside htdocs.

## What changed in batch 1
**Security**
- Login lockout: 5 failed attempts per account (25 per IP) blocks for 15 minutes. Reset-code requests, sign-ups and invite-code tries are rate limited too (table `rate_limits`).
- Forced password change for the default admin; password policy (8-72 chars, letter + number) everywhere.
- Changing or resetting a password signs out the user's other devices (`users.session_version`); 30-minute idle timeout.
- One-time-code password reset: 6-digit code, stored hashed, 10 minutes, 5 tries, single use, neutral responses (no account guessing), max 3 requests/hour/account.
- Errors are logged to `logs/php_error.log`, never shown (set APP_DEBUG=true only while developing). Security headers (CSP, X-Frame-Options, nosniff, Referrer-Policy; HSTS on HTTPS). Cookies are HttpOnly + SameSite.
- Verification documents are stored outside the web root and streamed to admins only. Uploaded photos are re-encoded (EXIF/GPS and hidden code removed), resized to 1600px, and size-limited.
- Admin audit log (`admin_audit_log`, page: Admin > Audit log). Emails to shelters on approval/rejection.
- Least-privilege database user: `database/create_app_user.sql`.

**Logic**
- DB-level unique keys: one active inquiry per adopter+pet, one approved inquiry per pet (blocks double-clicks and races).
- `set_pet_status()` is the single place pet status changes; marking a pet adopted or removing a listing closes the affected inquiries. A pet cannot be set back to available while an approval exists; staff can revoke an approval.
- Staff can only approve while the pet is available. Dates use Asia/Manila. Admin lists are paginated.
- Shelters get an invite code so more than one staff member can join (the ERD allows 1..*).
- Sign-up requires confirming age 18+. Donation posts show the shelter's contact and a "no payments handled here" notice.

**PH contact numbers**: mobile numbers must be 11 digits starting with 09 (spaces, dashes and +63 are normalized). Shelters may also use a landline with area code. Enforced on the server and in the form.

## Use case coverage
| UC | Feature | File |
|----|---------|------|
| 01 | Register account | register.php |
| 02 | Log in / out | login.php, logout.php |
| 03 | Reset password (emailed code) | forgot_password.php, reset_password.php |
| 04 | Manage profile | profile.php |
| 05 | Register shelter profile | staff/shelter.php |
| 06 | Approve or reject shelter | admin/shelters.php |
| 07 | Manage pet listings (+ photos) | staff/pets.php, staff/pet_form.php |
| 08 | Browse and search pets | index.php |
| 09 | View pet details | pet.php |
| 10 | Submit adoption inquiry | pet.php |
| 11 | View and withdraw inquiries | adopter/inquiries.php |
| 12 | Process adoption inquiries | staff/inquiries.php |
| 13 | Manage announcements & donations | staff/posts.php |
| 14 | View announcements & donations | announcements.php |
| 15 | Moderate content & manage accounts | admin/users.php, admin/moderation.php, admin/shelters.php, admin/audit.php |

## Email
Set MAIL_* in config.php (Gmail needs an App Password). If `MAIL_HOST` is left empty, emails are written to `logs/mail.log`
instead of being sent, which is handy while developing (reset codes appear there).

## Tables
The six DFD data stores (users, shelters, pets, pet_photos, adoption_inquiries, announcements_donations) plus three support
tables that are not business entities: `rate_limits`, `password_resets`, `admin_audit_log`. Add them to your ERD as "system/security tables".
