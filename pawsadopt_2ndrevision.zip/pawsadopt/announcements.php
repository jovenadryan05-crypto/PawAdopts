<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Announcements & donations'; $page = 'news';
// UC-14 View announcements & donations
$type = $_GET['type'] ?? '';
$where = "a.status IN ('published','closed') AND s.verification_status='approved' AND s.account_status='active'"; $args = [];
if (in_array($type, ['announcement', 'donation'], true)) { $where .= ' AND a.post_type = ?'; $args[] = $type; }
$posts = q("SELECT a.*, s.shelter_name, s.contact_email, s.contact_number FROM announcements_donations a JOIN shelters s ON s.shelter_id=a.shelter_id WHERE $where ORDER BY a.status='published' DESC, a.created_at DESC", $args)->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<h1>Announcements &amp; donation requests</h1>
<p class="muted">PawsAdopt does not collect or process donations. Always confirm a request with the shelter before sending money.</p>
<div class="tabs">
  <a class="<?= $type === '' ? 'on' : '' ?>" href="<?= url('announcements.php') ?>">All</a>
  <a class="<?= $type === 'announcement' ? 'on' : '' ?>" href="?type=announcement">Announcements</a>
  <a class="<?= $type === 'donation' ? 'on' : '' ?>" href="?type=donation">Donation requests</a>
</div>
<?php if (!$posts): ?><div class="empty"><h2>Nothing posted yet</h2><p>Shelters will share events and donation drives here.</p></div><?php endif; ?>
<div class="posts">
<?php foreach ($posts as $p): ?>
  <article class="post <?= $p['status'] === 'closed' ? 'closed' : '' ?>">
    <div class="post-head"><span class="badge b-<?= e($p['post_type']) ?>"><?= $p['post_type'] === 'donation' ? 'Donation request' : 'Announcement' ?></span>
      <?php if ($p['status'] === 'closed'): ?><?= badge('closed') ?><?php endif; ?></div>
    <h2><?= e($p['title']) ?></h2>
    <p class="prose"><?= nl2br(e($p['content'])) ?></p>
    <?php if ($p['post_type'] === 'donation' && $p['target_amount'] !== null): ?><p><strong>Target: &#8369;<?= number_format((float)$p['target_amount'], 2) ?></strong></p><?php endif; ?>
    <?php if ($p['post_type'] === 'donation'): ?><p class="small">To donate, contact <?= e($p['shelter_name']) ?> directly: <?= e($p['contact_email']) ?> &middot; <?= e($p['contact_number']) ?></p><?php endif; ?>
    <p class="small muted"><?= e($p['shelter_name']) ?> &middot; <?= fdate($p['created_at']) ?></p>
  </article>
<?php endforeach; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
