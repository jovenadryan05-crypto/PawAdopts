<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Reset password';
// UC-03 Reset password, step 1: email a 6-digit one-time code (hashed in the DB, valid 10 minutes)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(substr(trim($_POST['email'] ?? ''), 0, 150)); $ip = client_ip();
    if (filter_var($email, FILTER_VALIDATE_EMAIL) && !rate_blocked("reset:ip:$ip", 8, 3600) && !rate_blocked("reset:email:$email", 3, 3600)) {
        rate_hit("reset:ip:$ip"); rate_hit("reset:email:$email");
        $row = q("SELECT user_id, first_name FROM users WHERE email = ? AND account_status = 'active'", [$email])->fetch();
        if ($row) {
            $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            q('DELETE FROM password_resets WHERE user_id = ?', [$row['user_id']]);
            q('INSERT INTO password_resets (user_id, code_hash, expires_at) VALUES (?,?, NOW() + INTERVAL 10 MINUTE)', [$row['user_id'], password_hash($code, PASSWORD_DEFAULT)]);
            send_mail($email, 'Your PawsAdopt reset code',
                '<p>Hi ' . e($row['first_name']) . ',</p><p>Your password reset code is <b style="font-size:20px">' . $code . '</b>.</p>'
              . '<p>It expires in 10 minutes. If you did not ask for this, ignore this email.</p>');
        }
    }
    // Same response whether or not the email exists, and whether or not we were rate limited
    $_SESSION['reset_email'] = $email;
    flash('info', 'If that email is registered, a 6-digit code is on its way. It expires in 10 minutes.');
    redirect('reset_password.php');
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Forgot your password?</h1>
  <p class="muted">Enter your account email and we will send you a 6-digit code.</p>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label>Email<input type="email" name="email" required autofocus></label>
    <button class="btn">Send code</button>
  </form>
  <p class="muted"><a href="<?= url('login.php') ?>">Back to log in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
