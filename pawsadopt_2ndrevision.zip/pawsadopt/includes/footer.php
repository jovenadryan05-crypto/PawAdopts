</main>
<footer class="site-footer"><div class="wrap">PawsAdopt connects adopters with verified animal shelters. Adopt, don't shop.</div></footer>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
