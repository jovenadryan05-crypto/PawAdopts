<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION = [];
    session_destroy();
    session_start();
    flash('success', 'You have been logged out.');
}
redirect('login.php');
