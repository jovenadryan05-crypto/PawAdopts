<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('adopter');
$title = 'My inquiries'; $page = 'inq';
// UC-11 View and withdraw inquiries
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = q("UPDATE adoption_inquiries SET status='withdrawn' WHERE inquiry_id=? AND adopter_id=? AND status='pending'", [(int)($_POST['id'] ?? 0), $u['user_id']])->rowCount();
    flash($n ? 'success' : 'error', $n ? 'Inquiry withdrawn.' : 'Only pending inquiries can be withdrawn.');
    redirect('adopter/inquiries.php');
}
$rows = q('SELECT i.*, p.pet_name, p.species, s.shelter_name FROM adoption_inquiries i
           JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id
           WHERE i.adopter_id=? ORDER BY i.submitted_at DESC', [$u['user_id']])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>My inquiries</h1>
<?php if (!$rows): ?><div class="empty"><h2>No inquiries yet</h2><p>Find a pet you like and send the shelter a message. <a href="<?= url('index.php') ?>">Browse pets</a></p></div><?php endif; ?>
<?php foreach ($rows as $r): ?>
  <article class="panel inq">
    <div class="split"><h2><a href="<?= url('pet.php?id=' . $r['pet_id']) ?>"><?= e($r['pet_name']) ?></a> <span class="muted small"><?= e($r['species']) ?> at <?= e($r['shelter_name']) ?></span></h2><?= badge($r['status']) ?></div>
    <p class="small muted">Sent <?= fdate($r['submitted_at']) ?></p>
    <p class="quote"><?= nl2br(e($r['message'])) ?></p>
    <?php if ($r['responded_at']): ?>
      <div class="reply"><strong>Shelter response (<?= fdate($r['responded_at']) ?>)</strong><p><?= nl2br(e($r['response_message'] ?: 'No message provided.')) ?></p></div>
    <?php endif; ?>
    <?php if ($r['status'] === 'pending'): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
        <button class="btn btn-ghost" data-confirm="Withdraw this inquiry?">Withdraw inquiry</button></form>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
