-- Run ONCE on an existing PawsAdopt database (phpMyAdmin > pawsadopt > SQL). Safe to re-run on MariaDB/XAMPP.
-- Do NOT import schema.sql on a database you want to keep: it starts with DROP DATABASE.
USE pawsadopt;

-- 1. Accounts: forced password change + "log out everywhere" support
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS session_version INT NOT NULL DEFAULT 1;
UPDATE users SET must_change_password = 1 WHERE email = 'admin@pawsadopt.local';   -- default admin must set a new password

-- 2. Shelters: invite code so a second staff member can join an approved shelter
ALTER TABLE shelters ADD COLUMN IF NOT EXISTS invite_code CHAR(8) NULL;
UPDATE shelters SET invite_code = UPPER(SUBSTRING(MD5(RAND()), 1, 8)) WHERE invite_code IS NULL;
ALTER TABLE shelters ADD UNIQUE KEY IF NOT EXISTS uq_shelter_invite (invite_code);

-- 3. Database-level guards against duplicate inquiries and double approval
ALTER TABLE adoption_inquiries
  ADD COLUMN IF NOT EXISTS active_key VARCHAR(30) AS (IF(status IN ('pending','approved'), CONCAT(pet_id,'-',adopter_id), NULL)) VIRTUAL,
  ADD COLUMN IF NOT EXISTS approved_key INT AS (IF(status = 'approved', pet_id, NULL)) VIRTUAL;
ALTER TABLE adoption_inquiries
  ADD UNIQUE KEY IF NOT EXISTS uq_active_inquiry (active_key),
  ADD UNIQUE KEY IF NOT EXISTS uq_one_approved (approved_key);

-- 4. Support tables
CREATE TABLE IF NOT EXISTS rate_limits (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  bucket     VARCHAR(190) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bucket_time (bucket, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_resets (
  reset_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  code_hash  VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts   TINYINT NOT NULL DEFAULT 0,
  used_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admin_audit_log (
  log_id      INT AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT NULL,
  action      VARCHAR(60) NOT NULL,
  target_type VARCHAR(40) NOT NULL,
  target_id   INT NULL,
  details     VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_audit_time (created_at)
) ENGINE=InnoDB;

-- 5. Philippine contact numbers: convert +63 / 63 / spaced formats to 09XXXXXXXXX
UPDATE users SET contact_number = CONCAT('0', RIGHT(REGEXP_REPLACE(contact_number, '[^0-9]', ''), 10))
 WHERE REGEXP_REPLACE(contact_number, '[^0-9]', '') REGEXP '^(63)?9[0-9]{9}$';
UPDATE shelters SET contact_number = CONCAT('0', RIGHT(REGEXP_REPLACE(contact_number, '[^0-9]', ''), 10))
 WHERE REGEXP_REPLACE(contact_number, '[^0-9]', '') REGEXP '^(63)?9[0-9]{9}$';
-- Rows still not valid after the cleanup (their owners will be asked to fix them on next profile save):
SELECT 'users' AS tbl, user_id AS id, contact_number FROM users WHERE contact_number NOT REGEXP '^09[0-9]{9}$'
UNION ALL
SELECT 'shelters', shelter_id, contact_number FROM shelters WHERE contact_number NOT REGEXP '^(09[0-9]{9}|0[2-8][0-9]{7,9})$';
