-- Least-privilege database account for the website (do not run the site as root).
-- Run in phpMyAdmin > SQL, then set DB_USER / DB_PASS in config/config.php. Change the password first!
CREATE USER IF NOT EXISTS 'pawsadopt_app'@'localhost' IDENTIFIED BY 'ChangeThisStrongPassword!';
GRANT SELECT, INSERT, UPDATE, DELETE ON pawsadopt.* TO 'pawsadopt_app'@'localhost';
FLUSH PRIVILEGES;
