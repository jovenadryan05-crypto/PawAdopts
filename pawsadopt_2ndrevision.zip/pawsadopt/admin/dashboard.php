<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$title = 'Admin dashboard'; $page = 'dash';
$c = fn($sql) => (int)q($sql)->fetchColumn();
$stats = [
  'Shelters awaiting review' => $c("SELECT COUNT(*) FROM shelters WHERE verification_status='pending'"),
  'Approved shelters' => $c("SELECT COUNT(*) FROM shelters WHERE verification_status='approved'"),
  'Adopters' => $c("SELECT COUNT(*) FROM users WHERE role='adopter'"),
  'Shelter staff' => $c("SELECT COUNT(*) FROM users WHERE role='staff'"),
  'Available pets' => $c("SELECT COUNT(*) FROM pets WHERE status='available'"),
  'Adopted pets' => $c("SELECT COUNT(*) FROM pets WHERE status='adopted'"),
  'Open inquiries' => $c("SELECT COUNT(*) FROM adoption_inquiries WHERE status='pending'"),
  'Live posts' => $c("SELECT COUNT(*) FROM announcements_donations WHERE status='published'"),
];
include __DIR__ . '/../includes/header.php';
?>
<h1>Admin dashboard</h1>
<div class="stats"><?php foreach ($stats as $k => $v): ?><div class="stat"><b><?= $v ?></b><span><?= e($k) ?></span></div><?php endforeach; ?></div>
<?php if ($stats['Shelters awaiting review']): ?><div class="panel"><h2>Shelters need your review</h2><p><?= $stats['Shelters awaiting review'] ?> shelter(s) submitted documents for verification.</p><a class="btn" href="<?= url('admin/shelters.php') ?>">Review shelters</a></div><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
