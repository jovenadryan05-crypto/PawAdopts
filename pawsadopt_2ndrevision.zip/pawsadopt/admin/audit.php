<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$title = 'Audit log'; $page = 'audit';
[$pg, $pages, $off] = paginate((int)q('SELECT COUNT(*) FROM admin_audit_log')->fetchColumn(), 25);
$rows = q("SELECT l.*, CONCAT(u.first_name,' ',u.last_name) AS admin_name FROM admin_audit_log l LEFT JOIN users u ON u.user_id=l.admin_id ORDER BY l.log_id DESC LIMIT 25 OFFSET $off")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Audit log</h1>
<p class="muted">Every approval, rejection, suspension and moderation action taken by an administrator.</p>
<?php if (!$rows): ?><div class="empty"><p>No admin actions recorded yet.</p></div><?php else: ?>
<div class="table-wrap"><table>
<thead><tr><th>When</th><th>Administrator</th><th>Action</th><th>Target</th><th>Details</th><th>IP</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr>
  <td><?= e(date('M j, Y g:i A', strtotime($r['created_at']))) ?></td><td><?= e($r['admin_name'] ?: 'deleted user') ?></td>
  <td><?= e(str_replace('_', ' ', $r['action'])) ?></td><td><?= e($r['target_type'] . ($r['target_id'] ? ' #' . $r['target_id'] : '')) ?></td><td><?= e($r['details']) ?></td><td><?= e($r['ip']) ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?= pager($pg, $pages) ?>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
