<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
require_role('admin');
$title = 'Moderation'; $page = 'mod';
$tab = ($_GET['tab'] ?? 'pets') === 'posts' ? 'posts' : 'pets';
// UC-15 Moderate content: remove/restore pet listings, hide/publish posts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? '';
    if ($act === 'remove_pet') { set_pet_status($id, 'removed'); audit('pet_removed', 'pet', $id); }
    if ($act === 'restore_pet' && q("SELECT 1 FROM pets WHERE pet_id=? AND status='removed'", [$id])->fetch()) { set_pet_status($id, 'available'); audit('pet_restored', 'pet', $id); }
    if ($act === 'hide_post') { q("UPDATE announcements_donations SET status='hidden' WHERE post_id=?", [$id]); audit('post_hidden', 'post', $id); }
    if ($act === 'show_post') { q("UPDATE announcements_donations SET status='published' WHERE post_id=? AND status='hidden'", [$id]); audit('post_unhidden', 'post', $id); }
    flash('success', 'Moderation action applied.');
    redirect('admin/moderation.php?' . http_build_query(['tab' => $tab, 'p' => (int)($_GET['p'] ?? 1)]));
}
$table = $tab === 'pets' ? 'pets' : 'announcements_donations';
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM $table")->fetchColumn(), 20);
$pets = $tab === 'pets' ? q("SELECT p.*, s.shelter_name FROM pets p JOIN shelters s ON s.shelter_id=p.shelter_id ORDER BY p.created_at DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
$posts = $tab === 'posts' ? q("SELECT a.*, s.shelter_name FROM announcements_donations a JOIN shelters s ON s.shelter_id=a.shelter_id ORDER BY a.created_at DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
include __DIR__ . '/../includes/header.php';
?>
<h1>Content moderation</h1>
<div class="tabs"><a class="<?= $tab === 'pets' ? 'on' : '' ?>" href="?tab=pets">Pet listings</a><a class="<?= $tab === 'posts' ? 'on' : '' ?>" href="?tab=posts">Announcements &amp; donations</a></div>
<div class="table-wrap"><table>
<?php if ($tab === 'pets'): ?>
<thead><tr><th>Pet</th><th>Shelter</th><th>Listed</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($pets as $p): ?><tr>
  <td><a href="<?= url('pet.php?id=' . $p['pet_id']) ?>"><?= e($p['pet_name']) ?></a> <span class="muted small"><?= e($p['species']) ?></span></td><td><?= e($p['shelter_name']) ?></td><td><?= fdate($p['created_at']) ?></td><td><?= badge($p['status']) ?></td>
  <td class="row-actions"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['pet_id'] ?>">
    <?php if ($p['status'] !== 'removed'): ?><button class="btn btn-sm btn-danger" name="action" value="remove_pet" data-confirm="Remove this listing? Open inquiries will be closed.">Remove</button>
    <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="restore_pet">Restore</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php else: ?>
<thead><tr><th>Post</th><th>Shelter</th><th>Type</th><th>Posted</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($posts as $p): ?><tr>
  <td><?= e($p['title']) ?></td><td><?= e($p['shelter_name']) ?></td><td><?= e(ucfirst($p['post_type'])) ?></td><td><?= fdate($p['created_at']) ?></td><td><?= badge($p['status']) ?></td>
  <td class="row-actions"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['post_id'] ?>">
    <?php if ($p['status'] !== 'hidden'): ?><button class="btn btn-sm btn-danger" name="action" value="hide_post" data-confirm="Hide this post from the public?">Hide</button>
    <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="show_post">Unhide</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody></table></div>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
