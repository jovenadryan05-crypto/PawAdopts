<?php
// Streams a shelter's private verification document to admins only.
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$path = (string)q('SELECT verification_documents FROM shelters WHERE shelter_id=?', [(int)($_GET['id'] ?? 0)])->fetchColumn();
if (strpos($path, 'private/') === 0) { $base = realpath(PRIVATE_DIR); $file = $base ? realpath($base . '/' . substr($path, 8)) : false; }   // new location, outside the web root
else { $base = realpath(__DIR__ . '/../uploads/docs'); $file = $path ? realpath(__DIR__ . '/../' . $path) : false; }                    // legacy location
if (!$file || !$base || strpos($file, $base) !== 0 || !is_file($file)) { http_response_code(404); exit('Document not found.'); }
header_remove('Content-Security-Policy');   // lets the browser's built-in PDF viewer render the file
header('Content-Type: ' . (new finfo(FILEINFO_MIME_TYPE))->file($file));
header('Content-Disposition: inline; filename="' . basename($file) . '"');
header('Cache-Control: private, no-store');
readfile($file);
