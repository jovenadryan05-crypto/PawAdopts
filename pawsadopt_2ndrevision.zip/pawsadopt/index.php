<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Find a pet'; $page = 'browse';

// UC-08 Browse and search pets (only available pets from approved, active shelters)
$where = ["p.status = 'available'", "s.verification_status = 'approved'", "s.account_status = 'active'"];
$args = [];
$search = trim($_GET['q'] ?? '');
if ($search !== '') { $where[] = '(p.pet_name LIKE ? OR p.breed LIKE ? OR p.description LIKE ?)'; array_push($args, "%$search%", "%$search%", "%$search%"); }
$species = trim($_GET['species'] ?? '');
if ($species !== '') { $where[] = 'p.species = ?'; $args[] = $species; }
$sex = $_GET['sex'] ?? '';
if (in_array($sex, ['male', 'female'], true)) { $where[] = 'p.sex = ?'; $args[] = $sex; }
$age = $_GET['age'] ?? '';
$ageRanges = ['baby' => [0, 11], 'young' => [12, 35], 'adult' => [36, 95], 'senior' => [96, 9999]];
if (isset($ageRanges[$age])) { $where[] = 'p.age_months BETWEEN ? AND ?'; array_push($args, ...$ageRanges[$age]); }
$shelter = (int)($_GET['shelter'] ?? 0);
if ($shelter) { $where[] = 'p.shelter_id = ?'; $args[] = $shelter; }

$cond = implode(' AND ', $where);
$total = (int)q("SELECT COUNT(*) FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE $cond", $args)->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$pg = min(max(1, (int)($_GET['p'] ?? 1)), $pages);
$offset = ($pg - 1) * PER_PAGE;
$pets = q("SELECT p.*, s.shelter_name,
            (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
          FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id
          WHERE $cond ORDER BY p.created_at DESC LIMIT " . PER_PAGE . " OFFSET $offset", $args)->fetchAll();

$speciesList = q("SELECT DISTINCT species FROM pets WHERE status='available' ORDER BY species")->fetchAll(PDO::FETCH_COLUMN);
$shelters = q("SELECT shelter_id, shelter_name FROM shelters WHERE verification_status='approved' AND account_status='active' ORDER BY shelter_name")->fetchAll();
$qs = $_GET; unset($qs['p']);

include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <h1>Someone is waiting for a home like yours.</h1>
  <p>Browse animals from verified shelters, ask a question, and start the adoption conversation.</p>
</section>

<form class="filters" method="get" action="<?= url('index.php') ?>">
  <label class="grow">Search<input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, breed or description"></label>
  <label>Species
    <select name="species"><option value="">Any</option>
      <?php foreach ($speciesList as $sp): ?><option <?= $species === $sp ? 'selected' : '' ?>><?= e($sp) ?></option><?php endforeach; ?>
    </select></label>
  <label>Sex
    <select name="sex"><option value="">Any</option>
      <option value="male" <?= $sex==='male'?'selected':'' ?>>Male</option><option value="female" <?= $sex==='female'?'selected':'' ?>>Female</option></select></label>
  <label>Age
    <select name="age"><option value="">Any</option>
      <?php foreach (['baby'=>'Under 1 year','young'=>'1 to 2 years','adult'=>'3 to 7 years','senior'=>'8+ years'] as $k=>$v): ?>
        <option value="<?= $k ?>" <?= $age===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
    </select></label>
  <label>Shelter
    <select name="shelter"><option value="">Any</option>
      <?php foreach ($shelters as $s): ?><option value="<?= $s['shelter_id'] ?>" <?= $shelter==$s['shelter_id']?'selected':'' ?>><?= e($s['shelter_name']) ?></option><?php endforeach; ?>
    </select></label>
  <button class="btn">Search</button>
  <?php if ($_GET): ?><a class="btn btn-ghost" href="<?= url('index.php') ?>">Clear</a><?php endif; ?>
</form>

<p class="muted"><?= $total ?> pet<?= $total === 1 ? '' : 's' ?> available</p>

<?php if (!$pets): ?>
  <div class="empty"><h2>No pets match those filters</h2><p>Try removing a filter or searching a different breed.</p></div>
<?php else: ?>
  <div class="grid">
  <?php foreach ($pets as $p): ?>
    <a class="card pet-card" href="<?= url('pet.php?id=' . $p['pet_id']) ?>">
      <div class="thumb"><?php if ($p['photo']): ?><img src="<?= url($p['photo']) ?>" alt="<?= e($p['pet_name']) ?>" loading="lazy"><?php else: ?><span class="ph">&#128062;</span><?php endif; ?></div>
      <div class="card-body">
        <h3><?= e($p['pet_name']) ?></h3>
        <p class="muted"><?= e($p['breed'] ?: $p['species']) ?> &middot; <?= e(ucfirst($p['sex'])) ?> &middot; <?= age_label((int)$p['age_months']) ?></p>
        <p class="small"><?= e($p['shelter_name']) ?></p>
      </div>
    </a>
  <?php endforeach; ?>
  </div>
  <?php if ($pages > 1): ?>
  <nav class="pager" aria-label="Pages">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <a class="<?= $i === $pg ? 'on' : '' ?>" href="<?= url('index.php?' . http_build_query($qs + ['p' => $i])) ?>"><?= $i ?></a>
    <?php endfor; ?>
  </nav>
  <?php endif; ?>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
