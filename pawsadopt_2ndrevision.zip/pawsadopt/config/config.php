<?php
// ---- Database ----
define('DB_HOST', 'localhost');
define('DB_NAME', 'pawsadopt');
define('DB_USER', 'root');
define('DB_PASS', '');            // XAMPP default is empty
define('BASE_URL', '/pawsadopt');
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);
define('PER_PAGE', 12);

// ---- Mail (only needed for the one-time-code reset) ----
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'macjoven@tip.edu.ph');
define('MAIL_PASS', 'iwba stjf afis gdex');
define('MAIL_FROM', 'macjoven@tip.edu.ph');