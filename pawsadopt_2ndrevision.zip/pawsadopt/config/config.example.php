<?php
// Copy this file to config.php and edit it. config.php holds secrets, so never share or commit it.

// ---- Database ----
define('DB_HOST', 'localhost');
define('DB_NAME', 'pawsadopt');
define('DB_USER', 'root');          // better: 'pawsadopt_app' (see database/create_app_user.sql)
define('DB_PASS', '');
define('BASE_URL', '/pawsadopt');   // URL path of this folder under htdocs ('' if served at the site root)

// ---- App ----
define('APP_DEBUG', false);         // true only while developing: shows PHP errors on screen
define('SESSION_IDLE', 1800);       // auto log-out after this many idle seconds
// define('PRIVATE_DIR', 'C:/xampp/pawsadopt_private');  // optional: where verification documents are stored (outside htdocs)
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);
define('PER_PAGE', 12);

// ---- Email (password reset codes, shelter notifications) ----
// Leave MAIL_HOST empty while developing: emails are written to logs/mail.log instead of being sent.
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'yourproject@gmail.com');
define('MAIL_PASS', 'your 16-char app password');
define('MAIL_FROM', 'yourproject@gmail.com');
