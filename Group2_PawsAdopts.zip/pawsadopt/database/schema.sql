-- PawsAdopt schema (6 tables, one per DFD data store D1-D6)
DROP DATABASE IF EXISTS pawsadopt;
CREATE DATABASE pawsadopt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pawsadopt;

-- D1 USERS (shelter_id FK is added after SHELTERS exists: users <-> shelters is circular)
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id     INT NULL COMMENT 'NULL, staff only',
  first_name     VARCHAR(60)  NOT NULL,
  last_name      VARCHAR(60)  NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  contact_number VARCHAR(30)  NOT NULL,
  role           ENUM('adopter','staff','admin') NOT NULL,
  account_status ENUM('active','suspended') NOT NULL DEFAULT 'active',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- D2 SHELTERS
CREATE TABLE shelters (
  shelter_id             INT AUTO_INCREMENT PRIMARY KEY,
  shelter_name           VARCHAR(120) NOT NULL,
  address                VARCHAR(255) NOT NULL,
  contact_email          VARCHAR(150) NOT NULL,
  contact_number         VARCHAR(30)  NOT NULL,
  verification_documents VARCHAR(255) NOT NULL,
  verification_status    ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  account_status         ENUM('active','suspended') NOT NULL DEFAULT 'active',
  reviewed_by            INT NULL COMMENT 'NULL until reviewed',
  reviewed_at            DATETIME NULL,
  rejection_reason       VARCHAR(255) NULL,
  created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_shelter_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE users ADD CONSTRAINT fk_user_shelter
  FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE SET NULL;

-- D3 PETS
CREATE TABLE pets (
  pet_id      INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id  INT NOT NULL,
  listed_by   INT NOT NULL,
  pet_name    VARCHAR(80) NOT NULL,
  species     VARCHAR(40) NOT NULL,
  breed       VARCHAR(80) NULL,
  sex         ENUM('male','female','unknown') NOT NULL DEFAULT 'unknown',
  age_months  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  description TEXT NULL,
  status      ENUM('available','pending','adopted','removed') NOT NULL DEFAULT 'available',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pet_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_pet_user    FOREIGN KEY (listed_by)  REFERENCES users(user_id)       ON DELETE RESTRICT,
  INDEX idx_pet_search (status, species)
) ENGINE=InnoDB;

-- D4 PET_PHOTOS
CREATE TABLE pet_photos (
  photo_id    INT AUTO_INCREMENT PRIMARY KEY,
  pet_id      INT NOT NULL,
  photo_url   VARCHAR(255) NOT NULL,
  is_primary  TINYINT(1) NOT NULL DEFAULT 0,
  uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_photo_pet FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- D5 ADOPTION_INQUIRIES (the response fields live here, per the ERD)
CREATE TABLE adoption_inquiries (
  inquiry_id       INT AUTO_INCREMENT PRIMARY KEY,
  pet_id           INT NOT NULL,
  adopter_id       INT NOT NULL,
  message          TEXT NOT NULL,
  status           ENUM('pending','approved','rejected','withdrawn') NOT NULL DEFAULT 'pending',
  submitted_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  responded_by     INT NULL COMMENT 'NULL until responded',
  decision         ENUM('approved','rejected') NULL,
  response_message TEXT NULL,
  responded_at     DATETIME NULL,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_inq_pet     FOREIGN KEY (pet_id)       REFERENCES pets(pet_id)   ON DELETE CASCADE,
  CONSTRAINT fk_inq_adopter FOREIGN KEY (adopter_id)   REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_inq_staff   FOREIGN KEY (responded_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- D6 ANNOUNCEMENTS_DONATIONS
CREATE TABLE announcements_donations (
  post_id       INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id    INT NOT NULL,
  posted_by     INT NOT NULL,
  post_type     ENUM('announcement','donation') NOT NULL,
  title         VARCHAR(150) NOT NULL,
  content       TEXT NOT NULL,
  target_amount DECIMAL(12,2) NULL,
  status        ENUM('published','closed','hidden') NOT NULL DEFAULT 'published',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_post_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_post_user    FOREIGN KEY (posted_by)  REFERENCES users(user_id)       ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Default administrator (change this password after first login)
-- email: admin@pawsadopt.local   password: Admin@12345
INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role)
VALUES ('System','Admin','admin@pawsadopt.local','$2y$10$HEZtbE8PQ5Tn/6bXMEcAY.1DvrTzw9MsodnMSiA7bSiWxMyhrHgQ.','09000000000','admin');
