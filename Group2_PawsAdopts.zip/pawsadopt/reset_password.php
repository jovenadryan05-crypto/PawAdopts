<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (empty($_SESSION['reset_email'])) redirect('forgot_password.php');
$title = 'Enter code'; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $r = q('SELECT r.* FROM password_resets r JOIN users u ON u.user_id=r.user_id
            WHERE u.email=? AND r.used_at IS NULL AND r.expires_at > NOW() AND r.attempts < 5
            ORDER BY r.reset_id DESC LIMIT 1', [$_SESSION['reset_email']])->fetch();
    $pw = $_POST['password'] ?? '';
    if (strlen($pw) < 8) $error = 'New password must be at least 8 characters.';
    elseif ($pw !== ($_POST['confirm'] ?? '')) $error = 'Passwords do not match.';
    elseif (!$r) $error = 'This code expired or was used too many times. Request a new one.';
    elseif (!password_verify(trim($_POST['code'] ?? ''), $r['code_hash'])) {
        q('UPDATE password_resets SET attempts = attempts + 1 WHERE reset_id=?', [$r['reset_id']]);
        $error = 'That code is not correct.';
    } else {
        q('UPDATE users SET password_hash=? WHERE user_id=?', [password_hash($pw, PASSWORD_DEFAULT), $r['user_id']]);
        q('UPDATE password_resets SET used_at=NOW() WHERE reset_id=?', [$r['reset_id']]);
        unset($_SESSION['reset_email']);
        flash('success', 'Password updated. Log in with your new password.');
        redirect('login.php');
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Enter your code</h1>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?>
    <label>6-digit code<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" required autofocus></label>
    <label>New password<input type="password" name="password" minlength="8" required></label>
    <label>Confirm new password<input type="password" name="confirm" minlength="8" required></label>
    <button class="btn">Update password</button>
  </form>
  <p class="muted"><a href="<?= url('forgot_password.php') ?>">Send a new code</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>