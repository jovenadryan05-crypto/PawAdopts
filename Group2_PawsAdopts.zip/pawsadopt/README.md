# PawsAdopt: Pet Adoption System (PHP + MySQL + CSS + JS)

Built from the project's UML use case, Level 0 DFD, class diagram and ERD.
No framework and no Composer: plain PHP 8+ with PDO, MySQL/MariaDB, vanilla CSS and JS.

## Setup (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\pawsadopt`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin > Import > choose `database/schema.sql` (it creates the `pawsadopt` database).
4. If your MySQL has a password or the folder name differs, edit `config/config.php`.
5. Visit http://localhost/pawsadopt

Default admin: `admin@pawsadopt.local` / `Admin@12345` (change it under Profile after first login).
`uploads/` must be writable by PHP.

## Use case coverage
| UC | Feature | File |
|----|---------|------|
| 01 | Register account | register.php |
| 02 | Log in / out | login.php, logout.php |
| 03 | Reset password | forgot_password.php |
| 04 | Manage profile | profile.php |
| 05 | Register shelter profile | staff/shelter.php |
| 06 | Approve or reject shelter | admin/shelters.php |
| 07 | Manage pet listings (+ photos) | staff/pets.php, staff/pet_form.php |
| 08 | Browse and search pets | index.php |
| 09 | View pet details | pet.php |
| 10 | Submit adoption inquiry | pet.php |
| 11 | View and withdraw inquiries | adopter/inquiries.php |
| 12 | Process adoption inquiries | staff/inquiries.php |
| 13 | Manage announcements & donations | staff/posts.php |
| 14 | View announcements & donations | announcements.php |
| 15 | Moderate content & manage accounts | admin/users.php, admin/moderation.php, admin/shelters.php |

## Design decisions to know about
- **Reset password (UC-03):** the ERD has no token table and XAMPP has no mail server, so identity is confirmed with the email + contact number on file. For production, replace with an emailed one-time token.
- **Inquiry responses** are stored on `adoption_inquiries` (as in the ERD), not in a separate table; the class diagram's `InquiryResponse` maps to those columns.
- **Pet status flow:** approving an inquiry sets the pet to *pending*; "Mark pet as adopted" sets *adopted* and closes other pending inquiries.
- **Visibility:** pets and posts only show publicly when their shelter is approved and active.
- **Security:** PDO prepared statements, bcrypt hashes, CSRF tokens on every POST, role checks on every protected page, MIME-checked uploads, verification documents stored in a private folder and streamed only to admins.
