<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Create account'; $errors = [];
// UC-01 Register account (adopters and shelter staff; admin accounts are created by the system)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    $role = $f('role');
    if (!in_array($role, ['adopter', 'staff'], true)) $errors[] = 'Choose an account type.';
    if ($f('first_name') === '' || $f('last_name') === '') $errors[] = 'First and last name are required.';
    if (!filter_var($f('email'), FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $f('contact_number'))) $errors[] = 'Enter a valid contact number.';
    if (strlen($_POST['password'] ?? '') < 8) $errors[] = 'Password must be at least 8 characters.';
    if (($_POST['password'] ?? '') !== ($_POST['confirm'] ?? '')) $errors[] = 'Passwords do not match.';
    if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$f('email')])->fetch()) $errors[] = 'That email is already registered.';
    if (!$errors) {
        q('INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role) VALUES (?,?,?,?,?,?)',
          [$f('first_name'), $f('last_name'), strtolower($f('email')), password_hash($_POST['password'], PASSWORD_DEFAULT), $f('contact_number'), $role]);
        flash('success', 'Account created. Log in to continue.');
        redirect('login.php');
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth">
  <h1>Create your account</h1>
  <?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?>
    <fieldset class="choice"><legend>I am joining as</legend>
      <label><input type="radio" name="role" value="adopter" <?= ($_POST['role'] ?? 'adopter') === 'adopter' ? 'checked' : '' ?>> An adopter</label>
      <label><input type="radio" name="role" value="staff" <?= ($_POST['role'] ?? '') === 'staff' ? 'checked' : '' ?>> Shelter staff</label>
    </fieldset>
    <div class="two"><label>First name<input name="first_name" value="<?= old('first_name') ?>" required></label>
    <label>Last name<input name="last_name" value="<?= old('last_name') ?>" required></label></div>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required></label>
    <label>Contact number<input name="contact_number" value="<?= old('contact_number') ?>" required></label>
    <div class="two"><label>Password<input type="password" name="password" minlength="8" required></label>
    <label>Confirm password<input type="password" name="confirm" minlength="8" required></label></div>
    <button class="btn">Create account</button>
  </form>
  <p class="muted">Already registered? <a href="<?= url('login.php') ?>">Log in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
