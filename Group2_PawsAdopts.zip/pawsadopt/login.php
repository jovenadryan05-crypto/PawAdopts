<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Log in'; $error = '';
// UC-02 Log in
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $row = q('SELECT * FROM users WHERE email = ?', [strtolower(trim($_POST['email'] ?? ''))])->fetch();
    if (!$row || !password_verify($_POST['password'] ?? '', $row['password_hash'])) {
        $error = 'Email or password is incorrect.';
    } elseif ($row['account_status'] !== 'active') {
        $error = 'This account is suspended. Contact the administrator.';
    } else {
        session_regenerate_id(true);
        $_SESSION['uid'] = $row['user_id'];
        flash('success', 'Welcome back, ' . $row['first_name'] . '.');
        redirect(home_for($row));
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Log in</h1>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required autofocus></label>
    <label>Password<input type="password" name="password" required></label>
    <button class="btn">Log in</button>
  </form>
  <p class="muted"><a href="<?= url('forgot_password.php') ?>">Forgot your password?</a> &middot; <a href="<?= url('register.php') ?>">Create an account</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
