<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';

function send_mail(string $to, string $subject, string $html): bool {
    $m = new PHPMailer(true);
    try {
        $m->isSMTP(); $m->Host = MAIL_HOST; $m->Port = MAIL_PORT;
        $m->SMTPAuth = true; $m->Username = MAIL_USER; $m->Password = MAIL_PASS;
        $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $m->setFrom(MAIL_FROM, 'PawsAdopt'); $m->addAddress($to);
        $m->isHTML(true); $m->Subject = $subject; $m->Body = $html; $m->AltBody = strip_tags($html);
        $m->send(); return true;
    } catch (Exception $e) { error_log('Mail error: ' . $m->ErrorInfo); return false; }
}