<?php
require_once __DIR__ . '/../config/config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
function q(string $sql, array $params = []): PDOStatement { $s = db()->prepare($sql); $s->execute($params); return $s; }

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return BASE_URL . '/' . ltrim($p, '/'); }
function redirect(string $p): void { header('Location: ' . url($p)); exit; }
function old(string $k, $default = ''): string { return e($_POST[$k] ?? $default); }

function flash(?string $type = null, ?string $msg = null) {
    if ($type !== null) { $_SESSION['flash'][] = [$type, $msg]; return; }
    $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f;
}
function csrf_field(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Your form expired. Go back, refresh the page and try again.');
    }
}

function user(): ?array {
    static $u = false;
    if ($u === false) {
        $u = null;
        if (!empty($_SESSION['uid'])) {
            $u = q('SELECT u.*, s.shelter_name, s.verification_status, s.account_status AS shelter_status, s.rejection_reason
                    FROM users u LEFT JOIN shelters s ON s.shelter_id = u.shelter_id WHERE u.user_id = ?', [$_SESSION['uid']])->fetch() ?: null;
            if ($u && $u['account_status'] !== 'active') { unset($_SESSION['uid']); $u = null; }
        }
    }
    return $u;
}
function require_role(string ...$roles): array {
    $u = user();
    if (!$u) { flash('error', 'Please log in to continue.'); redirect('login.php'); }
    if ($roles && !in_array($u['role'], $roles, true)) { http_response_code(403); exit('403: you do not have access to this page.'); }
    return $u;
}
function shelter_ready(?array $u): bool {
    return $u && $u['role'] === 'staff' && $u['shelter_id'] && $u['verification_status'] === 'approved' && $u['shelter_status'] === 'active';
}
function home_for(array $u): string {
    return ['admin' => 'admin/dashboard.php', 'staff' => 'staff/dashboard.php', 'adopter' => 'index.php'][$u['role']];
}

function age_label(int $months): string {
    if ($months < 12) return $months . ' mo';
    $y = intdiv($months, 12); $m = $months % 12;
    return $y . ' yr' . ($y > 1 ? 's' : '') . ($m ? " $m mo" : '');
}
function badge(string $status): string { return '<span class="badge b-' . e($status) . '">' . e(ucfirst($status)) . '</span>'; }
function fdate(?string $d): string { return $d ? date('M j, Y', strtotime($d)) : '-'; }

/** Validate + store an uploaded image (or PDF when $allowPdf). Returns web path or null (adds a flash on error). */
function save_upload(array $file, string $dir, bool $allowPdf = false): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > MAX_UPLOAD_BYTES) { flash('error', 'Upload failed. Files must be under 5 MB.'); return null; }
    $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if ($allowPdf) $types['application/pdf'] = 'pdf';
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($types[$mime])) { flash('error', 'Unsupported file type. Use JPG, PNG or WEBP' . ($allowPdf ? ' or PDF.' : '.')); return null; }
    $name = bin2hex(random_bytes(12)) . '.' . $types[$mime];
    $target = __DIR__ . '/../uploads/' . $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) { flash('error', 'Could not save the file. Check folder permissions on uploads/.'); return null; }
    return 'uploads/' . $dir . '/' . $name;
}
