<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$admin = require_role('admin');
$title = 'Users'; $page = 'users';
// UC-15 Manage accounts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? '';
    if ($id === (int)$admin['user_id']) flash('error', 'You cannot change your own account status.');
    elseif (in_array($act, ['suspend', 'activate'], true)) {
        q("UPDATE users SET account_status=? WHERE user_id=? AND role<>'admin'", [$act === 'suspend' ? 'suspended' : 'active', $id]);
        flash('success', 'Account ' . ($act === 'suspend' ? 'suspended.' : 'reactivated.'));
    }
    redirect('admin/users.php?' . http_build_query(array_intersect_key($_GET, ['role' => 1, 'q' => 1])));
}
$role = $_GET['role'] ?? ''; $search = trim($_GET['q'] ?? '');
$where = ['1=1']; $args = [];
if (in_array($role, ['adopter', 'staff', 'admin'], true)) { $where[] = 'u.role=?'; $args[] = $role; }
if ($search !== '') { $where[] = '(u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)'; array_push($args, "%$search%", "%$search%", "%$search%"); }
$rows = q('SELECT u.*, s.shelter_name FROM users u LEFT JOIN shelters s ON s.shelter_id=u.shelter_id WHERE ' . implode(' AND ', $where) . ' ORDER BY u.created_at DESC LIMIT 200', $args)->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Users</h1>
<form class="filters" method="get">
  <label class="grow">Search<input type="search" name="q" value="<?= e($search) ?>" placeholder="Name or email"></label>
  <label>Role<select name="role"><option value="">All</option><?php foreach (['adopter', 'staff', 'admin'] as $r): ?><option value="<?= $r ?>" <?= $role === $r ? 'selected' : '' ?>><?= ucfirst($r) ?></option><?php endforeach; ?></select></label>
  <button class="btn">Filter</button>
</form>
<div class="table-wrap"><table>
<thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Shelter</th><th>Joined</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td><td><?= e($r['email']) ?></td><td><?= e(ucfirst($r['role'])) ?></td><td><?= e($r['shelter_name'] ?: '-') ?></td><td><?= fdate($r['created_at']) ?></td><td><?= badge($r['account_status']) ?></td>
<td class="row-actions"><?php if ($r['role'] !== 'admin'): ?>
  <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['user_id'] ?>">
  <?php if ($r['account_status'] === 'active'): ?><button class="btn btn-sm btn-danger" name="action" value="suspend" data-confirm="Suspend this account?">Suspend</button>
  <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="activate">Reactivate</button><?php endif; ?></form>
<?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
