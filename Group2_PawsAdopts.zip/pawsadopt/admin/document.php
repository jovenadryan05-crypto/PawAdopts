<?php
// Streams a shelter's private verification document to admins only.
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$path = q('SELECT verification_documents FROM shelters WHERE shelter_id=?', [(int)($_GET['id'] ?? 0)])->fetchColumn();
$file = $path ? realpath(__DIR__ . '/../' . $path) : false;
$base = realpath(__DIR__ . '/../uploads/docs');
if (!$file || !$base || strpos($file, $base) !== 0 || !is_file($file)) { http_response_code(404); exit('Document not found.'); }
header('Content-Type: ' . (new finfo(FILEINFO_MIME_TYPE))->file($file));
header('Content-Disposition: inline; filename="' . basename($file) . '"');
header('X-Content-Type-Options: nosniff');
readfile($file);
