<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Announcements & donations'; $page = 'posts'; $errors = [];
// UC-13 Manage announcements & donations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? 'create';
    if ($act === 'create') {
        $f = fn($k) => trim($_POST[$k] ?? '');
        $type = $f('post_type'); $amount = $f('target_amount');
        if (!in_array($type, ['announcement', 'donation'], true)) $errors[] = 'Choose a post type.';
        if ($f('title') === '' || $f('content') === '') $errors[] = 'Title and content are required.';
        if ($type === 'donation' && ($amount === '' || !is_numeric($amount) || $amount <= 0)) $errors[] = 'Donation requests need a target amount above zero.';
        if (!$errors) {
            q('INSERT INTO announcements_donations (shelter_id, posted_by, post_type, title, content, target_amount) VALUES (?,?,?,?,?,?)',
              [$u['shelter_id'], $u['user_id'], $type, $f('title'), $f('content'), $type === 'donation' ? $amount : null]);
            flash('success', 'Posted.'); redirect('staff/posts.php');
        }
    } else {
        $id = (int)$_POST['id'];
        if ($act === 'close') q("UPDATE announcements_donations SET status='closed' WHERE post_id=? AND shelter_id=? AND status='published'", [$id, $u['shelter_id']]);
        if ($act === 'reopen') q("UPDATE announcements_donations SET status='published' WHERE post_id=? AND shelter_id=? AND status='closed'", [$id, $u['shelter_id']]);
        if ($act === 'delete') q('DELETE FROM announcements_donations WHERE post_id=? AND shelter_id=?', [$id, $u['shelter_id']]);
        flash('success', 'Post updated.'); redirect('staff/posts.php');
    }
}
$posts = q('SELECT * FROM announcements_donations WHERE shelter_id=? ORDER BY created_at DESC', [$u['shelter_id']])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Announcements &amp; donation requests</h1>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<div class="cols">
<form method="post" class="stack panel" id="postForm"><?= csrf_field() ?><h2>New post</h2>
  <label>Type<select name="post_type" id="postType"><option value="announcement" <?= ($_POST['post_type'] ?? '') === 'announcement' ? 'selected' : '' ?>>Announcement</option><option value="donation" <?= ($_POST['post_type'] ?? '') === 'donation' ? 'selected' : '' ?>>Donation request</option></select></label>
  <label>Title<input name="title" value="<?= old('title') ?>" maxlength="150" required></label>
  <label>Content<textarea name="content" rows="5" required><?= old('content') ?></textarea></label>
  <label id="amountField" hidden>Target amount (&#8369;)<input type="number" name="target_amount" min="1" step="0.01" value="<?= old('target_amount') ?>"></label>
  <button class="btn">Publish</button>
</form>
<div>
  <h2>Your posts</h2>
  <?php if (!$posts): ?><div class="empty"><p>Nothing posted yet.</p></div><?php endif; ?>
  <?php foreach ($posts as $p): ?>
  <article class="panel">
    <div class="split"><strong><?= e($p['title']) ?></strong><?= badge($p['status']) ?></div>
    <p class="small muted"><?= ucfirst($p['post_type']) ?> &middot; <?= fdate($p['created_at']) ?><?= $p['target_amount'] !== null ? ' &middot; target &#8369;' . number_format((float)$p['target_amount'], 2) : '' ?></p>
    <?php if ($p['status'] === 'hidden'): ?><p class="small">Hidden by an administrator.</p><?php endif; ?>
    <form method="post" class="inline-actions"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['post_id'] ?>">
      <?php if ($p['status'] === 'published'): ?><button class="btn btn-sm btn-ghost" name="action" value="close">Close</button><?php endif; ?>
      <?php if ($p['status'] === 'closed'): ?><button class="btn btn-sm btn-ghost" name="action" value="reopen">Reopen</button><?php endif; ?>
      <button class="btn btn-sm btn-danger" name="action" value="delete" data-confirm="Delete this post permanently?">Delete</button></form>
  </article>
  <?php endforeach; ?>
</div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
