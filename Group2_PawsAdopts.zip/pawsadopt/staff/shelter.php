<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
$title = 'Shelter profile'; $page = 'dash'; $errors = [];
$shelter = $u['shelter_id'] ? q('SELECT * FROM shelters WHERE shelter_id=?', [$u['shelter_id']])->fetch() : null;
if ($shelter && $shelter['verification_status'] === 'pending') { flash('info', 'Your shelter is already awaiting review.'); redirect('staff/dashboard.php'); }
// UC-05 Register shelter profile (also used to edit details or resubmit after rejection)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    if ($f('shelter_name') === '' || $f('address') === '') $errors[] = 'Shelter name and address are required.';
    if (!filter_var($f('contact_email'), FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid shelter email.';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $f('contact_number'))) $errors[] = 'Enter a valid shelter contact number.';
    $doc = null;
    if (!$errors) {
        $doc = save_upload($_FILES['document'] ?? [], 'docs', true);
        if (!$doc && !$shelter) $errors[] = 'Upload a verification document (business permit, registration or similar).';
        if (!$doc && $shelter && !empty($_FILES['document']['name'])) $errors[] = 'The document could not be saved.';
    }
    if (!$errors) {
        if (!$shelter) {
            q('INSERT INTO shelters (shelter_name,address,contact_email,contact_number,verification_documents) VALUES (?,?,?,?,?)',
              [$f('shelter_name'), $f('address'), $f('contact_email'), $f('contact_number'), $doc]);
            q('UPDATE users SET shelter_id=? WHERE user_id=?', [db()->lastInsertId(), $u['user_id']]);
            flash('success', 'Shelter submitted for verification.');
        } else {
            $resubmit = $shelter['verification_status'] === 'rejected';
            q('UPDATE shelters SET shelter_name=?, address=?, contact_email=?, contact_number=?, verification_documents=COALESCE(?, verification_documents),
               verification_status = IF(?, "pending", verification_status), rejection_reason = IF(?, NULL, rejection_reason), reviewed_by = IF(?, NULL, reviewed_by), reviewed_at = IF(?, NULL, reviewed_at)
               WHERE shelter_id=?', [$f('shelter_name'), $f('address'), $f('contact_email'), $f('contact_number'), $doc, (int)$resubmit, (int)$resubmit, (int)$resubmit, (int)$resubmit, $shelter['shelter_id']]);
            flash('success', $resubmit ? 'Shelter resubmitted for verification.' : 'Shelter details updated.');
        }
        redirect('staff/dashboard.php');
    }
}
$v = fn($k) => e($_POST[$k] ?? ($shelter[$k] ?? ''));
include __DIR__ . '/../includes/header.php';
?>
<h1><?= $shelter ? 'Edit shelter details' : 'Register your shelter' ?></h1>
<?php if ($shelter && $shelter['verification_status'] === 'rejected'): ?><div class="flash flash-error">Rejected: <?= e($shelter['rejection_reason']) ?>. Fix the details and resubmit.</div><?php endif; ?>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="stack panel narrow-form"><?= csrf_field() ?>
  <label>Shelter name<input name="shelter_name" value="<?= $v('shelter_name') ?>" required></label>
  <label>Address<input name="address" value="<?= $v('address') ?>" required></label>
  <div class="two"><label>Contact email<input type="email" name="contact_email" value="<?= $v('contact_email') ?>" required></label>
  <label>Contact number<input name="contact_number" value="<?= $v('contact_number') ?>" required></label></div>
  <label>Verification document (PDF, JPG, PNG; max 5 MB)<input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png,.webp" <?= $shelter ? '' : 'required' ?>></label>
  <?php if ($shelter): ?><p class="small muted">Leave the file empty to keep the document already on file.</p><?php endif; ?>
  <button class="btn"><?= $shelter && $shelter['verification_status'] === 'rejected' ? 'Resubmit for verification' : ($shelter ? 'Save changes' : 'Submit for verification') ?></button>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
