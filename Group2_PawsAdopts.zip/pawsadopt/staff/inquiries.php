<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Adoption inquiries'; $page = 'inq';
// UC-12 Process adoption inquiries
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $msg = trim($_POST['response_message'] ?? '');
    $inq = q('SELECT i.*, p.shelter_id FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id WHERE i.inquiry_id=?', [$id])->fetch();
    if (!$inq || $inq['shelter_id'] != $u['shelter_id']) { flash('error', 'Inquiry not found.'); redirect('staff/inquiries.php'); }
    if (in_array($act, ['approved', 'rejected'], true) && $inq['status'] === 'pending') {
        q('UPDATE adoption_inquiries SET status=?, decision=?, response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=?', [$act, $act, $msg ?: null, $u['user_id'], $id]);
        if ($act === 'approved') q("UPDATE pets SET status='pending' WHERE pet_id=? AND status='available'", [$inq['pet_id']]);
        flash('success', 'Response sent to the adopter.');
    } elseif ($act === 'adopted' && $inq['status'] === 'approved') {
        q("UPDATE pets SET status='adopted' WHERE pet_id=?", [$inq['pet_id']]);
        q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message='This pet has been adopted by another applicant.', responded_by=?, responded_at=NOW()
           WHERE pet_id=? AND status='pending'", [$u['user_id'], $inq['pet_id']]);
        flash('success', 'Pet marked as adopted. Other pending inquiries were closed.');
    } else flash('error', 'That inquiry was already handled.');
    redirect('staff/inquiries.php' . (isset($_GET['s']) ? '?s=' . urlencode($_GET['s']) : ''));
}
$filter = $_GET['s'] ?? 'pending';
$valid = ['pending', 'approved', 'rejected', 'withdrawn', 'all'];
if (!in_array($filter, $valid, true)) $filter = 'pending';
$rows = q('SELECT i.*, p.pet_name, p.status AS pet_status, a.first_name, a.last_name, a.email, a.contact_number FROM adoption_inquiries i
           JOIN pets p ON p.pet_id=i.pet_id JOIN users a ON a.user_id=i.adopter_id
           WHERE p.shelter_id=? ' . ($filter === 'all' ? '' : 'AND i.status=?') . ' ORDER BY i.submitted_at DESC',
           $filter === 'all' ? [$u['shelter_id']] : [$u['shelter_id'], $filter])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Adoption inquiries</h1>
<div class="tabs"><?php foreach ($valid as $s): ?><a class="<?= $filter === $s ? 'on' : '' ?>" href="?s=<?= $s ?>"><?= ucfirst($s) ?></a><?php endforeach; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'all' ? '' : e($filter) . ' ' ?>inquiries</h2></div><?php endif; ?>
<?php foreach ($rows as $r): ?>
<article class="panel inq">
  <div class="split"><h2><?= e($r['pet_name']) ?> <span class="muted small">from <?= e($r['first_name'] . ' ' . $r['last_name']) ?></span></h2><?= badge($r['status']) ?></div>
  <p class="small muted"><?= e($r['email']) ?> &middot; <?= e($r['contact_number']) ?> &middot; sent <?= fdate($r['submitted_at']) ?></p>
  <p class="quote"><?= nl2br(e($r['message'])) ?></p>
  <?php if ($r['responded_at']): ?><div class="reply"><strong>Your response (<?= fdate($r['responded_at']) ?>)</strong><p><?= nl2br(e($r['response_message'] ?: 'No message.')) ?></p></div><?php endif; ?>
  <?php if ($r['status'] === 'pending'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <label>Message to adopter (optional)<textarea name="response_message" rows="3" placeholder="Next steps, a meeting time, or why it is not a fit."></textarea></label>
    <div class="actions"><button class="btn" name="action" value="approved">Approve</button><button class="btn btn-danger" name="action" value="rejected" data-confirm="Reject this inquiry?">Reject</button></div>
  </form>
  <?php elseif ($r['status'] === 'approved' && $r['pet_status'] !== 'adopted'): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <button class="btn btn-ghost" name="action" value="adopted" data-confirm="Mark this pet as adopted? Other pending inquiries will be closed.">Mark pet as adopted</button></form>
  <?php endif; ?>
</article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
