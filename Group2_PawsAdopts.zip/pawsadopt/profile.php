<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_role();
$title = 'My profile'; $page = 'profile'; $errors = [];
// UC-04 Manage profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    if (($_POST['action'] ?? '') === 'password') {
        if (!password_verify($_POST['current'] ?? '', $u['password_hash'])) $errors[] = 'Current password is incorrect.';
        elseif (strlen($_POST['password'] ?? '') < 8) $errors[] = 'New password must be at least 8 characters.';
        elseif ($_POST['password'] !== ($_POST['confirm'] ?? '')) $errors[] = 'New passwords do not match.';
        else { q('UPDATE users SET password_hash=? WHERE user_id=?', [password_hash($_POST['password'], PASSWORD_DEFAULT), $u['user_id']]); flash('success', 'Password changed.'); redirect('profile.php'); }
    } else {
        if ($f('first_name') === '' || $f('last_name') === '') $errors[] = 'First and last name are required.';
        if (!filter_var($f('email'), FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $f('contact_number'))) $errors[] = 'Enter a valid contact number.';
        if (!$errors && q('SELECT 1 FROM users WHERE email=? AND user_id<>?', [$f('email'), $u['user_id']])->fetch()) $errors[] = 'That email is used by another account.';
        if (!$errors) {
            q('UPDATE users SET first_name=?, last_name=?, email=?, contact_number=? WHERE user_id=?', [$f('first_name'), $f('last_name'), strtolower($f('email')), $f('contact_number'), $u['user_id']]);
            flash('success', 'Profile updated.'); redirect('profile.php');
        }
    }
}
include __DIR__ . '/includes/header.php';
?>
<h1>My profile</h1>
<p class="muted"><?= e(ucfirst($u['role'])) ?> account &middot; member since <?= fdate($u['created_at']) ?></p>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<div class="cols">
  <form method="post" class="stack panel"><?= csrf_field() ?><h2>Details</h2>
    <div class="two"><label>First name<input name="first_name" value="<?= e($_POST['first_name'] ?? $u['first_name']) ?>" required></label>
    <label>Last name<input name="last_name" value="<?= e($_POST['last_name'] ?? $u['last_name']) ?>" required></label></div>
    <label>Email<input type="email" name="email" value="<?= e($_POST['email'] ?? $u['email']) ?>" required></label>
    <label>Contact number<input name="contact_number" value="<?= e($_POST['contact_number'] ?? $u['contact_number']) ?>" required></label>
    <button class="btn">Save changes</button>
  </form>
  <form method="post" class="stack panel" data-match="password,confirm"><?= csrf_field() ?><input type="hidden" name="action" value="password"><h2>Change password</h2>
    <label>Current password<input type="password" name="current" required></label>
    <label>New password<input type="password" name="password" minlength="8" required></label>
    <label>Confirm new password<input type="password" name="confirm" minlength="8" required></label>
    <button class="btn">Change password</button>
  </form>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
