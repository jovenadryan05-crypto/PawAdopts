# Diagram updates for batches 1 to 3

Your submitted diagrams (6 tables, 15 use cases, DFD D1 to D6) describe the original scope. These additions bring them in line with the system you now have.
Use whichever you need; the **business** additions (D7, UC-16/17) are the ones your instructor will care about. The support tables are infrastructure.

## 1. ERD (Mermaid) - new entity and relationships
```mermaid
erDiagram
    ADOPTION_INQUIRIES ||--o{ INQUIRY_MESSAGES : "has"
    USERS ||--o{ INQUIRY_MESSAGES : "sends"
    INQUIRY_MESSAGES {
        int message_id PK
        int inquiry_id FK
        int sender_id FK
        varchar body
        datetime created_at
        datetime read_at "NULL until the other side reads it"
    }
```
**Columns to add to existing entities**
- USERS: `varchar profile_photo`, `varchar bio`, `varchar city`, `varchar position` (staff job title), `enum housing_type`, `varchar other_pets`, `enum pet_experience`, `datetime consent_at`, `varchar terms_version`, `tinyint must_change_password`, `int session_version`. `account_status` now also allows `deleted`.
- SHELTERS: `char invite_code` (lets additional staff join, so "employs 1..*" is real).
- ADOPTION_INQUIRIES: `tinyint chat_locked`, `datetime chat_reported_at`, `int chat_reported_by`, `varchar chat_report_reason` (generated unique keys also enforce one active inquiry per adopter+pet and one approved inquiry per pet).

**System tables (optional, show as a separate "infrastructure" group):** `rate_limits(bucket, created_at)`, `password_resets(user_id FK, code_hash, expires_at, attempts, used_at)`, `admin_audit_log(admin_id FK, action, target_type, target_id, details, ip)`.

## 2. Level 0 DFD
- Add data store **D7 | INQUIRY_MESSAGES**.
- Process **5.0 Adoption Inquiry Management** (rename: *Adoption Inquiry & Conversation Management*):
  - ADOPTER --"Message"--> P5 --"Message / Read status"--> D7 ;  D7 --"Conversation"--> P5 --"Conversation / Unread count"--> ADOPTER
  - STAFF --"Message / Report conversation"--> P5 ; P5 --"Conversation / Unread count"--> STAFF
- Process **7.0 Administration & Content Moderation**: STAFF/ADOPTER --"Report"--> P7 ; D5/D7 --"Reported conversation"--> P7 --"Lock / Dismiss decision"--> D5
- Process **1.0 Account & Authentication**: add flows "Consent record" (to D1) and "Data export / Erasure request".

## 3. Use case diagram (PlantUML additions)
```plantuml
usecase "UC-16: Chat About an Inquiry" as UC16
usecase "UC-17: Report a Conversation" as UC17
usecase "UC-18: Manage My Data (Download / Delete)" as UC18
ACT01 --> UC16
ACT02 --> UC16
ACT01 --> UC17
ACT02 --> UC17
ACT01 --> UC18
ACT02 --> UC18
ACT03 --> UC15
UC16 ..> UC02 : <<include>>
UC16 ..> UC10 : <<extend>>
```
UC-15 (Moderate Content & Manage Accounts) now also covers "review, lock or dismiss a reported conversation".

## 4. Class diagram (Mermaid additions)
```mermaid
classDiagram
    class InquiryMessage {
        -int messageId
        -String body
        -DateTime createdAt
        -DateTime readAt
        +markRead() void
    }
    Adopter : +sendMessage(inquiryId, body) InquiryMessage
    Adopter : +viewConversation(inquiryId) List~InquiryMessage~
    Adopter : +reportConversation(inquiryId, reason) void
    Adopter : +downloadMyData() File
    Adopter : +deleteMyAccount() void
    ShelterStaff : +sendMessage(inquiryId, body) InquiryMessage
    ShelterStaff : +reportConversation(inquiryId, reason) void
    SystemAdmin : +reviewReportedConversation(inquiryId) List~InquiryMessage~
    SystemAdmin : +lockConversation(inquiryId) boolean
    AdoptionInquiry "1" *-- "0..*" InquiryMessage : has
    User "1" --> "0..*" InquiryMessage : sends
```
