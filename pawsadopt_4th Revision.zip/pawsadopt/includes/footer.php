</main>
<footer class="site-footer"><div class="wrap foot"><span>PawsAdopt connects adopters with verified animal shelters. Adopt, don't shop.</span>
  <span class="legal-links"><a href="<?= url('terms.php') ?>">Terms</a><a href="<?= url('privacy.php') ?>">Privacy Notice</a></span></div></footer>
<script src="<?= url('assets/js/app.js') ?>"></script>
<?php foreach (($scripts ?? []) as $sc): ?><script src="<?= url($sc) ?>"></script>
<?php endforeach; ?>
</body>
</html>
