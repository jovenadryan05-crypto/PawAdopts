<?php
// Data subject rights (RA 10173): export a copy of your data, and erase your account.

function export_user_data(array $u): array {
    $out = ['exported_at' => date('c'), 'account' => array_intersect_key($u, array_flip([
        'first_name', 'last_name', 'email', 'contact_number', 'role', 'account_status', 'city', 'bio', 'housing_type', 'other_pets',
        'pet_experience', 'position', 'profile_photo', 'consent_at', 'terms_version', 'created_at']))];
    if ($u['shelter_id']) $out['shelter'] = $u['shelter_name'];
    if ($u['role'] === 'adopter') {
        $out['inquiries'] = q('SELECT p.pet_name, s.shelter_name, i.message, i.status, i.submitted_at, i.response_message, i.responded_at
                               FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id
                               WHERE i.adopter_id=? ORDER BY i.submitted_at', [$u['user_id']])->fetchAll();
        $out['conversation_messages'] = q('SELECT p.pet_name, IF(m.sender_id=i.adopter_id, "you", "shelter") AS sent_by, m.body, m.created_at
                                           FROM inquiry_messages m JOIN adoption_inquiries i ON i.inquiry_id=m.inquiry_id JOIN pets p ON p.pet_id=i.pet_id
                                           WHERE i.adopter_id=? ORDER BY m.message_id', [$u['user_id']])->fetchAll();
    } elseif ($u['role'] === 'staff') {
        $out['pets_listed'] = q('SELECT pet_name, species, status, created_at FROM pets WHERE listed_by=?', [$u['user_id']])->fetchAll();
        $out['messages_sent'] = q('SELECT p.pet_name, m.body, m.created_at FROM inquiry_messages m JOIN adoption_inquiries i ON i.inquiry_id=m.inquiry_id JOIN pets p ON p.pet_id=i.pet_id WHERE m.sender_id=? ORDER BY m.message_id', [$u['user_id']])->fetchAll();
        $out['posts_authored'] = q('SELECT title, post_type, status, created_at FROM announcements_donations WHERE posted_by=?', [$u['user_id']])->fetchAll();
    }
    return $out;
}

/** Erase = anonymise. Business records (pets, inquiries) stay for the shelters' history, without personal details. */
function delete_account(array $u): void {
    $uid = (int)$u['user_id'];
    if ($u['role'] === 'adopter') {
        $reserved = q("SELECT DISTINCT pet_id FROM adoption_inquiries WHERE adopter_id=? AND status='approved'", [$uid])->fetchAll(PDO::FETCH_COLUMN);
        q("UPDATE adoption_inquiries SET status='withdrawn' WHERE adopter_id=? AND status IN ('pending','approved')", [$uid]);
        foreach ($reserved as $petId) {        // a pet reserved for this adopter becomes available again
            if (q('SELECT status FROM pets WHERE pet_id=?', [$petId])->fetchColumn() === 'pending') set_pet_status((int)$petId, 'available');
        }
        q("UPDATE adoption_inquiries SET message='[Removed at the adopter\'s request]' WHERE adopter_id=?", [$uid]);
        q("UPDATE inquiry_messages m JOIN adoption_inquiries i ON i.inquiry_id=m.inquiry_id SET m.body='[Conversation removed at the adopter\'s request]' WHERE i.adopter_id=?", [$uid]);
    }
    delete_public_file($u['profile_photo']);
    q('DELETE FROM password_resets WHERE user_id=?', [$uid]);
    q("UPDATE users SET first_name='Deleted', last_name='User', email=?, contact_number='00000000000', password_hash=?, account_status='deleted',
         shelter_id=NULL, profile_photo=NULL, bio=NULL, city=NULL, `position`=NULL, housing_type=NULL, other_pets=NULL, pet_experience=NULL,
         consent_at=NULL, terms_version=NULL, must_change_password=0, session_version=session_version+1 WHERE user_id=?",
      ['deleted-' . $uid . '@deleted.invalid', password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT), $uid]);
}
