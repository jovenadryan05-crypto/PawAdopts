<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_role('adopter', 'staff', 'admin');
$id = (int)($_GET['inquiry'] ?? 0);
$i = chat_inquiry($id);
$viewer = $i ? chat_viewer($i, $u) : null;
$back = ['adopter' => 'adopter/inquiries.php', 'staff' => 'staff/inquiries.php', 'admin' => 'admin/moderation.php?tab=chats'][$u['role']];
if (!$viewer) {
    http_response_code(404); $title = 'Conversation not found'; $page = '';
    include __DIR__ . '/includes/header.php';
    echo '<div class="empty"><h2>Conversation not found</h2><p>It may not exist, or you may not be part of it. <a href="' . e(url($back)) . '">Go back</a>.</p></div>';
    include __DIR__ . '/includes/footer.php'; exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {          // works without JavaScript too
    if (($_POST['action'] ?? '') === 'report') {
        $err = chat_report($i, $viewer, $u, trim($_POST['reason'] ?? ''));
        flash($err ? 'error' : 'success', $err ?: 'Thank you. An administrator will review this conversation.');
    } else {
        $r = chat_send($i, $viewer, $u, (string)($_POST['body'] ?? ''));
        if (!$r['ok']) flash('error', $r['error']);
    }
    redirect('chat.php?inquiry=' . $id);
}
if ($viewer === 'admin') audit('chat_viewed', 'inquiry', $id, 'Reported conversation opened (read-only)');
chat_mark_read($i, $viewer);                            // before the header, so the nav badge is already up to date
$messages = chat_messages($i, $viewer, $u);
$seenUpto = chat_seen_upto($i, $viewer);
$closed = chat_closed_reason($i, $viewer, $u);
$lastId = $messages ? end($messages)['id'] : 0;
$adopterRow = ['profile_photo' => $i['a_photo'], 'first_name' => $i['a_first'], 'last_name' => $i['a_last']];
$title = 'Conversation: ' . $i['pet_name']; $page = $viewer === 'admin' ? 'mod' : 'inq'; $scripts = ['assets/js/chat.js'];
include __DIR__ . '/includes/header.php';
?>
<p><a href="<?= url($back) ?>">&larr; Back</a></p>
<div class="chat-head">
  <?= $viewer === 'staff' || $viewer === 'admin' ? avatar($adopterRow) : '' ?>
  <div>
    <h1>About <?= e($i['pet_name']) ?> <?= badge($i['status']) ?></h1>
    <p class="muted">
      <?php if ($viewer === 'adopter'): ?>Conversation with <?= e($i['shelter_name']) ?>
      <?php else: ?><?= e($i['a_first'] . ' ' . $i['a_last']) ?> and <?= e($i['shelter_name']) ?><?php endif; ?>
    </p>
  </div>
</div>

<div id="chat" class="chat" data-api="<?= e(url('chat_api.php')) ?>" data-inquiry="<?= $id ?>" data-csrf="<?= e($_SESSION['csrf'] ?? '') ?>" data-last="<?= (int)$lastId ?>" data-cansend="<?= $closed ? '0' : '1' ?>">
  <ol id="msgs" class="msgs" aria-live="polite" aria-label="Messages">
    <?php foreach ($messages as $m): ?>
      <li class="msg <?= $m['mine'] ? 'mine' : 'theirs' ?>" data-id="<?= $m['id'] ?>"><div class="meta"><?= e($m['name']) ?> &middot; <?= e($m['time']) ?></div><div class="bubble"><?= e($m['body']) ?></div><?php if ($m['mine'] && $m['id'] === $seenUpto): ?><div class="seen">Seen</div><?php endif; ?></li>
    <?php endforeach; ?>
  </ol>
  <p id="noMsgs" class="muted center" <?= $messages ? 'hidden' : '' ?>>No messages yet. Say hello and ask about <?= e($i['pet_name']) ?>.</p>
  <p id="chatError" class="field-error" role="alert" hidden></p>
  <p id="closedNote" class="closed-note" <?= $closed ? '' : 'hidden' ?>><?= e($closed ?? '') ?></p>
  <form id="composer" class="composer" method="post" <?= $closed ? 'hidden' : '' ?>><?= csrf_field() ?>
    <input type="hidden" name="action" value="send">
    <textarea name="body" id="body" rows="2" maxlength="<?= CHAT_MAX_LEN ?>" required placeholder="Write a message. Enter sends, Shift+Enter adds a new line."></textarea>
    <button class="btn">Send</button>
  </form>
</div>

<p class="small muted">Messages are visible to you and the other side only. Administrators can read a conversation only if someone reports it, and that is logged. Emails about new messages never include the message text.</p>
<?php if ($viewer !== 'admin'): ?>
  <?php if ($i['chat_reported_at']): ?><p class="small muted">This conversation was reported on <?= e(fdate($i['chat_reported_at'])) ?> and may be reviewed by an administrator.</p>
  <?php else: ?>
  <details class="danger-zone"><summary>Report this conversation</summary>
    <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="report">
      <label>What is the problem? (optional)<input name="reason" maxlength="200" placeholder="e.g. abusive language, asking for money"></label>
      <button class="btn btn-danger" data-confirm="Report this conversation to the administrators? They will be able to read it.">Report</button>
    </form>
  </details>
  <?php endif; ?>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
