(function () {
  'use strict';
  var root = document.getElementById('chat');
  if (!root || !window.fetch) return;                           // no JS / old browser: the plain form still works

  var api = root.dataset.api, inquiry = root.dataset.inquiry, csrf = root.dataset.csrf;
  var list = document.getElementById('msgs'), form = document.getElementById('composer'), box = document.getElementById('body');
  var errorEl = document.getElementById('chatError'), closedEl = document.getElementById('closedNote'), emptyEl = document.getElementById('noMsgs');
  var lastId = parseInt(root.dataset.last || '0', 10), seen = {}, delay = 3000, stopped = false, timer = null, sending = false;

  list.querySelectorAll('[data-id]').forEach(function (li) { seen[li.dataset.id] = true; });

  function nearBottom() { return list.scrollHeight - list.scrollTop - list.clientHeight < 120; }
  function toBottom() { list.scrollTop = list.scrollHeight; }
  function showError(text) { errorEl.textContent = text || ''; errorEl.hidden = !text; }

  function addMessage(m) {                                      // textContent only: message text is never parsed as HTML
    if (seen[m.id]) return false;
    seen[m.id] = true;
    var li = document.createElement('li'); li.className = 'msg ' + (m.mine ? 'mine' : 'theirs'); li.dataset.id = m.id;
    var meta = document.createElement('div'); meta.className = 'meta'; meta.textContent = m.name + ' \u00b7 ' + m.time;
    var bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = m.body;
    li.appendChild(meta); li.appendChild(bubble); list.appendChild(li);
    lastId = Math.max(lastId, m.id);
    if (emptyEl) emptyEl.hidden = true;
    return true;
  }
  function setSeen(upto) {
    list.querySelectorAll('.seen').forEach(function (s) { s.remove(); });
    if (!upto) return;
    var li = list.querySelector('li.mine[data-id="' + upto + '"]');
    if (li) { var s = document.createElement('div'); s.className = 'seen'; s.textContent = 'Seen'; li.appendChild(s); }
  }
  function applyState(d) {
    if (typeof d.can_send === 'undefined') return;
    form.hidden = !d.can_send; closedEl.hidden = d.can_send; closedEl.textContent = d.closed_reason || '';
  }

  function poll() {
    return fetch(api + '?inquiry=' + encodeURIComponent(inquiry) + '&after=' + lastId, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) {
        if (r.status === 401) { stopped = true; showError('You were logged out. Please log in again.'); return null; }
        if (r.status === 403 || r.status === 404) { stopped = true; return null; }
        return r.json();
      })
      .then(function (d) {
        if (!d || !d.ok) return;
        var stick = nearBottom(), added = false;
        d.messages.forEach(function (m) { if (addMessage(m)) added = true; });
        setSeen(d.seen_upto); applyState(d);
        if (window.pawsSetUnread) window.pawsSetUnread(d.unread);
        if (added && stick) toBottom();
        delay = 3000; showError('');
      })
      .catch(function () { delay = Math.min(delay * 2, 30000); });   // back off when the network or server is struggling
  }
  function schedule() {
    if (stopped) return;
    clearTimeout(timer);
    timer = setTimeout(function () { (document.hidden ? Promise.resolve() : poll()).then(schedule); }, delay);
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && !stopped) { clearTimeout(timer); poll().then(schedule); }   // catch up the moment the tab is visible again
  });

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var text = box.value.trim();
      if (!text || sending) return;
      sending = true; form.querySelector('button').disabled = true; showError('');
      var data = new FormData(); data.append('csrf', csrf); data.append('inquiry', inquiry); data.append('body', text);
      fetch(api, { method: 'POST', body: data, credentials: 'same-origin', headers: { Accept: 'application/json' } })
        .then(function (r) { return r.json().then(function (d) { return { status: r.status, d: d }; }); })
        .then(function (x) {
          if (x.d && x.d.ok) { addMessage(x.d.message); box.value = ''; box.dispatchEvent(new Event('input')); toBottom(); setSeen(0); }
          else showError((x.d && x.d.error) || 'Could not send your message.');
        })
        .catch(function () { showError('Network problem. Your message was not sent; please try again.'); })
        .then(function () { sending = false; form.querySelector('button').disabled = false; box.focus(); });
    });
    box.addEventListener('keydown', function (e) {                // Enter sends, Shift+Enter makes a new line
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (form.requestSubmit) form.requestSubmit(); else form.dispatchEvent(new Event('submit', { cancelable: true })); }
    });
  }

  toBottom();
  schedule();
})();
