<?php
// Self-hosted CAPTCHA: no third-party scripts, so it works under our strict Content-Security-Policy and offline.
// Image mode is drawn with GD (captcha.php); text mode is a small sum for screen-reader users or when GD is missing.
const CAPTCHA_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // no 0/O/1/I confusion

function captcha_new(string $mode = 'image'): array {
    if ($mode === 'image' && !function_exists('imagecreatetruecolor')) $mode = 'text';
    $q = null;
    if ($mode === 'image') {
        $a = ''; for ($i = 0; $i < 5; $i++) $a .= CAPTCHA_ALPHABET[random_int(0, strlen(CAPTCHA_ALPHABET) - 1)];
    } else {
        $x = random_int(2, 9); $y = random_int(2, 9);
        if (random_int(0, 1)) { $a = (string)($x + $y); $q = "What is $x plus $y?"; }
        else { if ($x < $y) [$x, $y] = [$y, $x]; $a = (string)($x - $y); $q = "What is $x minus $y?"; }
    }
    return $_SESSION['captcha'] = ['mode' => $mode, 'answer' => $a, 'q' => $q, 'at' => time(), 'id' => bin2hex(random_bytes(4))];
}
/** The live challenge (reused across page loads until it is answered or 10 minutes pass). */
function captcha_current(): array {
    $c = $_SESSION['captcha'] ?? null;
    return (!$c || time() - $c['at'] > 600) ? captcha_new() : $c;
}
/** Single use: every answer attempt consumes the challenge, so a new one is shown next time. */
function captcha_check(string $input): bool {
    $c = $_SESSION['captcha'] ?? null; unset($_SESSION['captcha']);
    $ip = 'captcha:ip:' . client_ip();
    if (rate_blocked($ip, 30, 3600)) return false;
    $ok = $c && time() - $c['at'] <= 600 && hash_equals(strtolower($c['answer']), strtolower(trim($input)));
    if (!$ok) rate_hit($ip);
    return $ok;
}
function captcha_widget(): string {
    $c = captcha_current();
    if ($c['mode'] === 'image')
        return '<div class="captcha"><label>Security check<span class="captcha-row"><img src="' . e(url('captcha.php?v=' . $c['id'])) . '" width="170" height="58" alt="Security code image. Characters are not case sensitive.">'
             . '<input name="captcha" maxlength="8" autocomplete="off" autocapitalize="off" spellcheck="false" required></span><span class="hint">Type the characters you see (not case sensitive).</span></label></div>';
    return '<div class="captcha"><label>Security question: ' . e($c['q']) . '<input name="captcha" inputmode="numeric" maxlength="3" autocomplete="off" required></label></div>';
}
/** Place AFTER the main submit button, so pressing Enter in a field still submits the main button. */
function captcha_switch_button(): string {
    $to = captcha_current()['mode'] === 'image' ? 'text' : 'image';
    return '<button class="linklike dark" name="captcha_switch" value="' . $to . '" formnovalidate>' . ($to === 'text' ? "Can't read the image? Use a simple question instead" : 'Use the image instead') . '</button>';
}
