<?php
// UC-16 Conversations about an inquiry (adopter <-> shelter staff). "Real time" is AJAX polling (see assets/js/chat.js).
const CHAT_MAX_LEN = 1000;

/** Send a JSON response. Pending after-response work (emails) is allowed to finish after the body is delivered. */
function respond_json(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if (!empty($GLOBALS['after_response'])) { header('Content-Length: ' . strlen($json)); header('Connection: close'); }
    echo $json;
    exit;
}

function chat_inquiry(int $id): ?array {
    return q('SELECT i.*, p.pet_name, p.shelter_id, p.status AS pet_status, s.shelter_name, s.contact_email AS shelter_email, s.account_status AS shelter_status,
                a.first_name AS a_first, a.last_name AS a_last, a.email AS a_email, a.profile_photo AS a_photo
              FROM adoption_inquiries i JOIN pets p ON p.pet_id = i.pet_id JOIN shelters s ON s.shelter_id = p.shelter_id JOIN users a ON a.user_id = i.adopter_id
              WHERE i.inquiry_id = ?', [$id])->fetch() ?: null;
}
/** Who is this user in this conversation? adopter | staff | admin (admins only once a participant reported it) | null (no access) */
function chat_viewer(array $i, array $u): ?string {
    if ($u['role'] === 'adopter' && (int)$i['adopter_id'] === (int)$u['user_id']) return 'adopter';
    if ($u['role'] === 'staff' && $u['shelter_id'] && (int)$u['shelter_id'] === (int)$i['shelter_id']) return 'staff';
    if ($u['role'] === 'admin' && $i['chat_reported_at']) return 'admin';
    return null;
}
/** Why this viewer cannot send, or null when the conversation is open to them. */
function chat_closed_reason(array $i, string $viewer, array $u): ?string {
    if ($viewer === 'admin') return 'You are viewing this reported conversation as an administrator (read-only).';
    if ($i['chat_locked']) return 'This conversation was locked by an administrator.';
    if (in_array($i['status'], ['rejected', 'withdrawn'], true)) return 'This inquiry is ' . $i['status'] . ', so the conversation is closed. You can still read the history.';
    if ($viewer === 'staff' && !shelter_ready($u)) return 'Your shelter account is not active, so you cannot send messages.';
    if ($viewer === 'adopter' && $i['shelter_status'] !== 'active') return 'This shelter is currently unavailable.';
    return null;
}
// SQL comparators on sender_id vs the adopter: messages from the OTHER side / from MY side
function chat_other_cmp(string $viewer): string { return $viewer === 'adopter' ? '<>' : '='; }
function chat_my_cmp(string $viewer): string { return $viewer === 'adopter' ? '=' : '<>'; }

function chat_format(array $m, array $i, string $viewer, array $u): array {
    $side = (int)$m['sender_id'] === (int)$i['adopter_id'] ? 'adopter' : 'shelter';
    $mine = $viewer !== 'admin' && (($side === 'adopter') === ($viewer === 'adopter'));
    if ((int)$m['sender_id'] === (int)$u['user_id']) $name = 'You';
    else $name = $side === 'shelter' ? $m['first_name'] . ' (' . $i['shelter_name'] . ')' : trim($m['first_name'] . ' ' . $m['last_name']);
    $ts = strtotime($m['created_at']);
    return ['id' => (int)$m['message_id'], 'mine' => $mine, 'side' => $side, 'name' => $name, 'body' => $m['body'],
            'time' => date('Y-m-d', $ts) === date('Y-m-d') ? date('g:i A', $ts) : date('M j, g:i A', $ts)];
}
function chat_messages(array $i, string $viewer, array $u, int $after = 0, int $limit = 200): array {
    $rows = q('SELECT m.*, u.first_name, u.last_name FROM inquiry_messages m JOIN users u ON u.user_id = m.sender_id
               WHERE m.inquiry_id = ? AND m.message_id > ? ORDER BY m.message_id DESC LIMIT ' . (int)$limit, [$i['inquiry_id'], $after])->fetchAll();
    return array_map(fn($m) => chat_format($m, $i, $viewer, $u), array_reverse($rows));
}
function chat_mark_read(array $i, string $viewer): void {
    if ($viewer === 'admin') return;
    q('UPDATE inquiry_messages SET read_at = NOW() WHERE inquiry_id = ? AND read_at IS NULL AND sender_id ' . chat_other_cmp($viewer) . ' ?', [$i['inquiry_id'], $i['adopter_id']]);
}
/** Highest id of MY side's messages that the other side has read (drives the "Seen" label). */
function chat_seen_upto(array $i, string $viewer): int {
    if ($viewer === 'admin') return 0;
    return (int)q('SELECT COALESCE(MAX(message_id), 0) FROM inquiry_messages WHERE inquiry_id = ? AND read_at IS NOT NULL AND sender_id ' . chat_my_cmp($viewer) . ' ?', [$i['inquiry_id'], $i['adopter_id']])->fetchColumn();
}

function unread_count(array $u): int {
    if ($u['role'] === 'adopter')
        return (int)q('SELECT COUNT(*) FROM inquiry_messages m JOIN adoption_inquiries i ON i.inquiry_id = m.inquiry_id
                       WHERE i.adopter_id = ? AND m.sender_id <> i.adopter_id AND m.read_at IS NULL', [$u['user_id']])->fetchColumn();
    if ($u['role'] === 'staff' && $u['shelter_id'])
        return (int)q('SELECT COUNT(*) FROM inquiry_messages m JOIN adoption_inquiries i ON i.inquiry_id = m.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
                       WHERE p.shelter_id = ? AND m.sender_id = i.adopter_id AND m.read_at IS NULL', [$u['shelter_id']])->fetchColumn();
    return 0;
}
function reported_chat_count(): int { return (int)q('SELECT COUNT(*) FROM adoption_inquiries WHERE chat_reported_at IS NOT NULL')->fetchColumn(); }
/** Number shown on the navigation badge: unread messages (adopter, staff) or reported chats (admin). */
function nav_unread(array $u): int { return $u['role'] === 'admin' ? reported_chat_count() : unread_count($u); }
function count_badge(int $n): string { return '<span class="count" data-unread' . ($n > 0 ? '' : ' hidden') . '>' . $n . '</span>'; }

/** @return array ['ok'=>true,'message'=>row] or ['ok'=>false,'error'=>text,'status'=>http code] */
function chat_send(array $i, string $viewer, array $u, string $body): array {
    $fail = fn(string $e, int $s) => ['ok' => false, 'error' => $e, 'status' => $s];
    $body = trim(str_replace(["\r\n", "\r"], "\n", $body));   // browsers submit line breaks as CRLF: store plain \n
    if ($viewer === 'admin' || ($reason = chat_closed_reason($i, $viewer, $u))) return $fail($reason ?? 'Administrators cannot send messages here.', 403);
    if ($body === '') return $fail('Type a message first.', 400);
    if (str_len($body) > CHAT_MAX_LEN) return $fail('Messages can be up to ' . CHAT_MAX_LEN . ' characters.', 400);
    $uid = (int)$u['user_id'];
    if (rate_blocked("chat:min:$uid", 20, 60) || rate_blocked("chat:hour:$uid", 300, 3600)) return $fail('You are sending messages too quickly. Please wait a moment.', 429);
    // the other side was already alerted if one of MY earlier messages is still unread: then do not email again
    $alerted = (bool)q('SELECT 1 FROM inquiry_messages WHERE inquiry_id = ? AND read_at IS NULL AND sender_id ' . chat_my_cmp($viewer) . ' ? LIMIT 1', [$i['inquiry_id'], $i['adopter_id']])->fetch();
    q('INSERT INTO inquiry_messages (inquiry_id, sender_id, body) VALUES (?,?,?)', [$i['inquiry_id'], $uid, $body]);
    $id = (int)db()->lastInsertId();
    rate_hit("chat:min:$uid"); rate_hit("chat:hour:$uid");
    if (!$alerted) notify_chat_message($i, $viewer, $u);
    $row = q('SELECT m.*, u.first_name, u.last_name FROM inquiry_messages m JOIN users u ON u.user_id = m.sender_id WHERE m.message_id = ?', [$id])->fetch();
    return ['ok' => true, 'message' => chat_format($row, $i, $viewer, $u)];
}
/** Email alert: says WHO wrote and about WHICH pet, never the message text. */
function notify_chat_message(array $i, string $viewer, array $u): void {
    if ($viewer === 'adopter') { $to = $i['shelter_email']; $who = $u['first_name'] . ' ' . $u['last_name']; }
    else { $to = $i['a_email']; $who = $i['shelter_name']; }
    $subject = 'New message about ' . $i['pet_name'];
    send_mail_later($to, $subject, mail_layout($subject,
        '<p><b>' . e($who) . '</b> sent you a message about <b>' . e($i['pet_name']) . '</b>.</p><p>For your privacy the message itself is not included in this email.</p>'
        . mail_button('Open conversation', 'chat.php?inquiry=' . (int)$i['inquiry_id'])));
    $link = 'chat.php?inquiry=' . (int)$i['inquiry_id'];
    if ($viewer === 'adopter') notify_users(shelter_staff_ids((int)$i['shelter_id']), 'message', $subject, 'From ' . $who, $link);
    else notify_user((int)$i['adopter_id'], 'message', $subject, 'From ' . $who, $link);
}
function chat_report(array $i, string $viewer, array $u, string $reason): ?string {
    if (!in_array($viewer, ['adopter', 'staff'], true)) return 'Only the people in this conversation can report it.';
    if ($i['chat_reported_at']) return 'This conversation was already reported.';
    if (str_len($reason) > 200) return 'Please keep the reason under 200 characters.';
    if (rate_blocked('chatreport:user:' . $u['user_id'], 5, 86400)) return 'You have sent several reports today. Please wait before sending more.';
    q('UPDATE adoption_inquiries SET chat_reported_at = NOW(), chat_reported_by = ?, chat_report_reason = ? WHERE inquiry_id = ? AND chat_reported_at IS NULL', [$u['user_id'], $reason ?: null, $i['inquiry_id']]);
    rate_hit('chatreport:user:' . $u['user_id']);
    notify_users(admin_ids(), 'chat_report', 'A conversation was reported', $i['pet_name'], 'admin/moderation.php?tab=chats');
    return null;
}
