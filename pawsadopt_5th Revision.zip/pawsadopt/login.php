<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Log in'; $error = '';
// UC-02 Log in, with lockout after repeated failures (per account and per IP)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(substr(trim($_POST['email'] ?? ''), 0, 150)); $ip = client_ip();
    if (rate_blocked("login:email:$email", 5, 900) || rate_blocked("login:ip:$ip", 25, 900)) {
        $error = 'Too many failed attempts. Please wait 15 minutes and try again.';
    } else {
        $row = q('SELECT * FROM users WHERE email = ?', [$email])->fetch();
        // Always run password_verify (even for unknown emails) so response time does not reveal which emails exist
        $valid = password_verify($_POST['password'] ?? '', $row['password_hash'] ?? '$2y$10$DUmH0Yo9YbzZDq/D24hUUOsieC7m7gdH/86kwX46IxH.ccvPw3UeW') && $row;
        if (!$valid) {
            rate_hit("login:email:$email"); rate_hit("login:ip:$ip");
            $error = 'Email or password is incorrect.';
        } elseif ($row['account_status'] !== 'active') {
            $error = 'This account is suspended. Contact the administrator.';
        } else {
            rate_clear("login:email:$email");
            if ($row['role'] === 'admin' && ADMIN_2FA && $row['email_verified_at']) {      // two-step sign-in for admins with a verified email
                if (otp_issue($row, 'admin_login', 'Your PawsAdopt admin sign-in code', 'Use this code to finish signing in to the PawsAdopt admin area.')) {
                    $_SESSION['pending_2fa'] = ['uid' => (int)$row['user_id'], 'at' => time()];
                    redirect('verify_login.php');
                }
                $error = 'Too many sign-in codes were requested. Please wait and try again.';
            } else {
                login_user($row);
                flash('success', 'Welcome back, ' . $row['first_name'] . '.');
                redirect(home_for($row));
            }
        }
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Log in</h1>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required autofocus></label>
    <label>Password<input type="password" name="password" required></label>
    <button class="btn">Log in</button>
  </form>
  <p class="muted"><a href="<?= url('forgot_password.php') ?>">Forgot your password?</a> &middot; <a href="<?= url('register.php') ?>">Create an account</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
