(function () {
  'use strict';

  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle'), nav = document.getElementById('nav');
  if (toggle && nav) toggle.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
  });

  // Confirm dialogs: <button data-confirm="Are you sure?">
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-confirm]');
    if (el && !window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
  });

  // Pet gallery: click a thumbnail to swap the main photo
  var main = document.getElementById('mainPhoto');
  document.querySelectorAll('.thumbs .t').forEach(function (t) {
    t.addEventListener('click', function () {
      if (main) main.src = t.dataset.src;
      document.querySelectorAll('.thumbs .t').forEach(function (o) { o.classList.remove('on'); });
      t.classList.add('on');
    });
  });

  // Password match check: <form data-match="password,confirm">
  document.querySelectorAll('form[data-match]').forEach(function (form) {
    var names = form.dataset.match.split(','), a = form.elements[names[0]], b = form.elements[names[1]];
    if (!a || !b) return;
    function check() { b.setCustomValidity(a.value && b.value && a.value !== b.value ? 'Passwords do not match.' : ''); }
    a.addEventListener('input', check); b.addEventListener('input', check);
  });

  // Image previews before upload: <input type="file" data-preview="#box">
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      var box = document.querySelector(input.dataset.preview);
      if (!box) return;
      box.innerHTML = '';
      Array.prototype.forEach.call(input.files, function (file) {
        if (file.size > 5 * 1024 * 1024) { alert(file.name + ' is over 5 MB and will be rejected.'); return; }
        var img = document.createElement('img'); img.alt = file.name; img.src = URL.createObjectURL(file); box.appendChild(img);
      });
    });
  });

  // Donation posts show the target amount field
  var type = document.getElementById('postType'), amount = document.getElementById('amountField');
  if (type && amount) {
    var sync = function () {
      var donation = type.value === 'donation';
      amount.hidden = !donation;
      amount.querySelector('input').required = donation;
    };
    type.addEventListener('change', sync); sync();
  }

  // PH mobile inputs: digits only, max 11 (09XXXXXXXXX)
  document.querySelectorAll('input[data-ph]').forEach(function (input) {
    input.addEventListener('input', function () { input.value = input.value.replace(/\D/g, '').slice(0, 11); });
  });

  // Double-submit guard: after a valid submit, disable the buttons so a double-click cannot send the form twice
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      setTimeout(function () { if (e.defaultPrevented) return; form.querySelectorAll('button:not([type=button])').forEach(function (b) { b.disabled = true; }); }, 0);
    });
  });
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('form button:disabled').forEach(function (b) { b.disabled = false; });
  });

  // Character counters on limited textareas
  document.querySelectorAll('textarea[maxlength]').forEach(function (t) {
    var c = document.createElement('span'); c.className = 'hint'; t.parentNode.appendChild(c);
    var update = function () { c.textContent = t.value.length + ' / ' + t.maxLength; };
    t.addEventListener('input', update); update();
  });

  // Page-transition loader: a paw appears only if a click/submit is still loading after 120ms (fast pages never flash it).
  // It never delays navigation, and it is static (no motion) when the visitor prefers reduced motion (see the CSS).
  var loader = document.getElementById('pageLoader'), loaderTimer = null, loaderMax = null;
  function hideLoader() { clearTimeout(loaderTimer); clearTimeout(loaderMax); if (loader) { loader.classList.remove('on'); loader.hidden = true; } }
  function showLoader() {
    if (!loader) return;
    clearTimeout(loaderTimer); clearTimeout(loaderMax);
    loaderTimer = setTimeout(function () { loader.hidden = false; requestAnimationFrame(function () { loader.classList.add('on'); }); }, 120);
    loaderMax = setTimeout(hideLoader, 10000);                 // safety net, e.g. a download that never navigates
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if ((a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('data-no-loader')) return;
    var u; try { u = new URL(a.href, location.href); } catch (err) { return; }
    if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search && u.hash)) return;
    showLoader();
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-no-loader') || f.target === '_blank') return;
    setTimeout(function () { if (!e.defaultPrevented) showLoader(); }, 0);
  });
  window.addEventListener('pageshow', hideLoader);

  // Notification bell badge
  window.pawsSetNotif = function (n) {
    document.querySelectorAll('[data-notif]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
  };

  // Unread-message badge in the navigation: refreshed every 30s while the tab is visible (also updated by chat.js)
  window.pawsSetUnread = function (n) {
    document.querySelectorAll('[data-unread]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
  };
  var unreadUrl = document.body.dataset.unreadUrl;
  if (unreadUrl && window.fetch) {
    setInterval(function () {
      if (document.hidden) return;
      fetch(unreadUrl, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) { if (d && d.ok) { window.pawsSetUnread(d.unread); if (typeof d.notifications !== 'undefined') window.pawsSetNotif(d.notifications); } })
        .catch(function () {});
    }, 30000);
  }

  // Success flashes fade after a few seconds
  document.querySelectorAll('.flash-success').forEach(function (f) {
    setTimeout(function () { f.style.transition = 'opacity .6s'; f.style.opacity = '0'; setTimeout(function () { f.remove(); }, 700); }, 5000);
  });
})();
