<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (empty($_SESSION['reset_email'])) redirect('forgot_password.php');
$title = 'Enter code'; $error = '';
// UC-03 Reset password, step 2: verify the code and set a new password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw = $_POST['password'] ?? '';
    $uid = (int)q("SELECT user_id FROM users WHERE email = ? AND account_status = 'active'", [$_SESSION['reset_email']])->fetchColumn();
    if ($err = password_error($pw)) $error = $err;
    elseif ($pw !== ($_POST['confirm'] ?? '')) $error = 'Passwords do not match.';
    elseif (!$uid) $error = 'This code expired or was tried too many times. Request a new one.';
    else {
        $res = otp_verify($uid, 'reset', $_POST['code'] ?? '');
        if ($res === 'expired') $error = 'This code expired or was tried too many times. Request a new one.';
        elseif ($res === 'bad') $error = 'That code is not correct.';
        else {
            // reaching the mailbox proves the email address too
            q('UPDATE users SET password_hash = ?, must_change_password = 0, email_verified_at = COALESCE(email_verified_at, NOW()) WHERE user_id = ?', [password_hash($pw, PASSWORD_DEFAULT), $uid]);
            bump_session($uid);                              // log out every device that was signed in
            rate_clear('login:email:' . $_SESSION['reset_email']);
            unset($_SESSION['reset_email']);
            flash('success', 'Password updated. Log in with your new password.');
            redirect('login.php');
        }
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Enter your code</h1>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?>
    <label>6-digit code<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required autofocus></label>
    <label>New password<input type="password" name="password" minlength="8" maxlength="72" required><span class="hint">8+ characters with a letter and a number.</span></label>
    <label>Confirm new password<input type="password" name="confirm" minlength="8" maxlength="72" required></label>
    <button class="btn">Update password</button>
  </form>
  <p class="muted"><a href="<?= url('forgot_password.php') ?>">Send a new code</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
