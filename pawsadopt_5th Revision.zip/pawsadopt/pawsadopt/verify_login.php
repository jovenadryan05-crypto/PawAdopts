<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$p = $_SESSION['pending_2fa'] ?? null;
if (!$p || time() - $p['at'] > 600) { unset($_SESSION['pending_2fa']); flash('error', 'Your sign-in expired. Please log in again.'); redirect('login.php'); }
$row = q("SELECT * FROM users WHERE user_id = ? AND role = 'admin' AND account_status = 'active'", [$p['uid']])->fetch();
if (!$row) { unset($_SESSION['pending_2fa']); redirect('login.php'); }
$title = 'Two-step sign-in'; $error = '';
// Step 2 of admin sign-in: the password was right, now confirm with the code emailed to the admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'resend') {
        if (otp_issue($row, 'admin_login', 'Your PawsAdopt admin sign-in code', 'Use this code to finish signing in to the PawsAdopt admin area.')) flash('success', 'A new code was sent to your email.');
        else flash('error', 'Too many codes requested. Please wait and try again.');
        redirect('verify_login.php');
    }
    $res = otp_verify((int)$row['user_id'], 'admin_login', $_POST['code'] ?? '');
    if ($res === 'ok') {
        unset($_SESSION['pending_2fa']);
        login_user($row);
        flash('success', 'Welcome back, ' . $row['first_name'] . '.');
        redirect(home_for($row));
    }
    if ($res === 'expired') { unset($_SESSION['pending_2fa']); flash('error', 'That code expired or was tried too many times. Please log in again.'); redirect('login.php'); }
    $error = 'That code is not correct.';
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Check your email</h1>
  <p>We sent a 6-digit sign-in code to the administrator email on this account. It expires in 10 minutes.</p>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label>6-digit code<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required autofocus></label>
    <button class="btn">Sign in</button>
  </form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="resend"><button class="linklike dark">Send a new code</button></form>
  <p class="muted"><a href="<?= url('login.php') ?>">Start over</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
