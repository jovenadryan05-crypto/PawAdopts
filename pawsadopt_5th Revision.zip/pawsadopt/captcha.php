<?php
// Draws the CAPTCHA image for the challenge stored in the visitor's session.
require __DIR__ . '/includes/bootstrap.php';
$c = $_SESSION['captcha'] ?? null;
if (!$c || $c['mode'] !== 'image' || !function_exists('imagecreatetruecolor')) { http_response_code(404); exit; }
session_write_close();
$W = 170; $H = 58;
$im = imagecreatetruecolor($W, $H);
imagefilledrectangle($im, 0, 0, $W, $H, imagecolorallocate($im, random_int(232, 250), random_int(236, 250), random_int(238, 252)));
for ($i = 0; $i < 6; $i++) imageline($im, random_int(0, $W), random_int(0, $H), random_int(0, $W), random_int(0, $H), imagecolorallocate($im, random_int(150, 205), random_int(150, 205), random_int(150, 205)));
$answer = $c['answer']; $n = strlen($answer);
for ($i = 0; $i < $n; $i++) {
    $small = imagecreatetruecolor(14, 20);                         // draw one character on a tiny transparent canvas...
    imagealphablending($small, false); imagesavealpha($small, true);
    imagefill($small, 0, 0, imagecolorallocatealpha($small, 0, 0, 0, 127));
    imagechar($small, 5, 2, 2, $answer[$i], imagecolorallocate($small, random_int(10, 90), random_int(10, 90), random_int(40, 130)));
    $sz = random_int(27, 34); $sh = (int)round($sz * 1.4);        // ...then scale it up, rotate it a little, and place it with jitter
    $big = imagecreatetruecolor($sz, $sh);
    imagealphablending($big, false); imagesavealpha($big, true);
    imagefill($big, 0, 0, imagecolorallocatealpha($big, 0, 0, 0, 127));
    imagecopyresampled($big, $small, 0, 0, 0, 0, $sz, $sh, 14, 20);
    $rot = imagerotate($big, random_int(-24, 24), imagecolorallocatealpha($big, 0, 0, 0, 127));
    imagesavealpha($rot, true); imagealphablending($im, true);
    imagecopy($im, $rot, 6 + $i * 31 + random_int(-2, 2), random_int(0, 4), 0, 0, imagesx($rot), imagesy($rot));
}
for ($i = 0; $i < 4; $i++) imageline($im, random_int(0, 20), random_int(0, $H), random_int($W - 20, $W), random_int(0, $H), imagecolorallocate($im, random_int(90, 150), random_int(90, 150), random_int(90, 150)));
for ($i = 0; $i < 140; $i++) imagesetpixel($im, random_int(0, $W - 1), random_int(0, $H - 1), imagecolorallocate($im, random_int(80, 200), random_int(80, 200), random_int(80, 200)));
header('Content-Type: image/png'); header('Cache-Control: no-store');
imagepng($im);
