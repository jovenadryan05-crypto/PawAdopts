<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$admin = require_role('admin');
$title = 'Shelters'; $page = 'shelters';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $reason = trim($_POST['reason'] ?? '');
    $sh = q('SELECT * FROM shelters WHERE shelter_id=?', [$id])->fetch();
    if (!$sh) { flash('error', 'Shelter not found.'); redirect('admin/shelters.php'); }
    // UC-06 Approve or reject shelter
    if ($act === 'approve' && $sh['verification_status'] !== 'approved') {
        q("UPDATE shelters SET verification_status='approved', rejection_reason=NULL, reviewed_by=?, reviewed_at=NOW() WHERE shelter_id=?", [$admin['user_id'], $id]);
        audit('shelter_approved', 'shelter', $id, $sh['shelter_name']);
        send_mail_later($sh['contact_email'], 'Your shelter was approved on PawsAdopt',
            '<p>Good news: <b>' . e($sh['shelter_name']) . '</b> has been verified. You can now list pets, answer inquiries and post announcements.</p><p><a href="' . SITE_URL . '/staff/dashboard.php">Open your dashboard</a></p>');
        notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter was approved', $sh['shelter_name'], 'staff/dashboard.php');
        flash('success', 'Shelter approved and notified by email.');
    } elseif ($act === 'reject' && $sh['verification_status'] === 'pending') {
        if ($reason === '') flash('error', 'Give the shelter a reason for the rejection.');
        else {
            q("UPDATE shelters SET verification_status='rejected', rejection_reason=?, reviewed_by=?, reviewed_at=NOW() WHERE shelter_id=?", [$reason, $admin['user_id'], $id]);
            audit('shelter_rejected', 'shelter', $id, $sh['shelter_name'] . ': ' . $reason);
            send_mail_later($sh['contact_email'], 'Your PawsAdopt shelter registration needs changes',
                '<p>We could not approve <b>' . e($sh['shelter_name']) . '</b> yet.</p><p><b>Reason:</b> ' . e($reason) . '</p><p>Update your details and resubmit from your dashboard.</p>');
            notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter registration needs changes', $reason, 'staff/dashboard.php');
            flash('success', 'Shelter rejected and notified by email.');
        }
    } elseif ($act === 'suspend' || $act === 'activate') {       // UC-15 manage accounts
        q('UPDATE shelters SET account_status=? WHERE shelter_id=?', [$act === 'suspend' ? 'suspended' : 'active', $id]);
        audit('shelter_' . ($act === 'suspend' ? 'suspended' : 'reactivated'), 'shelter', $id, $sh['shelter_name']);
        flash('success', 'Shelter ' . ($act === 'suspend' ? 'suspended; its listings are hidden.' : 'reactivated.'));
    }
    redirect('admin/shelters.php?s=' . urlencode($_GET['s'] ?? 'pending'));
}
$filter = $_GET['s'] ?? 'pending';
$valid = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($filter, $valid, true)) $filter = 'pending';
$cond = $filter === 'all' ? '' : 'WHERE s.verification_status=?'; $args = $filter === 'all' ? [] : [$filter];
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM shelters s $cond", $args)->fetchColumn(), 15);
$rows = q("SELECT s.*, (SELECT COUNT(*) FROM pets p WHERE p.shelter_id=s.shelter_id) AS pet_count,
            (SELECT CONCAT(first_name,' ',last_name) FROM users WHERE shelter_id=s.shelter_id ORDER BY user_id LIMIT 1) AS staff_name
           FROM shelters s $cond ORDER BY s.created_at DESC LIMIT 15 OFFSET $off", $args)->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Shelters</h1>
<div class="tabs"><?php foreach ($valid as $s): ?><a class="<?= $filter === $s ? 'on' : '' ?>" href="?s=<?= $s ?>"><?= ucfirst($s) ?></a><?php endforeach; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'all' ? '' : e($filter) . ' ' ?>shelters</h2></div><?php endif; ?>
<?php foreach ($rows as $s): ?>
<article class="panel">
  <div class="split"><h2><?= e($s['shelter_name']) ?></h2><span><?= badge($s['verification_status']) ?> <?php if ($s['account_status'] === 'suspended') echo badge('suspended'); ?></span></div>
  <p class="small muted"><?= e($s['address']) ?> &middot; <?= e($s['contact_email']) ?> &middot; <?= e($s['contact_number']) ?><br>
    Registered by <?= e($s['staff_name'] ?: 'unknown') ?> on <?= fdate($s['created_at']) ?> &middot; <?= (int)$s['pet_count'] ?> pet(s)</p>
  <?php if ($s['rejection_reason']): ?><p class="small"><strong>Rejection reason:</strong> <?= e($s['rejection_reason']) ?></p><?php endif; ?>
  <p><a href="<?= url('admin/document.php?id=' . $s['shelter_id']) ?>" target="_blank" rel="noopener">View verification document</a></p>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['shelter_id'] ?>">
    <?php if ($s['verification_status'] !== 'approved'): ?>
      <label>Rejection reason (required to reject)<input name="reason" maxlength="255" placeholder="e.g. Document is unreadable"></label>
    <?php endif; ?>
    <div class="actions">
      <?php if ($s['verification_status'] !== 'approved'): ?><button class="btn" name="action" value="approve">Approve</button><?php endif; ?>
      <?php if ($s['verification_status'] === 'pending'): ?><button class="btn btn-danger" name="action" value="reject">Reject</button><?php endif; ?>
      <?php if ($s['verification_status'] === 'approved'): ?>
        <?php if ($s['account_status'] === 'active'): ?><button class="btn btn-danger" name="action" value="suspend" data-confirm="Suspend this shelter and hide its listings?">Suspend shelter</button>
        <?php else: ?><button class="btn btn-ghost" name="action" value="activate">Reactivate shelter</button><?php endif; ?>
      <?php endif; ?>
    </div>
  </form>
</article>
<?php endforeach; ?>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
