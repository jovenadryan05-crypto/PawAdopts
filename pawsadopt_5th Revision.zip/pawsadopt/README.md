# PawsAdopt: Pet Adoption System (PHP + MySQL + CSS + JS)

Built from the project's UML use case, Level 0 DFD, class diagram and ERD.
Plain PHP 8+ with PDO, MySQL/MariaDB, vanilla CSS and JS. PHPMailer is bundled (includes/PHPMailer).

## Fresh install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\pawsadopt`.
2. Copy `config/config.example.php` to `config/config.php` and edit it (database, BASE_URL, email).
3. Start Apache and MySQL. In phpMyAdmin > Import, choose `database/schema.sql`
   (WARNING: it starts with DROP DATABASE, so only use it on a fresh install).
4. Make sure `extension=gd` is enabled in `php.ini` (it is by default in XAMPP). Photos are re-encoded with GD.
5. Visit http://localhost/pawsadopt
   Default admin: `admin@pawsadopt.local` / `Admin@12345`. You are forced to change it at first login.

## Updating an existing install
1. **Back up first**: phpMyAdmin > pawsadopt > Export.
2. phpMyAdmin > pawsadopt > SQL: run the migration(s) you have not run yet, in order. Never import `schema.sql` on a database you want to keep (it starts with DROP DATABASE).
   - from the original version: `001`, `002`, `003`, `004` (in `database/migrations/`)
   - from batch 1: `002`, `003`, `004`;  from batch 2: `003`, `004`;  from batch 3: only `004_verification_notifications_timeline.sql`
3. Unzip this package over your project folder. `config/config.php` is not in the package, so your settings are kept.
   See `config/config.example.php` for optional settings (APP_DEBUG, SESSION_IDLE, PRIVATE_DIR, ADMIN_2FA).
4. The contact email shown in the Terms and Privacy Notice defaults to your `MAIL_FROM`; to use another address add
   `define('SITE_CONTACT_EMAIL', 'privacy@yourdomain.ph');` to config.php.
5. The legal text changed again, so `TERMS_VERSION` is now `2026-10.3`: everyone accepts it at their next login (intended).
6. **Existing users must verify their email once** (they can still browse). Existing shelters should add their city and province (a hint appears on their dashboard).
7. **Admin:** set a real email in Profile and verify it. From then on every admin sign-in also needs a code emailed to that address.
   Until the admin email is verified, two-step sign-in stays off (so the seeded fake address cannot lock you out).
   If email ever breaks, set `define('ADMIN_2FA', false);` in config.php to sign in with the password only, then fix the email.

## What changed in batch 4
- **Email verification** (`verify_email.php`): a 6-digit code (hashed, 10 minutes, 5 tries, 3 sends per hour). Unverified adopters and staff can browse, but cannot send inquiries or use chat. Changing your email needs your current password and re-verifies it. Resetting a password by emailed code also proves the email. The same one-time-code module (`includes/otp.php`, column `password_resets.purpose`) serves password reset, verification and admin sign-in, and codes of one purpose never work for another.
- **Admin two-step sign-in** (`verify_login.php`): after the password, a code is emailed to the admin (only when the admin's email is verified).
- **CAPTCHA** on sign-up and forgot-password (the two forms that send email), self-hosted so it fits the strict Content-Security-Policy: an image drawn with GD (`captcha.php`) or, for screen-reader users or when GD is missing, a simple text question. Single use, 10 minutes, case-insensitive, failures rate limited. It deters casual bots; it is not a defence against determined attackers or modern AI solvers.
- **Notifications**: bell icon with an unread count (refreshes every 30s), `notifications.php` list, mark-all-read, kept 90 days. Created wherever an email is sent (new inquiry, decisions, meetings, messages, shelter approval, reports, story requests).
- **Locations and pet details**: shelters now have city and province (required; pets inherit them, no retyping). Pets have size, vaccinated, spayed/neutered, good with kids. The browse page filters by location, size and the three yes/no details.
- **Adoption timeline** (table `inquiry_events`): sent, under review, meeting scheduled (with date), approved, revoked, withdrawn, adopted, closed because another applicant was adopted, closed because the listing was removed. Shown to the adopter and the shelter. `adoption_inquiries.status` is deliberately unchanged, so the unique keys that prevent duplicates and double approvals keep working. Staff can mark an inquiry "under review" and schedule meetings.
- **Success stories** (`staff/stories.php`, `stories.php`): a shelter writes a story for an adopted pet; the adopter is asked and chooses yes with first name and photo, yes anonymously, or no, and can change this any time. Editing the text asks for consent again. Admins can hide stories; a suspended shelter or a deleted adopter removes them from the public page.
- **Admin dashboard charts** (inquiries and adoptions per month) drawn as plain SVG, with no JavaScript library.
- **Page-transition loader**: a small paw appears only if a click or form submit is still loading after 120 ms, never delays navigation, and is static for visitors who prefer reduced motion.
- The CSP is unchanged (`script-src 'self'`); nothing in this batch needs an external script, inline script or inline style.

## What changed in batch 3
- **Conversations about an inquiry** (`chat.php`, `chat_api.php`, `assets/js/chat.js`, table `inquiry_messages`): adopter and the shelter's staff can message each other while the inquiry is pending or approved.
  "Real time" is AJAX polling every 3 seconds (paused while the tab is hidden, backs off on errors); it works on plain XAMPP with no extra software. Without JavaScript the page still works with normal form posts.
- Unread badge in the navigation (refreshes every 30s and instantly on the chat page), "Seen" marker under your last read message, Enter to send / Shift+Enter for a new line.
- **Rules:** only the adopter and staff of that shelter can read or send; messages are plain text (max 1000 chars, always escaped); 20 per minute and 300 per hour per user; the conversation becomes read-only when the inquiry is rejected or withdrawn, or when an administrator locks it.
- **Email alerts:** the other side is emailed about a new message only when they have nothing unread from you yet. The email names the sender and the pet but never contains the message text.
- **Moderation:** either participant can report a conversation. Only then can an administrator open it (read-only, every view is written to the audit log), lock/unlock it, or dismiss the report: Admin > Moderation > Reported conversations. Admins see a badge with the number of reported chats.
- **Privacy:** conversation text is included in the data export and is erased when the adopter deletes their account. The Privacy Notice and Terms describe all of this.
- Small fix: elements with the `hidden` attribute are now really hidden (the donation "target amount" field only appears for donation posts).

## What changed in batch 2
- **Terms and Conditions + Privacy Notice** (`terms.php`, `privacy.php`, RA 10173): sign-up requires an unticked-by-default acceptance checkbox; acceptance time and version are stored (`users.consent_at`, `users.terms_version`).
  Bump `TERMS_VERSION` (bootstrap default, or define it in config.php) after editing the legal text and everyone must accept again (`consent.php`).
- **Data subject rights** (Profile > Your data and privacy): download your data as JSON, and delete your account. Deletion anonymises the account
  (name, email, mobile, photo and profile details removed; inquiry messages erased; open inquiries withdrawn; a reserved pet is released). Business records stay without personal data.
- **Richer profiles:** profile photo (cropped to a 400x400 square, EXIF removed), city, bio; adopters: housing, other pets, pet experience; staff: job title.
  Staff see the adopter's profile when reviewing an inquiry, and the inquiry box is pre-filled from the adopter's profile.
- **Inquiry emailed to the shelter** (its contact email) with the adopter's details and message; adopters are emailed when a shelter approves, rejects, revokes, or the pet is adopted by someone else.
  Emails are sent after the page response (`send_mail_later`), so a slow mail server never slows a page, holds the session lock, or loses an inquiry; failures go to `logs/php_error.log`.
  The reset-code request also uses it, so response time no longer reveals whether an email is registered. SMTP waits are capped at 12 seconds.
- 10 inquiries per adopter per hour. New columns on `users`: profile_photo, bio, city, position, housing_type, other_pets, pet_experience, consent_at, terms_version; `account_status` gains the value `deleted`.

## What changed in batch 1
**Security**
- Login lockout: 5 failed attempts per account (25 per IP) blocks for 15 minutes. Reset-code requests, sign-ups and invite-code tries are rate limited too (table `rate_limits`).
- Forced password change for the default admin; password policy (8-72 chars, letter + number) everywhere.
- Changing or resetting a password signs out the user's other devices (`users.session_version`); 30-minute idle timeout.
- One-time-code password reset: 6-digit code, stored hashed, 10 minutes, 5 tries, single use, neutral responses (no account guessing), max 3 requests/hour/account.
- Errors are logged to `logs/php_error.log`, never shown (set APP_DEBUG=true only while developing). Security headers (CSP, X-Frame-Options, nosniff, Referrer-Policy; HSTS on HTTPS). Cookies are HttpOnly + SameSite.
- Verification documents are stored outside the web root and streamed to admins only. Uploaded photos are re-encoded (EXIF/GPS and hidden code removed), resized to 1600px, and size-limited.
- Admin audit log (`admin_audit_log`, page: Admin > Audit log). Emails to shelters on approval/rejection.
- Least-privilege database user: `database/create_app_user.sql`.

**Logic**
- DB-level unique keys: one active inquiry per adopter+pet, one approved inquiry per pet (blocks double-clicks and races).
- `set_pet_status()` is the single place pet status changes; marking a pet adopted or removing a listing closes the affected inquiries. A pet cannot be set back to available while an approval exists; staff can revoke an approval.
- Staff can only approve while the pet is available. Dates use Asia/Manila. Admin lists are paginated.
- Shelters get an invite code so more than one staff member can join (the ERD allows 1..*).
- Sign-up requires confirming age 18+. Donation posts show the shelter's contact and a "no payments handled here" notice.

**PH contact numbers**: mobile numbers must be 11 digits starting with 09 (spaces, dashes and +63 are normalized). Shelters may also use a landline with area code. Enforced on the server and in the form.

## Use case coverage
| UC | Feature | File |
|----|---------|------|
| 01 | Register account | register.php |
| 02 | Log in / out | login.php, logout.php |
| 03 | Reset password (emailed code) | forgot_password.php, reset_password.php |
| 04 | Manage profile (photo, details, data export, delete account) | profile.php |
| 05 | Register shelter profile | staff/shelter.php |
| 06 | Approve or reject shelter | admin/shelters.php |
| 07 | Manage pet listings (+ photos) | staff/pets.php, staff/pet_form.php |
| 08 | Browse and search pets | index.php |
| 09 | View pet details | pet.php |
| 10 | Submit adoption inquiry | pet.php |
| 11 | View and withdraw inquiries | adopter/inquiries.php |
| 12 | Process adoption inquiries | staff/inquiries.php |
| 13 | Manage announcements & donations | staff/posts.php |
| 14 | View announcements & donations | announcements.php |
| 16 | Conversation about an inquiry | chat.php, chat_api.php |
| 19 | Verify email | verify_email.php |
| 20 | View notifications | notifications.php |
| 21 | Track adoption timeline / schedule a meeting | adopter/inquiries.php, staff/inquiries.php |
| 22 | Share and consent to a success story | staff/stories.php, adopter/inquiries.php, stories.php |
| 23 | Admin two-step sign-in (extends UC-02) | verify_login.php |
| 17 | Report a conversation / review reported conversations | chat.php, admin/moderation.php |
| 15 | Moderate content & manage accounts | admin/users.php, admin/moderation.php, admin/shelters.php, admin/audit.php |

## Legal pages
The Terms and Privacy Notice are templates written to match what the system actually does. Have your adviser or Data Protection Officer review them before launch.

## Email
Set MAIL_* in config.php (Gmail needs an App Password). If `MAIL_HOST` is left empty, emails are written to `logs/mail.log`
instead of being sent, which is handy while developing (reset codes appear there).

## Tables
The DFD data stores (users, shelters, pets, pet_photos, adoption_inquiries, announcements_donations) plus `inquiry_messages` (D7, conversations), `inquiry_events` (D8, timeline), `success_stories` (D9), plus the support
tables that are not business entities: `rate_limits`, `password_resets`, `admin_audit_log`, `notifications`. Add them to your ERD as "system/security tables".
