<?php
require __DIR__ . '/includes/bootstrap.php';
if ($u = user()) redirect(home_for($u));          // signed-in users go straight to their own home
$title = 'Welcome'; $page = 'home';
// Landing page: who we are, what we stand for, and where to log in or create an account.
$live = "s.verification_status = 'approved' AND s.account_status = 'active'";
$stat = [
    'pets'     => (int)q("SELECT COUNT(*) FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE p.status = 'available' AND $live")->fetchColumn(),
    'shelters' => (int)q("SELECT COUNT(*) FROM shelters s WHERE $live")->fetchColumn(),
    'adopted'  => (int)q("SELECT COUNT(*) FROM inquiry_events WHERE event_type = 'adopted'")->fetchColumn(),
];
$featured = q("SELECT p.pet_id, p.pet_name, p.species, p.breed, p.sex, p.age_months, s.shelter_name, s.city,
                 (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
               FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE p.status = 'available' AND $live ORDER BY p.created_at DESC LIMIT 4")->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<section class="landing-hero">
  <div class="lh-text">
    <p class="eyebrow">Adopt, don't shop</p>
    <h1>Every pet deserves a home that fits.</h1>
    <p>PawsAdopt connects Filipino adopters with verified animal shelters, so the right pet finds the right family, and shelters get the information they need to say yes with confidence.</p>
    <div class="actions">
      <a class="btn btn-lg" href="<?= url('register.php') ?>">Create an account</a>
      <a class="btn btn-ghost btn-lg" href="<?= url('login.php') ?>">Log in</a>
      <a class="btn-link" href="<?= url('pets.php') ?>">Browse pets first &rarr;</a>
    </div>
  </div>
  <div class="lh-stats">
    <div class="stat"><b><?= $stat['pets'] ?></b><span>Pets waiting for a home</span></div>
    <div class="stat"><b><?= $stat['shelters'] ?></b><span>Verified shelters</span></div>
    <div class="stat"><b><?= $stat['adopted'] ?></b><span>Adoptions completed</span></div>
  </div>
</section>

<section class="band" id="about">
  <h2 class="band-title">About us</h2>
  <div class="two-col">
    <p class="prose">PawsAdopt is a pet adoption platform built for the Philippines. We bring verified shelters and adopters into one place. Shelters list animals with honest details. Adopters see how well each pet fits their home and tell the shelter about their situation in a structured way. After the adoption, we help everyone follow up, so happy endings are real and shared.</p>
    <p class="prose">Every shelter is checked by an administrator before its pets appear. We do not sell animals, we do not handle payments, and we keep adopters' personal details private until they choose to send an inquiry.</p>
  </div>
</section>

<section class="band" id="mission">
  <div class="mv">
    <article class="mv-card"><h2>Our mission</h2><p>To make responsible adoption simple, transparent and trusted: helping shelters find committed homes faster, and helping adopters choose a pet they can care for for life.</p></article>
    <article class="mv-card alt"><h2>Our vision</h2><p>A Philippines where every pet waiting for a home is placed with a loving, prepared family, and where no pet is left waiting because information was missing.</p></article>
  </div>
</section>

<section class="band">
  <h2 class="band-title">What we stand for</h2>
  <div class="values">
    <div class="value"><span aria-hidden="true">&#128269;</span><h3>Transparency</h3><p>Public shelter profiles show adoptions, waiting pets and how fast shelters reply.</p></div>
    <div class="value"><span aria-hidden="true">&#129309;</span><h3>Right fit</h3><p>Match scores explain why a pet suits your home, and where to be careful.</p></div>
    <div class="value"><span aria-hidden="true">&#128274;</span><h3>Privacy</h3><p>Your details are shared only when you send an inquiry. Stories need your consent.</p></div>
    <div class="value"><span aria-hidden="true">&#128153;</span><h3>Lifelong care</h3><p>Check-ins after adoption keep pets and families supported.</p></div>
  </div>
</section>

<section class="band" id="how">
  <h2 class="band-title">How it works</h2>
  <div class="cols">
    <div class="panel"><h3>For adopters</h3>
      <ol class="steps"><li>Create a free account and add your home details.</li><li>Browse pets and see your match score.</li><li>Complete a short home-readiness checklist and send an inquiry.</li><li>Chat with the shelter, meet your pet, and send check-ins after adoption.</li></ol>
      <a class="btn" href="<?= url('register.php?as=adopter') ?>">Sign up as an adopter</a></div>
    <div class="panel"><h3>For shelters</h3>
      <ol class="steps"><li>Register your shelter with a verification document.</li><li>Once approved, create accounts for your employees and give them their credentials.</li><li>List pets with photos, receive structured inquiries and post announcements.</li><li>Share success stories and show your results publicly.</li></ol>
      <a class="btn btn-ghost" href="<?= url('register.php?as=shelter') ?>">Register your shelter</a></div>
  </div>
</section>

<?php if ($featured): ?>
<section class="band">
  <div class="split"><h2 class="band-title">Newest arrivals</h2><a href="<?= url('pets.php') ?>">See all pets &rarr;</a></div>
  <div class="grid">
  <?php foreach ($featured as $p): ?>
    <a class="card pet-card" href="<?= url('pet.php?id=' . $p['pet_id']) ?>">
      <div class="thumb"><?php if ($p['photo']): ?><img src="<?= url($p['photo']) ?>" alt="<?= e($p['pet_name']) ?>" loading="lazy"><?php else: ?><span class="ph">&#128062;</span><?php endif; ?></div>
      <div class="card-body"><h3><?= e($p['pet_name']) ?></h3>
        <p class="muted"><?= e($p['breed'] ?: $p['species']) ?> &middot; <?= e(ucfirst($p['sex'])) ?> &middot; <?= age_label((int)$p['age_months']) ?></p>
        <p class="small"><?= e($p['shelter_name']) ?><?= $p['city'] ? ' &middot; ' . e($p['city']) : '' ?></p></div>
    </a>
  <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="cta-band">
  <h2>Ready to meet your match?</h2>
  <p>Join PawsAdopt today. It takes two minutes.</p>
  <div class="actions center-actions"><a class="btn btn-lg" href="<?= url('register.php') ?>">Create an account</a><a class="btn btn-ghost btn-lg" href="<?= url('login.php') ?>">Log in</a></div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
