<?php
require_once __DIR__ . '/../config/config.php';

// ---- Defaults for optional settings, so an older config.php keeps working ----
defined('APP_DEBUG')       || define('APP_DEBUG', false);      // true = show PHP errors on screen (development only)
defined('SESSION_IDLE')    || define('SESSION_IDLE', 1800);    // log out after 30 idle minutes
defined('PRIVATE_DIR')     || define('PRIVATE_DIR', getenv('PAWS_PRIVATE_DIR') ?: dirname(__DIR__, 3) . '/pawsadopt_private');
defined('MAX_UPLOAD_BYTES')|| define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);
defined('PER_PAGE')        || define('PER_PAGE', 12);
foreach (['MAIL_HOST' => '', 'MAIL_PORT' => 587, 'MAIL_USER' => '', 'MAIL_PASS' => '', 'MAIL_FROM' => ''] as $k => $v) defined($k) || define($k, $v);
// Bump TERMS_VERSION whenever the Terms or Privacy Notice change: every user is then asked to accept again.
defined('TERMS_VERSION') || define('TERMS_VERSION', '2026-10.5');
defined('ADMIN_2FA') || define('ADMIN_2FA', true);   // emailed sign-in code for admins whose email is verified
defined('SITE_CONTACT_EMAIL') || define('SITE_CONTACT_EMAIL', MAIL_FROM !== '' ? MAIL_FROM : 'privacy@pawsadopt.example');
function is_https(): bool { return !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'; }
defined('SITE_URL') || define('SITE_URL', (is_https() ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL);

date_default_timezone_set('Asia/Manila');

// ---- Errors: log them, never show paths and stack traces to visitors ----
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
ini_set('error_log', $logDir . '/php_error.log');
set_exception_handler(function (Throwable $t) {
    error_log(get_class($t) . ': ' . $t->getMessage() . ' in ' . $t->getFile() . ':' . $t->getLine());
    http_response_code(500);
    if (APP_DEBUG) { echo '<pre>' . htmlspecialchars((string)$t) . '</pre>'; exit; }
    echo '<!DOCTYPE html><meta charset="utf-8"><title>Something went wrong</title><body style="font-family:sans-serif;max-width:520px;margin:12vh auto;padding:0 20px">'
       . '<h1>Something went wrong</h1><p>We could not complete that request. Please try again in a moment.</p><p><a href="' . htmlspecialchars(BASE_URL . '/index.php') . '">Back to PawsAdopt</a></p></body>';
    exit;
});

// ---- Security headers ----
if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; script-src 'self'; form-action 'self'; frame-src https://www.google.com https://maps.google.com https://www.openstreetmap.org; frame-ancestors 'none'; base-uri 'self'");
    if (is_https()) header('Strict-Transport-Security: max-age=31536000');
}

// ---- Session ----
ini_set('session.use_strict_mode', '1');
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => is_https()]);
    session_start();
}
if (!empty($_SESSION['uid'])) {
    if (time() - ($_SESSION['last'] ?? time()) > SESSION_IDLE) {
        unset($_SESSION['uid'], $_SESSION['sv']);
        $_SESSION['flash'][] = ['info', 'You were logged out after a period of inactivity. Please log in again.'];
    } else {
        $_SESSION['last'] = time();
    }
}

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+08:00'",
        ]);
    }
    return $pdo;
}
function q(string $sql, array $params = []): PDOStatement { $s = db()->prepare($sql); $s->execute($params); return $s; }

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return BASE_URL . '/' . ltrim($p, '/'); }
/**
 * Run a task AFTER the response has reached the browser (used for emails, so a slow mail server never slows a page
 * or holds the session lock). Only use it on requests that end in redirect().
 */
function after_response(callable $fn): void {
    static $registered = false;
    $GLOBALS['after_response'][] = $fn;
    if ($registered) return;
    $registered = true;
    register_shutdown_function(function () {
        ignore_user_abort(true); set_time_limit(90);
        session_write_close();                                   // release the session lock before the slow part
        if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
        else { while (ob_get_level() > 0) @ob_end_flush(); flush(); }
        foreach ($GLOBALS['after_response'] as $task) {
            try { $task(); } catch (Throwable $t) { error_log('Deferred task failed: ' . $t->getMessage()); }
        }
    });
}
function send_mail_later(string $to, string $subject, string $html): void { after_response(fn() => send_mail($to, $subject, $html)); }
function redirect(string $p): void {
    header('Location: ' . url($p));
    if (!empty($GLOBALS['after_response'])) { header('Content-Length: 0'); header('Connection: close'); }
    exit;
}
function old(string $k, $default = ''): string { return e($_POST[$k] ?? $default); }
function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }

function flash(?string $type = null, ?string $msg = null) {
    if ($type !== null) { $_SESSION['flash'][] = [$type, $msg]; return; }
    $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f;
}
function csrf_field(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Your form expired. Go back, refresh the page and try again.');
    }
}

// ---- Rate limiting (table rate_limits) ----
function rate_blocked(string $bucket, int $max, int $windowSeconds): bool {
    return (int)q('SELECT COUNT(*) FROM rate_limits WHERE bucket = ? AND created_at > NOW() - INTERVAL ? SECOND', [substr($bucket, 0, 190), $windowSeconds])->fetchColumn() >= $max;
}
function rate_hit(string $bucket): void {
    q('INSERT INTO rate_limits (bucket) VALUES (?)', [substr($bucket, 0, 190)]);
    if (random_int(1, 100) === 1) q('DELETE FROM rate_limits WHERE created_at < NOW() - INTERVAL 2 DAY');
}
function rate_clear(string $bucket): void { q('DELETE FROM rate_limits WHERE bucket = ?', [substr($bucket, 0, 190)]); }

// ---- Validation ----
function password_error(string $pw): ?string {
    if (strlen($pw) < 8) return 'Password must be at least 8 characters.';
    if (strlen($pw) > 72) return 'Password must be 72 characters or fewer.';
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) return 'Password must include at least one letter and one number.';
    return null;
}
/** Philippine mobile number: 11 digits starting with 09. Accepts spaces, dashes and +63/63 prefixes; returns 09XXXXXXXXX or null. */
function ph_mobile(string $raw): ?string {
    $n = preg_replace('/[\s\-().]/', '', $raw);
    if (preg_match('/^(\+63|63)(9\d{9})$/', $n, $m)) $n = '0' . $m[2];
    return preg_match('/^09\d{9}$/', $n) ? $n : null;
}
/** Shelter contact: a PH mobile, or a landline with area code (e.g. 02 8123 4567, 082 123 4567). */
function ph_contact(string $raw): ?string {
    if ($m = ph_mobile($raw)) return $m;
    $n = preg_replace('/[\s\-().]/', '', $raw);
    if (preg_match('/^\+?63([2-8]\d{7,9})$/', $n, $x)) $n = '0' . $x[1];
    return preg_match('/^0[2-8]\d{7,9}$/', $n) ? $n : null;
}

/** First/last names: letters (any language), spaces, apostrophes, hyphens and periods only. No digits or symbols. */
function name_error(string $label, string $v): ?string {
    $v = trim($v);
    if ($v === '') return "$label is required.";
    if (str_len($v) > 60) return "$label must be 60 characters or fewer.";
    if (!preg_match("/^\\p{L}[\\p{L}\\s'.\\-]*$/u", $v) || preg_match_all('/\\p{L}/u', $v) < 2)
        return "$label can only contain letters (spaces, hyphens, apostrophes and periods are allowed) and needs at least 2 letters.";
    return null;
}
/** Collapse repeated spaces so "  Ana   Marie " is stored as "Ana Marie". */
function clean_name(string $v): string { return trim(preg_replace('/\s+/u', ' ', $v)); }

// ---- Password history: a new password may not equal the current one or any of the last 5 ----
function password_reused(int $uid, string $pw): bool {
    $hashes = q('SELECT password_hash FROM password_history WHERE user_id = ? ORDER BY history_id DESC LIMIT 5', [$uid])->fetchAll(PDO::FETCH_COLUMN);
    $hashes[] = (string)q('SELECT password_hash FROM users WHERE user_id = ?', [$uid])->fetchColumn();
    foreach ($hashes as $h) if ($h !== '' && password_verify($pw, $h)) return true;
    return false;
}
const PASSWORD_REUSED_MSG = 'You cannot reuse your current or a recent password. Please choose a new one.';
/** The ONE place a password changes: remembers the old hash, keeps the last 5, stores the new hash. */
function set_password(int $uid, string $newPw, bool $mustChange = false): void {
    $old = (string)q('SELECT password_hash FROM users WHERE user_id = ?', [$uid])->fetchColumn();
    if ($old !== '') q('INSERT INTO password_history (user_id, password_hash) VALUES (?,?)', [$uid, $old]);
    q('DELETE FROM password_history WHERE user_id = ? AND history_id NOT IN (SELECT history_id FROM (SELECT history_id FROM password_history WHERE user_id = ? ORDER BY history_id DESC LIMIT 5) keep)', [$uid, $uid]);
    q('UPDATE users SET password_hash = ?, must_change_password = ? WHERE user_id = ?', [password_hash($newPw, PASSWORD_DEFAULT), $mustChange ? 1 : 0, $uid]);
}
/** A readable temporary password that always satisfies the password policy (no look-alike characters). */
function temp_password(): string {
    $abc = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ'; $num = '23456789';
    do {
        $p = '';
        for ($i = 0; $i < 8; $i++) $p .= $abc[random_int(0, strlen($abc) - 1)];
        $p .= $num[random_int(0, 7)] . $num[random_int(0, 7)];
        $p = str_shuffle($p);
    } while (password_error($p));
    return $p;
}

// ---- Auth ----
function login_user(array $row): void {
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$row['user_id'];
    $_SESSION['sv'] = (int)$row['session_version'];
    $_SESSION['last'] = time();
    $_SESSION['login_popup'] = 1;       // shows the welcome popup and chime once (includes/login_popup.php)
}
/** Invalidate every other session of this user (call after a password change). The current browser stays signed in. */
function bump_session(int $userId, bool $keepCurrent = false): void {
    q('UPDATE users SET session_version = session_version + 1 WHERE user_id = ?', [$userId]);
    if ($keepCurrent) $_SESSION['sv'] = (int)q('SELECT session_version FROM users WHERE user_id = ?', [$userId])->fetchColumn();
}
function user(): ?array {
    static $u = false;
    if ($u === false) {
        $u = null;
        if (!empty($_SESSION['uid'])) {
            $u = q('SELECT u.*, s.shelter_name, s.verification_status, s.account_status AS shelter_status, s.rejection_reason, s.invite_code, s.logo AS shelter_logo, s.city AS shelter_city, s.province AS shelter_province
                    FROM users u LEFT JOIN shelters s ON s.shelter_id = u.shelter_id WHERE u.user_id = ?', [$_SESSION['uid']])->fetch() ?: null;
            if ($u && ($u['account_status'] !== 'active' || (int)$u['session_version'] !== (int)($_SESSION['sv'] ?? 0))) {
                unset($_SESSION['uid'], $_SESSION['sv']); $u = null;
            }
        }
    }
    return $u;
}
function require_login(): array {
    $u = user();
    if (!$u) { flash('error', 'Please log in to continue.'); redirect('login.php'); }
    return $u;
}
function require_role(string ...$roles): array {
    $u = user();
    if (!$u) { flash('error', 'Please log in to continue.'); redirect('login.php'); }
    if ($roles && !in_array($u['role'], $roles, true)) { http_response_code(403); exit('403: you do not have access to this page.'); }
    if (($u['terms_version'] ?? null) !== TERMS_VERSION && !in_array(basename($_SERVER['SCRIPT_NAME']), ['consent.php', 'logout.php'], true)) {
        flash('info', 'Please review and accept the Terms and Privacy Notice to continue.'); redirect('consent.php');
    }
    if ($u['must_change_password'] && !in_array(basename($_SERVER['SCRIPT_NAME']), ['profile.php', 'logout.php'], true)) {
        flash('info', 'Please change your temporary password before continuing.'); redirect('profile.php');
    }
    return $u;
}
function email_verified(array $u): bool { return !empty($u['email_verified_at']); }
/** Unverified adopters and staff may browse, but not send inquiries or messages. */
function require_verified(array $u): void {
    if ($u['role'] !== 'admin' && !email_verified($u)) { flash('info', 'Please verify your email address first. It keeps inquiries and messages trustworthy.'); redirect('verify_email.php'); }
}
function shelter_ready(?array $u): bool {
    return $u && $u['role'] === 'staff' && $u['shelter_id'] && $u['verification_status'] === 'approved' && $u['shelter_status'] === 'active';
}
function home_for(array $u): string {
    return ['admin' => 'admin/dashboard.php', 'staff' => 'staff/dashboard.php', 'adopter' => 'pets.php'][$u['role']];
}

// ---- Pets & inquiries: ONE place that changes pet status and keeps inquiries consistent ----
function set_pet_status(int $petId, string $status): ?string {
    $pdo = db(); $pdo->beginTransaction();
    try {
        if (!q('SELECT status FROM pets WHERE pet_id = ? FOR UPDATE', [$petId])->fetch()) { $pdo->rollBack(); return 'Pet not found.'; }
        if ($status === 'available' && !q('SELECT 1 FROM pet_photos WHERE pet_id = ?', [$petId])->fetch()) {
            $pdo->rollBack(); return 'Add at least one photo before this pet goes live.';
        }
        if ($status === 'available' && q("SELECT 1 FROM adoption_inquiries WHERE pet_id = ? AND status = 'approved'", [$petId])->fetch()) {
            $pdo->rollBack(); return 'This pet has an approved inquiry. Revoke the approval or mark the pet as adopted instead.';
        }
        q('UPDATE pets SET status = ? WHERE pet_id = ?', [$status, $petId]);
        $close = ['adopted' => ["'pending'", 'This pet has been adopted by another applicant.'],
                  'removed' => ["'pending','approved'", 'This listing was removed.']][$status] ?? null;
        if ($close) {
            $ids = q('SELECT inquiry_id FROM adoption_inquiries WHERE pet_id = ? AND status IN (' . $close[0] . ')', [$petId])->fetchAll(PDO::FETCH_COLUMN);
            q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message=?, responded_at=NOW() WHERE pet_id=? AND status IN (" . $close[0] . ")", [$close[1], $petId]);
            foreach ($ids as $iid) inquiry_event((int)$iid, $status === 'adopted' ? 'closed_adopted' : 'closed_removed');
        }
        if ($status === 'adopted' && ($won = q("SELECT inquiry_id FROM adoption_inquiries WHERE pet_id = ? AND status = 'approved'", [$petId])->fetchColumn())) { inquiry_event((int)$won, 'adopted'); followups_schedule((int)$won); }
        $pdo->commit(); return null;
    } catch (Throwable $t) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $t; }
}

// ---- Admin audit trail ----
function audit(string $action, string $type, ?int $id, string $details = ''): void {
    $u = user();
    q('INSERT INTO admin_audit_log (admin_id, action, target_type, target_id, details, ip) VALUES (?,?,?,?,?,?)',
      [$u['user_id'] ?? null, $action, $type, $id, substr($details, 0, 255), client_ip()]);
}

/** Same as audit() but for an event with no signed-in session (for example a password reset by emailed code). */
function audit_for(int $adminId, string $action, string $type, ?int $id, string $details = ''): void {
    q('INSERT INTO admin_audit_log (admin_id, action, target_type, target_id, details, ip) VALUES (?,?,?,?,?,?)',
      [$adminId, $action, $type, $id, substr($details, 0, 255), client_ip()]);
}

// ---- Pagination ----
function paginate(int $total, int $per): array {
    $pages = max(1, (int)ceil($total / $per));
    $pg = min(max(1, (int)($_GET['p'] ?? 1)), $pages);
    return [$pg, $pages, ($pg - 1) * $per];
}
function pager(int $pg, int $pages): string {
    if ($pages < 2) return '';
    $qs = $_GET; unset($qs['p']);
    $out = '<nav class="pager" aria-label="Pages">';
    foreach (range(1, $pages) as $i) {
        if ($i !== 1 && $i !== $pages && abs($i - $pg) > 2) { if (abs($i - $pg) === 3) $out .= '<span class="gap">&hellip;</span>'; continue; }
        $out .= '<a class="' . ($i === $pg ? 'on' : '') . '" href="?' . e(http_build_query($qs + ['p' => $i])) . '">' . $i . '</a>';
    }
    return $out . '</nav>';
}

// ---- Profile helpers ----
function profile_options(): array {
    return [
        'housing' => ['house_owned' => 'House (owned)', 'house_rented' => 'House (rented)', 'apartment' => 'Apartment', 'condo' => 'Condominium', 'other' => 'Other'],
        'experience' => ['first_time' => 'First-time owner', 'some' => 'Some experience with pets', 'experienced' => 'Experienced pet owner'],
    ];
}
function str_len(string $s): int { return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s); }
function avatar(array $u, string $class = ''): string {
    if (!empty($u['profile_photo'])) return '<img class="avatar ' . e($class) . '" src="' . e(url($u['profile_photo'])) . '" alt="">';
    $a = trim((string)($u['first_name'] ?? '')); $b = trim((string)($u['last_name'] ?? ''));
    $ini = function_exists('mb_substr') ? mb_strtoupper(mb_substr($a, 0, 1) . mb_substr($b, 0, 1)) : strtoupper(substr($a, 0, 1) . substr($b, 0, 1));
    return '<span class="avatar ' . e($class) . '" aria-hidden="true">' . e($ini ?: '?') . '</span>';
}
function delete_public_file(?string $rel): void {
    if (!$rel || strpos($rel, 'uploads/') !== 0) return;
    $base = realpath(__DIR__ . '/../uploads'); $f = realpath(__DIR__ . '/../' . $rel);
    if ($base && $f && strpos($f, $base) === 0 && is_file($f)) @unlink($f);
}

// ---- Display helpers ----
function age_label(int $months): string {
    if ($months < 12) return $months . ' mo';
    $y = intdiv($months, 12); $m = $months % 12;
    return $y . ' yr' . ($y > 1 ? 's' : '') . ($m ? " $m mo" : '');
}
function pet_tags(array $p): string {
    $map = ['vaccinated' => ['Vaccinated', 'Not vaccinated'], 'neutered' => ['Spayed / neutered', 'Not spayed / neutered'], 'good_with_kids' => ['Good with kids', 'Not suited to young kids'],
            'good_with_pets' => ['Good with other pets', 'Prefers to be the only pet']];
    $h = '';
    if (!empty($p['size'])) $h .= '<span class="tag">' . e(ucfirst($p['size'])) . ' size</span>';
    if (!empty($p['energy_level'])) $h .= '<span class="tag">' . e(ucfirst($p['energy_level'])) . ' energy</span>';
    foreach ($map as $k => $l) { $v = $p[$k] ?? 'unknown'; if ($v === 'yes') $h .= '<span class="tag yes">' . e($l[0]) . '</span>'; elseif ($v === 'no') $h .= '<span class="tag">' . e($l[1]) . '</span>'; }
    if (($p['needs_yard'] ?? '') === 'yes') $h .= '<span class="tag">Needs a yard</span>';
    elseif (($p['needs_yard'] ?? '') === 'no') $h .= '<span class="tag yes">No yard needed</span>';
    if (!empty($p['experience_needed'])) $h .= '<span class="tag">' . e(['first_time' => 'Great for first-time owners', 'some' => 'Some experience helps', 'experienced' => 'Experienced owner needed'][$p['experience_needed']] ?? '') . '</span>';
    return $h ? '<div class="tags">' . $h . '</div>' : '';
}
function badge(string $status): string { return '<span class="badge b-' . e($status) . '">' . e(ucfirst($status)) . '</span>'; }
function shelter_logo(array $s, string $class = ''): string {
    if (!empty($s['logo'])) return '<img class="avatar ' . e($class) . '" src="' . e(url($s['logo'])) . '" alt="">';
    return '<span class="avatar ' . e($class) . '" aria-hidden="true">&#127968;</span>';
}
function fdate(?string $d): string { return $d ? date('M j, Y', strtotime($d)) : '-'; }

// ---- Uploads ----
/** Re-encode an image: strips EXIF/GPS and hidden payloads, fixes rotation, caps size at 1600px. */
function reencode_image(string $tmp, string $mime, string $dest, int $square = 0): bool {
    if (!function_exists('imagecreatefromstring')) return move_uploaded_file($tmp, $dest); // GD not installed: store as-is
    $info = @getimagesize($tmp);
    if (!$info || $info[0] > 8000 || $info[1] > 8000) return false;
    $img = @imagecreatefromstring((string)file_get_contents($tmp));
    if (!$img) return false;
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $deg = [3 => 180, 6 => -90, 8 => 90][(@exif_read_data($tmp)['Orientation'] ?? 1)] ?? 0;
        if ($deg && ($r = imagerotate($img, $deg, 0))) { imagedestroy($img); $img = $r; }
    }
    $w = imagesx($img); $h = imagesy($img);
    $cap = 1600;
    if ($square > 0) {   // profile photo: centre-crop to a square, then scale down to $square px
        $side = min($w, $h);
        if ($c = imagecrop($img, ['x' => intdiv($w - $side, 2), 'y' => intdiv($h - $side, 2), 'width' => $side, 'height' => $side])) { imagedestroy($img); $img = $c; }
        $w = $h = $side; $cap = $square;
    }
    if (max($w, $h) > $cap) {
        $s = $cap / max($w, $h);
        if ($n = imagescale($img, (int)round($w * $s), (int)round($h * $s))) { imagedestroy($img); $img = $n; }
    }
    if ($mime === 'image/png') { imagesavealpha($img, true); $ok = imagepng($img, $dest, 6); }
    elseif ($mime === 'image/webp') { $ok = function_exists('imagewebp') && imagewebp($img, $dest, 85); }
    else { $ok = imagejpeg($img, $dest, 85); }
    imagedestroy($img);
    return (bool)$ok;
}
/**
 * Validate and store an upload. $dir 'pets' = public images (uploads/pets); 'docs' = private verification documents,
 * stored OUTSIDE the web root (PRIVATE_DIR) and only served to admins. Returns the path to store in the DB, or null (with a flash).
 */
function save_upload(array $file, string $dir, bool $allowPdf = false, int $square = 0): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > MAX_UPLOAD_BYTES) { flash('error', 'Upload failed. Files must be under 5 MB.'); return null; }
    $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if ($allowPdf) $types['application/pdf'] = 'pdf';
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($types[$mime])) { flash('error', 'Unsupported file type. Use JPG, PNG or WEBP' . ($allowPdf ? ' or PDF.' : '.')); return null; }
    if ($mime === 'application/pdf' && file_get_contents($file['tmp_name'], false, null, 0, 5) !== '%PDF-') { flash('error', 'That PDF looks damaged.'); return null; }
    $name = bin2hex(random_bytes(12)) . '.' . $types[$mime];
    $private = $dir === 'docs';
    $folder = $private ? rtrim(PRIVATE_DIR, '/\\') . '/docs' : __DIR__ . '/../uploads/' . $dir;
    if (!is_dir($folder) && !@mkdir($folder, 0755, true)) { flash('error', 'Could not create the upload folder. Check folder permissions.'); return null; }
    $target = $folder . '/' . $name;
    $ok = $mime === 'application/pdf' ? move_uploaded_file($file['tmp_name'], $target) : reencode_image($file['tmp_name'], $mime, $target, $square);
    if (!$ok) { flash('error', 'Could not process that file. Try a different image.'); return null; }
    return ($private ? 'private/docs/' : 'uploads/' . $dir . '/') . $name;
}

require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/notify.php';
require_once __DIR__ . '/chat.php';
require_once __DIR__ . '/otp.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/captcha.php';
require_once __DIR__ . '/inbox.php';
require_once __DIR__ . '/timeline.php';
require_once __DIR__ . '/charts.php';
require_once __DIR__ . '/match.php';
require_once __DIR__ . '/followups.php';
require_once __DIR__ . '/stats.php';
require_once __DIR__ . '/listing.php';
require_once __DIR__ . '/geo.php';
require_once __DIR__ . '/petitions.php';
