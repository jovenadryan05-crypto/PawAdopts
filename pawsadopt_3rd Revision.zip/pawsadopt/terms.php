<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Terms and Conditions'; $page = '';
include __DIR__ . '/includes/header.php';
?>
<article class="legal">
  <h1>Terms and Conditions</h1>
  <p class="muted">Version <?= e(TERMS_VERSION) ?>. Please read these together with our <a href="<?= url('privacy.php') ?>">Privacy Notice</a>.</p>

  <h2>1. Acceptance</h2>
  <p>By creating an account or using PawsAdopt you agree to these Terms and to the Privacy Notice. If you do not agree, please do not use the platform.</p>

  <h2>2. What PawsAdopt is</h2>
  <p>PawsAdopt is an online platform that connects adopters with verified animal shelters. We provide listings, inquiries and announcements. We are not a shelter, we do not own or hold any animal, and we are not a party to any adoption. Every adoption decision, screening step and agreement is between the adopter and the shelter.</p>

  <h2>3. Eligibility and accounts</h2>
  <ul>
    <li>You must be at least 18 years old to create an account.</li>
    <li>Give accurate information and keep it up to date, including a working Philippine mobile number and email address.</li>
    <li>Keep your password private. You are responsible for activity under your account. Tell us if you think it was compromised.</li>
    <li>One person, one account. Do not impersonate anyone.</li>
  </ul>

  <h2>4. Adopters</h2>
  <ul>
    <li>Inquiries must be honest and sent in good faith. Do not send inquiries you do not intend to follow up.</li>
    <li>Sending an inquiry shares your name, email, mobile number and the profile details you filled in with that shelter (see the Privacy Notice).</li>
    <li>An approved inquiry is not a guarantee of adoption. Shelters may ask for interviews, home checks, fees and agreements of their own.</li>
  </ul>

  <h2>5. Shelters and shelter staff</h2>
  <ul>
    <li>Shelters must be verified by an administrator before they can list animals. You confirm that the documents you submit are genuine and that you are authorised to act for the shelter.</li>
    <li>Listings must be accurate and about animals genuinely available for adoption. Listings that sell animals for profit are not allowed.</li>
    <li>You may use adopters' personal data only to handle their inquiry and the adoption. You must not sell it, share it for marketing, or keep it longer than needed.</li>
    <li>Share the shelter invite code only with colleagues who are authorised to act for the shelter.</li>
  </ul>

  <h2>6. Donations</h2>
  <p>Donation requests are posted by shelters. PawsAdopt does not collect, hold or process money, and does not verify how donations are used. Confirm a request with the shelter before you send any money.</p>

  <h2>7. Acceptable use</h2>
  <p>You must not: post false, misleading, abusive or unlawful content; harass other users; upload files you have no right to share; scrape the site or try to bypass its security; attempt to access other people's accounts or data; or use the platform to send spam.</p>

  <h2>8. Content and moderation</h2>
  <p>You keep ownership of what you post (such as photos and descriptions) and give PawsAdopt a limited licence to display it on the platform for as long as it is posted. Administrators may hide or remove listings and posts, reject shelter registrations, and suspend accounts that break these Terms. Administrator actions are recorded in an audit log.</p>

  <h2>9. Availability and liability</h2>
  <p>We work to keep the platform available and accurate, but it is provided "as is". We cannot guarantee that listings are current, that a shelter will respond, or that an adoption will succeed. To the extent the law allows, PawsAdopt is not liable for losses arising from adoptions, donations, or dealings between users.</p>

  <h2>10. Ending your account</h2>
  <p>You can delete your account at any time from Profile &rarr; Your data and privacy. We may suspend or end accounts that break these Terms.</p>

  <h2>11. Changes to these Terms</h2>
  <p>When we change these Terms or the Privacy Notice, the version number above changes and you will be asked to review and accept them again before you continue.</p>

  <h2>12. Governing law and contact</h2>
  <p>These Terms are governed by the laws of the Republic of the Philippines. Questions: <a href="mailto:<?= e(SITE_CONTACT_EMAIL) ?>"><?= e(SITE_CONTACT_EMAIL) ?></a>.</p>
</article>
<?php include __DIR__ . '/includes/footer.php'; ?>
