-- PawsAdopt schema (6 tables, one per DFD data store D1-D6)
DROP DATABASE IF EXISTS pawsadopt;
CREATE DATABASE pawsadopt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pawsadopt;

-- D1 USERS (shelter_id FK is added after SHELTERS exists: users <-> shelters is circular)
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id     INT NULL COMMENT 'NULL, staff only',
  first_name     VARCHAR(60)  NOT NULL,
  last_name      VARCHAR(60)  NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  contact_number VARCHAR(30)  NOT NULL,
  role           ENUM('adopter','staff','admin') NOT NULL,
  account_status ENUM('active','suspended','deleted') NOT NULL DEFAULT 'active',
  profile_photo  VARCHAR(255) NULL,
  bio            VARCHAR(500) NULL,
  city           VARCHAR(80)  NULL,
  `position`     VARCHAR(80)  NULL COMMENT 'staff job title',
  housing_type   ENUM('house_owned','house_rented','apartment','condo','other') NULL,
  other_pets     VARCHAR(150) NULL,
  pet_experience ENUM('first_time','some','experienced') NULL,
  consent_at     DATETIME NULL COMMENT 'when the user accepted Terms + Privacy Notice',
  terms_version  VARCHAR(20) NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  session_version INT NOT NULL DEFAULT 1 COMMENT 'bumped on password change to log out other sessions',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- D2 SHELTERS
CREATE TABLE shelters (
  shelter_id             INT AUTO_INCREMENT PRIMARY KEY,
  shelter_name           VARCHAR(120) NOT NULL,
  address                VARCHAR(255) NOT NULL,
  contact_email          VARCHAR(150) NOT NULL,
  contact_number         VARCHAR(30)  NOT NULL,
  verification_documents VARCHAR(255) NOT NULL,
  verification_status    ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  account_status         ENUM('active','suspended') NOT NULL DEFAULT 'active',
  reviewed_by            INT NULL COMMENT 'NULL until reviewed',
  reviewed_at            DATETIME NULL,
  rejection_reason       VARCHAR(255) NULL,
  invite_code            CHAR(8) NULL UNIQUE COMMENT 'lets extra staff join this shelter',
  created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_shelter_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE users ADD CONSTRAINT fk_user_shelter
  FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE SET NULL;

-- D3 PETS
CREATE TABLE pets (
  pet_id      INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id  INT NOT NULL,
  listed_by   INT NOT NULL,
  pet_name    VARCHAR(80) NOT NULL,
  species     VARCHAR(40) NOT NULL,
  breed       VARCHAR(80) NULL,
  sex         ENUM('male','female','unknown') NOT NULL DEFAULT 'unknown',
  age_months  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  description TEXT NULL,
  status      ENUM('available','pending','adopted','removed') NOT NULL DEFAULT 'available',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pet_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_pet_user    FOREIGN KEY (listed_by)  REFERENCES users(user_id)       ON DELETE RESTRICT,
  INDEX idx_pet_search (status, species)
) ENGINE=InnoDB;

-- D4 PET_PHOTOS
CREATE TABLE pet_photos (
  photo_id    INT AUTO_INCREMENT PRIMARY KEY,
  pet_id      INT NOT NULL,
  photo_url   VARCHAR(255) NOT NULL,
  is_primary  TINYINT(1) NOT NULL DEFAULT 0,
  uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_photo_pet FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- D5 ADOPTION_INQUIRIES (the response fields live here, per the ERD)
CREATE TABLE adoption_inquiries (
  inquiry_id       INT AUTO_INCREMENT PRIMARY KEY,
  pet_id           INT NOT NULL,
  adopter_id       INT NOT NULL,
  message          TEXT NOT NULL,
  status           ENUM('pending','approved','rejected','withdrawn') NOT NULL DEFAULT 'pending',
  submitted_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  responded_by     INT NULL COMMENT 'NULL until responded',
  decision         ENUM('approved','rejected') NULL,
  response_message TEXT NULL,
  responded_at     DATETIME NULL,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  -- DB-level guards: one active inquiry per adopter+pet, and only one approved inquiry per pet
  active_key       VARCHAR(30) AS (IF(status IN ('pending','approved'), CONCAT(pet_id,'-',adopter_id), NULL)) VIRTUAL,
  approved_key     INT AS (IF(status = 'approved', pet_id, NULL)) VIRTUAL,
  UNIQUE KEY uq_active_inquiry (active_key),
  UNIQUE KEY uq_one_approved (approved_key),
  CONSTRAINT fk_inq_pet     FOREIGN KEY (pet_id)       REFERENCES pets(pet_id)   ON DELETE CASCADE,
  CONSTRAINT fk_inq_adopter FOREIGN KEY (adopter_id)   REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_inq_staff   FOREIGN KEY (responded_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- D6 ANNOUNCEMENTS_DONATIONS
CREATE TABLE announcements_donations (
  post_id       INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id    INT NOT NULL,
  posted_by     INT NOT NULL,
  post_type     ENUM('announcement','donation') NOT NULL,
  title         VARCHAR(150) NOT NULL,
  content       TEXT NOT NULL,
  target_amount DECIMAL(12,2) NULL,
  status        ENUM('published','closed','hidden') NOT NULL DEFAULT 'published',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_post_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_post_user    FOREIGN KEY (posted_by)  REFERENCES users(user_id)       ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Support tables (not part of the 6 DFD data stores: security and audit infrastructure)
CREATE TABLE rate_limits (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  bucket     VARCHAR(190) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bucket_time (bucket, created_at)
) ENGINE=InnoDB;

CREATE TABLE password_resets (
  reset_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  code_hash  VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts   TINYINT NOT NULL DEFAULT 0,
  used_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE admin_audit_log (
  log_id      INT AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT NULL,
  action      VARCHAR(60) NOT NULL,
  target_type VARCHAR(40) NOT NULL,
  target_id   INT NULL,
  details     VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_audit_time (created_at)
) ENGINE=InnoDB;

-- Default administrator (change this password after first login)
-- email: admin@pawsadopt.local   password: Admin@12345
INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role,must_change_password)
VALUES ('System','Admin','admin@pawsadopt.local','$2y$10$HEZtbE8PQ5Tn/6bXMEcAY.1DvrTzw9MsodnMSiA7bSiWxMyhrHgQ.','09000000000','admin',1);
