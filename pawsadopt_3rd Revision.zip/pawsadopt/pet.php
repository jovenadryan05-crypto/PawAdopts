<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$id = (int)($_GET['id'] ?? 0);
$pet = q('SELECT p.*, s.shelter_name, s.address, s.contact_email, s.contact_number AS shelter_phone, s.verification_status, s.account_status AS shelter_status
          FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE p.pet_id = ?', [$id])->fetch();
$u = user();
$isOwner = $u && $u['role'] === 'staff' && $u['shelter_id'] == ($pet['shelter_id'] ?? 0);
$isAdmin = $u && $u['role'] === 'admin';
$public = $pet && $pet['status'] !== 'removed' && $pet['verification_status'] === 'approved' && $pet['shelter_status'] === 'active';
if (!$pet || (!$public && !$isOwner && !$isAdmin)) { http_response_code(404); $title = 'Not found'; include __DIR__ . '/includes/header.php'; echo '<div class="empty"><h2>Pet not found</h2><p>This listing may have been removed. <a href="' . url('index.php') . '">Browse available pets</a>.</p></div>'; include __DIR__ . '/includes/footer.php'; exit; }

// UC-10 Submit adoption inquiry (requires login: UC-02 include)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = require_role('adopter');
    $msg = trim($_POST['message'] ?? '');
    if ($pet['status'] !== 'available') flash('error', 'This pet is no longer available for new inquiries.');
    elseif (strlen($msg) < 20) flash('error', 'Tell the shelter a bit more about yourself (at least 20 characters).');
    elseif (str_len($msg) > 2000) flash('error', 'Please keep your message under 2000 characters.');
    elseif (rate_blocked('inquiry:user:' . $u['user_id'], 10, 3600)) flash('error', 'You have sent several inquiries in the last hour. Please wait a while before sending more.');
    elseif (q("SELECT 1 FROM adoption_inquiries WHERE pet_id = ? AND adopter_id = ? AND status IN ('pending','approved')", [$id, $u['user_id']])->fetch())
        flash('error', 'You already have an active inquiry for this pet.');
    else {
        try {   // the unique key uq_active_inquiry also blocks a double-click / parallel duplicate
            q('INSERT INTO adoption_inquiries (pet_id, adopter_id, message) VALUES (?,?,?)', [$id, $u['user_id'], $msg]);
            rate_hit('inquiry:user:' . $u['user_id']);
            notify_new_inquiry($pet, $u, $msg);          // emailed to the shelter's contact email after the page is sent
            flash('success', 'Inquiry sent. You can follow its status under My inquiries.');
            redirect('adopter/inquiries.php');
        } catch (PDOException $ex) {
            if ($ex->getCode() !== '23000') throw $ex;
            flash('error', 'You already have an active inquiry for this pet.');
        }
    }
    redirect('pet.php?id=' . $id);
}

$photos = q('SELECT * FROM pet_photos WHERE pet_id = ? ORDER BY is_primary DESC, photo_id', [$id])->fetchAll();
$existing = $u && $u['role'] === 'adopter'
    ? q("SELECT status FROM adoption_inquiries WHERE pet_id = ? AND adopter_id = ? ORDER BY inquiry_id DESC LIMIT 1", [$id, $u['user_id']])->fetchColumn() : null;
$title = $pet['pet_name']; $page = 'browse';
include __DIR__ . '/includes/header.php';
?>
<p><a href="<?= url('index.php') ?>">&larr; Back to all pets</a></p>
<?php if ($pet['status'] === 'removed'): ?><div class="flash flash-error">This listing is removed and only visible to staff and admins.</div><?php endif; ?>
<div class="detail">
  <div class="gallery">
    <div class="main-img">
      <?php if ($photos): ?><img id="mainPhoto" src="<?= url($photos[0]['photo_url']) ?>" alt="<?= e($pet['pet_name']) ?>"><?php else: ?><span class="ph big">&#128062;</span><?php endif; ?>
    </div>
    <?php if (count($photos) > 1): ?>
    <div class="thumbs">
      <?php foreach ($photos as $ph): ?><button type="button" class="t" data-src="<?= url($ph['photo_url']) ?>"><img src="<?= url($ph['photo_url']) ?>" alt=""></button><?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
  <div class="info">
    <h1><?= e($pet['pet_name']) ?> <?= badge($pet['status']) ?></h1>
    <dl class="facts">
      <div><dt>Species</dt><dd><?= e($pet['species']) ?></dd></div>
      <div><dt>Breed</dt><dd><?= e($pet['breed'] ?: 'Not specified') ?></dd></div>
      <div><dt>Sex</dt><dd><?= e(ucfirst($pet['sex'])) ?></dd></div>
      <div><dt>Age</dt><dd><?= age_label((int)$pet['age_months']) ?></dd></div>
    </dl>
    <h2>About <?= e($pet['pet_name']) ?></h2>
    <p class="prose"><?= nl2br(e($pet['description'] ?: 'No description yet.')) ?></p>
    <h2>Shelter</h2>
    <p><strong><?= e($pet['shelter_name']) ?></strong><br><?= e($pet['address']) ?><br><?= e($pet['contact_email']) ?> &middot; <?= e($pet['shelter_phone']) ?></p>

    <div class="panel">
    <?php if ($pet['status'] !== 'available'): ?>
      <p class="muted">This pet is not accepting new inquiries right now.</p>
    <?php elseif (!$u): ?>
      <h3>Interested in <?= e($pet['pet_name']) ?>?</h3>
      <p><a class="btn" href="<?= url('login.php') ?>">Log in</a> or <a href="<?= url('register.php') ?>">create an adopter account</a> to send an inquiry.</p>
    <?php elseif ($u['role'] !== 'adopter'): ?>
      <p class="muted">Only adopter accounts can send inquiries.</p>
    <?php elseif (in_array($existing, ['pending', 'approved'], true)): ?>
      <p>You already have an inquiry for this pet (<?= badge($existing) ?>). <a href="<?= url('adopter/inquiries.php') ?>">View my inquiries</a></p>
    <?php else: ?>
      <h3>Send an adoption inquiry</h3>
      <form method="post"><?= csrf_field() ?>
        <label>Why would <?= e($pet['pet_name']) ?> be a good fit for your home?
          <textarea name="message" rows="5" minlength="20" required placeholder="Tell the shelter about your home, other pets, and experience."><?= e($_POST['message'] ?? profile_intro($u)) ?></textarea></label>
        <p class="hint">When you send this, the shelter receives your name, email, mobile number and the home details from your profile, and the inquiry is also emailed to the shelter. See the <a href="<?= url('privacy.php') ?>">Privacy Notice</a>.</p>
        <button class="btn">Send inquiry</button>
      </form>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
