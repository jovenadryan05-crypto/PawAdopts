<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Create account'; $errors = [];
// UC-01 Register account (adopters and shelter staff; admin accounts are created by the system)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    $role = $f('role'); $email = strtolower($f('email')); $phone = ph_mobile($f('contact_number'));
    if (rate_blocked('register:ip:' . client_ip(), 5, 3600)) $errors[] = 'Too many sign-ups from this connection. Please try again later.';
    if (!in_array($role, ['adopter', 'staff'], true)) $errors[] = 'Choose an account type.';
    if ($f('first_name') === '' || $f('last_name') === '') $errors[] = 'First and last name are required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!$phone) $errors[] = 'Contact number must be a Philippine mobile number: 11 digits starting with 09 (e.g. 09171234567).';
    if ($err = password_error($_POST['password'] ?? '')) $errors[] = $err;
    elseif (($_POST['password'] ?? '') !== ($_POST['confirm'] ?? '')) $errors[] = 'Passwords do not match.';
    if (empty($_POST['adult'])) $errors[] = 'You must confirm that you are 18 years old or above.';
    if (empty($_POST['agree'])) $errors[] = 'You must accept the Terms and Conditions and the Privacy Notice.';
    if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) $errors[] = 'That email is already registered.';
    if (!$errors) {
        q('INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role,consent_at,terms_version) VALUES (?,?,?,?,?,?,NOW(),?)',
          [$f('first_name'), $f('last_name'), $email, password_hash($_POST['password'], PASSWORD_DEFAULT), $phone, $role, TERMS_VERSION]);
        rate_hit('register:ip:' . client_ip());
        flash('success', 'Account created. Log in to continue.');
        redirect('login.php');
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth">
  <h1>Create your account</h1>
  <?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?>
    <fieldset class="choice"><legend>I am joining as</legend>
      <label><input type="radio" name="role" value="adopter" <?= ($_POST['role'] ?? 'adopter') === 'adopter' ? 'checked' : '' ?>> An adopter</label>
      <label><input type="radio" name="role" value="staff" <?= ($_POST['role'] ?? '') === 'staff' ? 'checked' : '' ?>> Shelter staff</label>
    </fieldset>
    <div class="two"><label>First name<input name="first_name" value="<?= old('first_name') ?>" required></label>
    <label>Last name<input name="last_name" value="<?= old('last_name') ?>" required></label></div>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required></label>
    <label>Mobile number<input type="tel" name="contact_number" value="<?= old('contact_number') ?>" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="09XXXXXXXXX" title="11 digits, starting with 09" data-ph required>
      <span class="hint">Philippine mobile number: 11 digits, starting with 09.</span></label>
    <div class="two"><label>Password<input type="password" name="password" minlength="8" maxlength="72" required><span class="hint">8+ characters with a letter and a number.</span></label>
    <label>Confirm password<input type="password" name="confirm" minlength="8" maxlength="72" required></label></div>
    <label class="check"><input type="checkbox" name="adult" value="1" <?= !empty($_POST['adult']) ? 'checked' : '' ?> required> I am 18 years old or above.</label>
    <label class="check"><input type="checkbox" name="agree" value="1" <?= !empty($_POST['agree']) ? 'checked' : '' ?> required> <span>I have read and agree to the <a href="<?= url('terms.php') ?>" target="_blank" rel="noopener">Terms and Conditions</a> and the <a href="<?= url('privacy.php') ?>" target="_blank" rel="noopener">Privacy Notice</a>.</span></label>
    <button class="btn">Create account</button>
  </form>
  <p class="muted">Already registered? <a href="<?= url('login.php') ?>">Log in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
