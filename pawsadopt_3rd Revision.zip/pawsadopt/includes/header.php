<?php $u = user(); $page = $page ?? ''; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'PawsAdopt') ?> | PawsAdopt</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?= url('index.php') ?>"><span class="paw" aria-hidden="true">&#128062;</span>PawsAdopt</a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="nav">Menu</button>
    <nav id="nav" class="nav">
      <a href="<?= url('index.php') ?>" class="<?= $page==='browse'?'on':'' ?>">Find a pet</a>
      <a href="<?= url('announcements.php') ?>" class="<?= $page==='news'?'on':'' ?>">Announcements</a>
      <?php if ($u && $u['role']==='adopter'): ?>
        <a href="<?= url('adopter/inquiries.php') ?>" class="<?= $page==='inq'?'on':'' ?>">My inquiries</a>
      <?php elseif ($u && $u['role']==='staff'): ?>
        <a href="<?= url('staff/dashboard.php') ?>" class="<?= $page==='dash'?'on':'' ?>">Dashboard</a>
        <a href="<?= url('staff/pets.php') ?>" class="<?= $page==='pets'?'on':'' ?>">Pet listings</a>
        <a href="<?= url('staff/inquiries.php') ?>" class="<?= $page==='inq'?'on':'' ?>">Inquiries</a>
        <a href="<?= url('staff/posts.php') ?>" class="<?= $page==='posts'?'on':'' ?>">Posts</a>
      <?php elseif ($u && $u['role']==='admin'): ?>
        <a href="<?= url('admin/dashboard.php') ?>" class="<?= $page==='dash'?'on':'' ?>">Dashboard</a>
        <a href="<?= url('admin/shelters.php') ?>" class="<?= $page==='shelters'?'on':'' ?>">Shelters</a>
        <a href="<?= url('admin/users.php') ?>" class="<?= $page==='users'?'on':'' ?>">Users</a>
        <a href="<?= url('admin/moderation.php') ?>" class="<?= $page==='mod'?'on':'' ?>">Moderation</a>
        <a href="<?= url('admin/audit.php') ?>" class="<?= $page==='audit'?'on':'' ?>">Audit log</a>
      <?php endif; ?>
      <span class="nav-sep"></span>
      <?php if ($u): ?>
        <a href="<?= url('profile.php') ?>" class="<?= $page==='profile'?'on':'' ?> me"><?= avatar($u, 'sm') ?><?= e($u['first_name']) ?></a>
        <form method="post" action="<?= url('logout.php') ?>" class="inline"><?= csrf_field() ?><button class="linklike">Log out</button></form>
      <?php else: ?>
        <a href="<?= url('login.php') ?>">Log in</a>
        <a href="<?= url('register.php') ?>" class="btn btn-sm">Sign up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="wrap main">
<?php foreach (flash() as [$t, $m]): ?>
  <div class="flash flash-<?= e($t) ?>" role="status"><?= e($m) ?></div>
<?php endforeach; ?>
