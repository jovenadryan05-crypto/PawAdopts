<?php
// Email notifications. All sending is deferred (send_mail_later), so a mail problem never loses data or slows a page.
// Every value that came from a user is escaped with e() because these are HTML emails.

function mail_layout(string $heading, string $body): string {
    return '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:auto;color:#14213d;line-height:1.5">'
         . '<h2 style="margin:0 0 14px">' . e($heading) . '</h2>' . $body
         . '<hr style="border:0;border-top:1px solid #dde3ee;margin:22px 0"><p style="font-size:12px;color:#6b7690">Sent by PawsAdopt because of activity on your account or shelter.</p></div>';
}
function mail_button(string $label, string $path): string {
    return '<p><a href="' . e(SITE_URL . '/' . ltrim($path, '/')) . '" style="display:inline-block;background:#14213d;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">' . e($label) . '</a></p>';
}
function mail_quote(string $text): string {
    return '<blockquote style="margin:12px 0;padding:8px 14px;border-left:4px solid #ffb703;background:#fffaf0">' . nl2br(e($text)) . '</blockquote>';
}

/** UC-10 follow-up: tell the shelter about a new inquiry (sent to the shelter's contact email). */
function notify_new_inquiry(array $pet, array $adopter, string $message): void {
    $opt = profile_options();
    $rows = ['Name' => $adopter['first_name'] . ' ' . $adopter['last_name'], 'Mobile' => $adopter['contact_number'], 'Email' => $adopter['email']];
    if (!empty($adopter['city'])) $rows['City'] = $adopter['city'];
    if (!empty($adopter['housing_type'])) $rows['Home'] = $opt['housing'][$adopter['housing_type']] ?? '';
    if (!empty($adopter['other_pets'])) $rows['Other pets'] = $adopter['other_pets'];
    if (!empty($adopter['pet_experience'])) $rows['Experience'] = $opt['experience'][$adopter['pet_experience']] ?? '';
    $t = '<table style="border-collapse:collapse;margin:8px 0">';
    foreach ($rows as $k => $v) $t .= '<tr><td style="padding:3px 14px 3px 0;color:#6b7690">' . e($k) . '</td><td style="padding:3px 0"><b>' . e($v) . '</b></td></tr>';
    $t .= '</table>';
    send_mail_later($pet['contact_email'], 'New adoption inquiry for ' . $pet['pet_name'],
        mail_layout('New inquiry for ' . $pet['pet_name'], '<p>An adopter is interested in <b>' . e($pet['pet_name']) . '</b>.</p>' . $t . '<p>Their message:</p>' . mail_quote($message)
            . '<p>Review and respond from your dashboard.</p>' . mail_button('Open inquiries', 'staff/inquiries.php')));
}

/** Tell an adopter what the shelter decided. $kind: approved | rejected | revoked | adopted_other */
function notify_adopter_update(array $adopter, string $petName, string $shelterName, string $kind, ?string $note = null): void {
    $lines = [
        'approved'      => ['Good news about ' . $petName, '<b>' . e($shelterName) . '</b> approved your inquiry for <b>' . e($petName) . '</b>. They will reach you on the contact details in your profile.'],
        'rejected'      => ['Update on your inquiry for ' . $petName, '<b>' . e($shelterName) . '</b> is not able to move forward with your inquiry for <b>' . e($petName) . '</b>. Please keep looking; there are many animals waiting.'],
        'revoked'       => ['Update on your inquiry for ' . $petName, '<b>' . e($shelterName) . '</b> withdrew its earlier approval for <b>' . e($petName) . '</b>.'],
        'adopted_other' => [$petName . ' has been adopted', '<b>' . e($petName) . '</b> was adopted by another applicant, so your inquiry was closed.'],
    ][$kind];
    $body = '<p>Hi ' . e($adopter['first_name']) . ',</p><p>' . $lines[1] . '</p>' . ($note ? '<p>Message from the shelter:</p>' . mail_quote($note) : '') . mail_button('View my inquiries', 'adopter/inquiries.php');
    send_mail_later($adopter['email'], $lines[0], mail_layout($lines[0], $body));
}

/** Starter text for the inquiry box, built from the adopter's own profile (they can edit or delete it). */
function profile_intro(array $u): string {
    $opt = profile_options(); $parts = [];
    if (!empty($u['housing_type'])) $parts[] = 'I live in a ' . strtolower($opt['housing'][$u['housing_type']] ?? 'home') . (!empty($u['city']) ? ' in ' . $u['city'] : '') . '.';
    elseif (!empty($u['city'])) $parts[] = 'I live in ' . $u['city'] . '.';
    if (!empty($u['other_pets'])) $parts[] = 'Other pets at home: ' . $u['other_pets'] . '.';
    if (!empty($u['pet_experience'])) $parts[] = 'Pet experience: ' . strtolower($opt['experience'][$u['pet_experience']] ?? '') . '.';
    return $parts ? implode(' ', $parts) . "\n\n" : '';
}
