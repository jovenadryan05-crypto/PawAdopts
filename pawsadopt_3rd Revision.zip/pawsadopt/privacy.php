<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Privacy Notice'; $page = '';
include __DIR__ . '/includes/header.php';
?>
<article class="legal">
  <h1>Privacy Notice</h1>
  <p class="muted">Version <?= e(TERMS_VERSION) ?>. This notice explains how PawsAdopt handles personal data under the Data Privacy Act of 2012 (Republic Act No. 10173).</p>

  <h2>1. Who is responsible</h2>
  <p>PawsAdopt is the personal information controller for the data described here. Privacy questions and requests: <a href="mailto:<?= e(SITE_CONTACT_EMAIL) ?>"><?= e(SITE_CONTACT_EMAIL) ?></a>.</p>

  <h2>2. What we collect</h2>
  <ul>
    <li><b>Account data (everyone):</b> first and last name, email, mobile number, password (stored only as a one-way hash), and when you accepted these terms.</li>
    <li><b>Optional profile data:</b> profile photo, city, short bio. Adopters may add housing type, other pets and pet experience. Shelter staff may add a job title.</li>
    <li><b>Inquiries (adopters):</b> the messages you send to shelters and the shelters' replies.</li>
    <li><b>Shelter data (shelter staff):</b> shelter name, address, contact details and the verification document you upload.</li>
    <li><b>Technical data:</b> a session cookie so you stay logged in, and your IP address in security records (login limits and the administrator audit log).</li>
  </ul>
  <p>We collect only what the features need. We do not ask for your birthdate, government ID numbers or payment details.</p>

  <h2>3. Why we use it</h2>
  <ul>
    <li>To create and secure your account, and to run the adoption process (inquiries, responses, listings).</li>
    <li>To verify shelters, moderate content and prevent abuse and fraud.</li>
    <li>To send service emails: password reset codes, new-inquiry alerts to shelters, and decision updates to adopters. We do not send marketing email.</li>
  </ul>
  <p>Our basis is your consent (given when you register), the need to provide the service you asked for, and our legitimate interest in keeping the platform safe.</p>

  <h2>4. Who can see your data</h2>
  <ul>
    <li><b>The shelter you inquire to</b> receives your name, email, mobile number, your message, and any profile details you filled in (photo, city, bio, housing, other pets, experience). This is the purpose of an inquiry. It is also sent to the shelter's contact email.</li>
    <li><b>Administrators</b> can see account details and shelter documents in order to verify shelters and moderate the platform.</li>
    <li><b>Other visitors</b> can see pet listings and announcements, but not your account details.</li>
    <li><b>Our email provider</b> carries the emails we send. We do not sell your data or share it for advertising.</li>
  </ul>

  <h2>5. How long we keep it</h2>
  <ul>
    <li>Account data is kept while your account is active.</li>
    <li>When you delete your account, your name, email, mobile number, photo and profile details are removed right away, and your inquiry messages are erased. Pets, shelters and anonymised inquiry records stay so shelters keep their history.</li>
    <li>Password reset codes expire after 10 minutes and are removed when used or replaced. Login-limit counters are purged after two days. Administrator audit records are kept for accountability.</li>
  </ul>

  <h2>6. How we protect it</h2>
  <p>Passwords are hashed; sessions expire when idle; login attempts are rate limited; shelter verification documents are stored outside the public web folder and only administrators can open them; uploaded photos are re-processed to remove hidden metadata such as GPS location; and access to pages is limited by role. No online service is perfectly secure, so please use a strong, unique password.</p>

  <h2>7. Your rights under RA 10173</h2>
  <ul>
    <li><b>Be informed</b> about how your data is used (this notice).</li>
    <li><b>Access:</b> download a copy of your data from Profile &rarr; Your data and privacy.</li>
    <li><b>Correct</b> your data at any time on your Profile page.</li>
    <li><b>Erasure or blocking:</b> delete your account from the same page.</li>
    <li><b>Object or withdraw consent:</b> contact us at the email above; withdrawing consent may mean we can no longer provide the service.</li>
    <li><b>Data portability:</b> the downloaded file is in a standard, machine-readable format (JSON).</li>
    <li><b>Damages and complaints:</b> if you believe your rights were violated, you may complain to the National Privacy Commission (<a href="https://privacy.gov.ph" rel="noopener" target="_blank">privacy.gov.ph</a>).</li>
  </ul>

  <h2>8. Children</h2>
  <p>PawsAdopt is for people aged 18 and above. If you believe a minor has registered, contact us and we will remove the account.</p>

  <h2>9. Cookies</h2>
  <p>We use a single essential session cookie to keep you logged in. We do not use advertising or tracking cookies.</p>

  <h2>10. Changes</h2>
  <p>If this notice changes, its version number changes and you will be asked to review and accept it again.</p>
</article>
<?php include __DIR__ . '/includes/footer.php'; ?>
