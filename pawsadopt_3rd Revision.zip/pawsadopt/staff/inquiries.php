<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Adoption inquiries'; $page = 'inq'; $opt = profile_options();
// UC-12 Process adoption inquiries (each decision is also emailed to the adopter)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $msg = trim($_POST['response_message'] ?? '');
    $inq = q('SELECT i.*, p.shelter_id, p.pet_name, s.shelter_name, a.email AS a_email, a.first_name AS a_first
              FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id JOIN users a ON a.user_id=i.adopter_id
              WHERE i.inquiry_id=?', [$id])->fetch();
    if (!$inq || $inq['shelter_id'] != $u['shelter_id']) { flash('error', 'Inquiry not found.'); redirect('staff/inquiries.php'); }
    $adopter = ['email' => $inq['a_email'], 'first_name' => $inq['a_first']];
    $pdo = db();
    if ($act === 'rejected' && $inq['status'] === 'pending') {
        q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=? AND status='pending'", [$msg ?: null, $u['user_id'], $id]);
        notify_adopter_update($adopter, $inq['pet_name'], $inq['shelter_name'], 'rejected', $msg ?: null);
        flash('success', 'Response sent to the adopter.');
    } elseif ($act === 'approved' && $inq['status'] === 'pending') {
        $pdo->beginTransaction();
        try {
            $petStatus = q('SELECT status FROM pets WHERE pet_id=? FOR UPDATE', [$inq['pet_id']])->fetchColumn();
            if ($petStatus !== 'available') { $pdo->rollBack(); flash('error', 'This pet is no longer available (' . $petStatus . '), so the inquiry cannot be approved.'); }
            else {
                q("UPDATE adoption_inquiries SET status='approved', decision='approved', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=? AND status='pending'", [$msg ?: null, $u['user_id'], $id]);
                q("UPDATE pets SET status='pending' WHERE pet_id=?", [$inq['pet_id']]);
                $pdo->commit();
                notify_adopter_update($adopter, $inq['pet_name'], $inq['shelter_name'], 'approved', $msg ?: null);
                flash('success', 'Approved. The adopter was notified and the pet is now reserved.');
            }
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($ex->getCode() !== '23000') throw $ex;
            flash('error', 'Another inquiry is already approved for this pet.');
        }
    } elseif ($act === 'adopted' && $inq['status'] === 'approved') {
        $others = q("SELECT a.email, a.first_name FROM adoption_inquiries i JOIN users a ON a.user_id=i.adopter_id WHERE i.pet_id=? AND i.status='pending'", [$inq['pet_id']])->fetchAll();
        $err = set_pet_status((int)$inq['pet_id'], 'adopted');
        if (!$err) foreach ($others as $o) notify_adopter_update($o, $inq['pet_name'], $inq['shelter_name'], 'adopted_other');
        flash($err ? 'error' : 'success', $err ?: 'Pet marked as adopted. Other pending inquiries were closed and those adopters were emailed.');
    } elseif ($act === 'revoke' && $inq['status'] === 'approved' && q('SELECT status FROM pets WHERE pet_id=?', [$inq['pet_id']])->fetchColumn() === 'pending') {
        q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=?", [$msg ?: 'The shelter has withdrawn its approval.', $u['user_id'], $id]);
        $err = set_pet_status((int)$inq['pet_id'], 'available');
        if (!$err) notify_adopter_update($adopter, $inq['pet_name'], $inq['shelter_name'], 'revoked', $msg ?: null);
        flash($err ? 'error' : 'success', $err ?: 'Approval revoked. The pet is available again.');
    } else flash('error', 'That inquiry was already handled.');
    redirect('staff/inquiries.php' . (isset($_GET['s']) ? '?s=' . urlencode($_GET['s']) : ''));
}
$filter = $_GET['s'] ?? 'pending';
$valid = ['pending', 'approved', 'rejected', 'withdrawn', 'all'];
if (!in_array($filter, $valid, true)) $filter = 'pending';
$rows = q('SELECT i.*, p.pet_name, p.status AS pet_status, a.first_name, a.last_name, a.email, a.contact_number, a.profile_photo, a.city, a.bio, a.housing_type, a.other_pets, a.pet_experience
           FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN users a ON a.user_id=i.adopter_id
           WHERE p.shelter_id=? ' . ($filter === 'all' ? '' : 'AND i.status=?') . ' ORDER BY i.submitted_at DESC',
           $filter === 'all' ? [$u['shelter_id']] : [$u['shelter_id'], $filter])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Adoption inquiries</h1>
<div class="tabs"><?php foreach ($valid as $s): ?><a class="<?= $filter === $s ? 'on' : '' ?>" href="?s=<?= $s ?>"><?= ucfirst($s) ?></a><?php endforeach; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'all' ? '' : e($filter) . ' ' ?>inquiries</h2></div><?php endif; ?>
<?php foreach ($rows as $r): ?>
<article class="panel inq">
  <div class="split"><h2><?= e($r['pet_name']) ?> <span class="muted small">from <?= e($r['first_name'] . ' ' . $r['last_name']) ?></span></h2><?= badge($r['status']) ?></div>
  <p class="small muted"><?= e($r['email']) ?> &middot; <?= e($r['contact_number']) ?> &middot; sent <?= fdate($r['submitted_at']) ?> &middot; pet is <?= e($r['pet_status']) ?></p>
  <?php if ($r['city'] || $r['bio'] || $r['housing_type'] || $r['other_pets'] || $r['pet_experience'] || $r['profile_photo']): ?>
  <div class="about"><?= avatar($r) ?><div>
    <?php if ($r['city']): ?><p><strong>City:</strong> <?= e($r['city']) ?></p><?php endif; ?>
    <?php if ($r['housing_type']): ?><p><strong>Home:</strong> <?= e($opt['housing'][$r['housing_type']] ?? '') ?></p><?php endif; ?>
    <?php if ($r['other_pets']): ?><p><strong>Other pets:</strong> <?= e($r['other_pets']) ?></p><?php endif; ?>
    <?php if ($r['pet_experience']): ?><p><strong>Experience:</strong> <?= e($opt['experience'][$r['pet_experience']] ?? '') ?></p><?php endif; ?>
    <?php if ($r['bio']): ?><p class="muted"><?= nl2br(e($r['bio'])) ?></p><?php endif; ?>
  </div></div>
  <?php endif; ?>
  <p class="quote"><?= nl2br(e($r['message'])) ?></p>
  <?php if ($r['responded_at']): ?><div class="reply"><strong>Response (<?= fdate($r['responded_at']) ?>)</strong><p><?= nl2br(e($r['response_message'] ?: 'No message.')) ?></p></div><?php endif; ?>
  <?php if ($r['status'] === 'pending'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <label>Message to adopter (optional, also emailed)<textarea name="response_message" rows="3" maxlength="1000" placeholder="Next steps, a meeting time, or why it is not a fit."></textarea></label>
    <div class="actions">
      <?php if ($r['pet_status'] === 'available'): ?><button class="btn" name="action" value="approved">Approve</button>
      <?php else: ?><span class="muted small">This pet is not available, so this inquiry can only be rejected.</span><?php endif; ?>
      <button class="btn btn-danger" name="action" value="rejected" data-confirm="Reject this inquiry?">Reject</button></div>
  </form>
  <?php elseif ($r['status'] === 'approved' && $r['pet_status'] === 'pending'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <label>Optional note (used if you revoke)<input name="response_message" maxlength="200"></label>
    <div class="actions"><button class="btn btn-ghost" name="action" value="adopted" data-confirm="Mark this pet as adopted? Other pending inquiries will be closed.">Mark pet as adopted</button>
    <button class="btn btn-danger" name="action" value="revoke" data-confirm="Revoke this approval and make the pet available again?">Revoke approval</button></div>
  </form>
  <?php endif; ?>
</article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
