<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/account.php';
csrf_check();
$u = require_role();
$title = 'My profile'; $page = 'profile'; $errors = [];
$opt = profile_options();
$isAdopter = $u['role'] === 'adopter'; $isStaff = $u['role'] === 'staff';
$act = $_POST['action'] ?? '';

// UC-04 Manage profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    if ($act === 'photo') {
        $path = save_upload($_FILES['photo'] ?? [], 'avatars', false, 400);     // cropped to a 400x400 square, EXIF removed
        if ($path) { delete_public_file($u['profile_photo']); q('UPDATE users SET profile_photo=? WHERE user_id=?', [$path, $u['user_id']]); flash('success', 'Profile photo updated.'); }
        elseif (empty($_FILES['photo']['name'])) flash('error', 'Choose an image first.');
        redirect('profile.php');
    } elseif ($act === 'remove_photo') {
        delete_public_file($u['profile_photo']); q('UPDATE users SET profile_photo=NULL WHERE user_id=?', [$u['user_id']]);
        flash('success', 'Profile photo removed.'); redirect('profile.php');
    } elseif ($act === 'password') {
        if (!password_verify($_POST['current'] ?? '', $u['password_hash'])) $errors[] = 'Current password is incorrect.';
        elseif ($err = password_error($_POST['password'] ?? '')) $errors[] = $err;
        elseif ($_POST['password'] !== ($_POST['confirm'] ?? '')) $errors[] = 'New passwords do not match.';
        elseif ($_POST['password'] === $_POST['current']) $errors[] = 'Choose a password different from your current one.';
        else {
            q('UPDATE users SET password_hash=?, must_change_password=0 WHERE user_id=?', [password_hash($_POST['password'], PASSWORD_DEFAULT), $u['user_id']]);
            bump_session((int)$u['user_id'], true);
            flash('success', 'Password changed. Any other devices were signed out.');
            redirect(home_for($u));
        }
    } elseif ($act === 'export') {                       // right to access / portability
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="pawsadopt-my-data-' . date('Ymd') . '.json"');
        header('Cache-Control: private, no-store');
        echo json_encode(export_user_data($u), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    } elseif ($act === 'delete') {                       // right to erasure
        if ($u['role'] === 'admin') $errors[] = 'Administrator accounts cannot be deleted here.';
        elseif (!password_verify($_POST['confirm_password'] ?? '', $u['password_hash'])) $errors[] = 'Your password is incorrect, so the account was not deleted.';
        elseif (empty($_POST['understand'])) $errors[] = 'Please tick the box to confirm you understand.';
        else {
            delete_account($u);
            $_SESSION = []; session_destroy(); session_start();
            flash('success', 'Your account was deleted and your personal details were removed.');
            redirect('login.php');
        }
    } else {
        $email = strtolower($f('email')); $phone = ph_mobile($f('contact_number'));
        $housing = $f('housing_type'); $exp = $f('pet_experience');
        if ($f('first_name') === '' || $f('last_name') === '') $errors[] = 'First and last name are required.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if (!$phone) $errors[] = 'Contact number must be a Philippine mobile number: 11 digits starting with 09.';
        if (str_len($f('city')) > 80) $errors[] = 'City must be 80 characters or fewer.';
        if (str_len($f('bio')) > 500) $errors[] = 'Bio must be 500 characters or fewer.';
        if ($isAdopter) {
            if ($housing !== '' && !isset($opt['housing'][$housing])) $errors[] = 'Choose a valid housing type.';
            if ($exp !== '' && !isset($opt['experience'][$exp])) $errors[] = 'Choose a valid experience level.';
            if (str_len($f('other_pets')) > 150) $errors[] = 'Other pets must be 150 characters or fewer.';
        }
        if ($isStaff && str_len($f('position')) > 80) $errors[] = 'Job title must be 80 characters or fewer.';
        if (!$errors && q('SELECT 1 FROM users WHERE email=? AND user_id<>?', [$email, $u['user_id']])->fetch()) $errors[] = 'That email is used by another account.';
        if (!$errors) {
            q('UPDATE users SET first_name=?, last_name=?, email=?, contact_number=?, city=?, bio=?, housing_type=?, other_pets=?, pet_experience=?, `position`=? WHERE user_id=?',
              [$f('first_name'), $f('last_name'), $email, $phone, $f('city') ?: null, $f('bio') ?: null,
               $isAdopter && $housing ? $housing : null, $isAdopter ? ($f('other_pets') ?: null) : null, $isAdopter && $exp ? $exp : null,
               $isStaff ? ($f('position') ?: null) : null, $u['user_id']]);
            flash('success', 'Profile updated.'); redirect('profile.php');
        }
    }
}
$v = fn($k) => e($_POST[$k] ?? ($u[$k] ?? ''));
include __DIR__ . '/includes/header.php';
?>
<div class="profile-head">
  <?= avatar($u, 'lg') ?>
  <div><h1><?= e($u['first_name'] . ' ' . $u['last_name']) ?></h1>
  <p class="muted"><?= e(ucfirst($u['role'])) ?> account &middot; member since <?= fdate($u['created_at']) ?></p></div>
</div>
<?php if ($u['must_change_password']): ?><div class="flash flash-error"><strong>Action required:</strong> you are using a temporary password. Set a new one below before continuing.</div><?php endif; ?>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>

<div class="cols">
  <div>
    <form method="post" class="stack panel"><?= csrf_field() ?><h2>Details</h2>
      <div class="two"><label>First name<input name="first_name" value="<?= $v('first_name') ?>" required></label>
      <label>Last name<input name="last_name" value="<?= $v('last_name') ?>" required></label></div>
      <label>Email<input type="email" name="email" value="<?= $v('email') ?>" required></label>
      <label>Mobile number<input type="tel" name="contact_number" value="<?= $v('contact_number') ?>" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="09XXXXXXXXX" title="11 digits, starting with 09" data-ph required></label>
      <label>City or municipality (optional)<input name="city" maxlength="80" value="<?= $v('city') ?>"></label>
      <?php if ($isStaff): ?><label>Job title (optional)<input name="position" maxlength="80" value="<?= $v('position') ?>" placeholder="e.g. Adoption coordinator"></label><?php endif; ?>
      <label>About me (optional)<textarea name="bio" rows="3" maxlength="500"><?= $v('bio') ?></textarea></label>
      <?php if ($isAdopter): ?>
        <h3>Your home (helps shelters match you)</h3>
        <p class="hint">Shared with a shelter only when you send it an inquiry. All optional.</p>
        <div class="two">
          <label>Housing<select name="housing_type"><option value="">Prefer not to say</option>
            <?php $h = $_POST['housing_type'] ?? ($u['housing_type'] ?? ''); foreach ($opt['housing'] as $k => $lbl): ?><option value="<?= $k ?>" <?= $h === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select></label>
          <label>Pet experience<select name="pet_experience"><option value="">Prefer not to say</option>
            <?php $x = $_POST['pet_experience'] ?? ($u['pet_experience'] ?? ''); foreach ($opt['experience'] as $k => $lbl): ?><option value="<?= $k ?>" <?= $x === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select></label>
        </div>
        <label>Other pets at home<input name="other_pets" maxlength="150" value="<?= $v('other_pets') ?>" placeholder="e.g. 2 cats, 1 dog, none"></label>
      <?php endif; ?>
      <button class="btn">Save changes</button>
    </form>
  </div>

  <div>
    <div class="panel"><h2>Profile photo</h2>
      <form method="post" enctype="multipart/form-data" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="photo">
        <label>Choose an image (JPG, PNG, WEBP; max 5 MB)<input type="file" name="photo" accept="image/*" data-preview="#avatarPreview" required></label>
        <div id="avatarPreview" class="previews one"></div>
        <p class="hint">It is cropped to a square. Hidden data such as location is removed. Shelters you contact can see it.</p>
        <div class="actions"><button class="btn">Upload photo</button></div>
      </form>
      <?php if ($u['profile_photo']): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="remove_photo"><button class="btn btn-ghost btn-sm" data-confirm="Remove your profile photo?">Remove current photo</button></form>
      <?php endif; ?>
    </div>

    <form method="post" class="stack panel" data-match="password,confirm"><?= csrf_field() ?><input type="hidden" name="action" value="password"><h2>Change password</h2>
      <label>Current password<input type="password" name="current" required></label>
      <label>New password<input type="password" name="password" minlength="8" maxlength="72" required><span class="hint">8+ characters with a letter and a number.</span></label>
      <label>Confirm new password<input type="password" name="confirm" minlength="8" maxlength="72" required></label>
      <button class="btn">Change password</button>
    </form>
  </div>
</div>

<div class="panel">
  <h2>Your data and privacy</h2>
  <p class="muted">You accepted the <a href="<?= url('terms.php') ?>">Terms</a> and <a href="<?= url('privacy.php') ?>">Privacy Notice</a> (version <?= e($u['terms_version'] ?? '-') ?>) on <?= fdate($u['consent_at']) ?>. Under the Data Privacy Act you can get a copy of your data or have it erased.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="export"><button class="btn btn-ghost">Download my data (JSON)</button></form>
  <?php if ($u['role'] !== 'admin'): ?>
  <details class="danger-zone">
    <summary>Delete my account</summary>
    <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="delete">
      <p>This removes your name, email, mobile number, photo and profile details right away and cannot be undone.
        <?= $isAdopter ? 'Your open inquiries are withdrawn and your inquiry messages are erased.' : 'You will also be removed from your shelter; its pets and posts stay.' ?></p>
      <label>Confirm with your password<input type="password" name="confirm_password" required autocomplete="current-password"></label>
      <label class="check"><input type="checkbox" name="understand" value="1" required> I understand this is permanent.</label>
      <button class="btn btn-danger" data-confirm="Permanently delete your account?">Delete my account</button>
    </form>
  </details>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
