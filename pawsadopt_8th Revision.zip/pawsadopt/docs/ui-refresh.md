# UI refresh (8th revision)

## Files changed
| File | Change |
|---|---|
| `assets/css/style.css` | Rewritten as a token-based design system (10 sections, documented at the top). All old class names kept, so no page breaks. |
| `includes/icons.php` | **New.** `icon($name, $class = '', $label = null)` prints inline Lucide SVGs. Inline SVG, so it works under the existing CSP. |
| `includes/bootstrap.php` | Loads `icons.php`; the shelter logo fallback uses the `building-2` icon instead of an emoji. |
| `includes/header.php` | Inter + Plus Jakarta Sans fonts, skip link, `aria-current="page"` on the active nav item, icon menu toggle / bell / log out, `role="alert"` on error flashes. |
| `includes/footer.php` | Brand mark in the footer; the page loader is now a thin progress bar. |
| `admin/dashboard.php`, `staff/dashboard.php` | Page header, icon stat tiles, `.attn` accent only on tiles that need action, icon buttons. |
| `index.php`, `register.php`, `pet.php`, `pets.php`, `shelter.php`, `stories.php`, `staff/pets.php`, `includes/login_popup.php`, `includes/geo.php`, `includes/captcha.php`, `includes/match.php` | Emoji / HTML-entity icons replaced with Lucide icons. |
| `assets/js/app.js` | Eye / eye-off password toggle, Esc and click-outside close the mobile menu, flash exit uses a class (opacity + transform). |

## 60-30-10
- **60 % neutral:** `--bg #f6f7fb`, `--surface #fff`, `--surface-2`, `--line`. Used for the page, cards, the header (frosted white) and tables.
- **30 % brand:** `--ink #14213d` (navy), `--ink-2`, `--muted`, `--teal #0f766e`. Used for text, links, the footer, mission cards, chat bubbles and chart bars.
- **10 % accent:** `--accent #ffb703`. Used only for primary `.btn`, the active nav/tab indicator, `.count` badges, `.stat.attn` and the loader bar. It is never used as text on a light background.

Button convention: one `.btn` (accent) per view for the main action. Use `.btn-ghost` for secondary actions and `.btn-danger` for destructive ones.

## Contrast (WCAG AA, checked)
| Pair | Ratio |
|---|---|
| Ink on white | 15.97:1 |
| `--ink-2` | 9.26:1 |
| `--muted` on white | 5.82:1 |
| `--muted` on `--bg` | 5.44:1 |
| Teal links | 5.47:1 |
| Navy on accent | 9.15:1 |
| White on teal | 5.47:1 |
| Badge text | 5.67–7.15:1 |
| Placeholder text | 4.59:1 |
| Input borders | 3.13:1 (non-text, 1.4.11) |

The focus ring is a 2 px navy outline with a 3 px offset. On dark surfaces it switches to the accent.

## Motion
- Every `transition` and `@keyframes` animates only `transform` and/or `opacity`.
- Hover fills, card shadows and the active indicator are drawn on `::before`/`::after` layers whose opacity or scale changes, so colours and box-shadows never animate.
- Page entrance is a staggered rise on `.main > *`. Chart bars grow with `scaleY`, and grids reveal as you scroll (`animation-timeline: view()`, progressive enhancement).
- Navigation between pages uses cross-document View Transitions (`@view-transition`). The sticky header stays still while the page beneath it changes.
- `prefers-reduced-motion: reduce` turns everything off. `forced-colors` mode is also handled.
