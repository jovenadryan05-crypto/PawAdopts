# UI refresh v9 (experience layer)

Built on the 8th revision. The tokens, 60-30-10 palette, composite-only motion and cross-document View Transitions were already in place, so v9 adds only what was missing and keeps every old class and token name.

## Files
| File | Change |
|---|---|
| `assets/css/style.css` | New section 11 (toast, heart, skeleton, FAB, floating field, empty state, modal, drawer). Token aliases (`--space-xs..4xl`, `--radius-sm..full`, `--shadow-xs..2xl`), fluid type for every size step, fluid root size and container for ultra-wide, `prefers-contrast: more` AAA overrides. |
| `assets/js/ui.js` | **New.** `pawsToast`, favorites, FAB, live validation, drawer, `pawsConfirm`, `pawsSkeleton`, `pawsTransition`. |
| `assets/js/app.js` | `[data-confirm]` now opens the styled dialog; gallery swap uses a View Transition. |
| `includes/ui.php` | **New.** `heart_button()`, `empty_state()`, `fab_html()`. Loaded by `bootstrap.php`. |
| `includes/footer.php` | Toast region, FAB, `ui.js`. |
| `pets.php` | Card is an `<article>` (the old whole-card `<a>` could not hold a button). Heart, filter drawer, skeleton wrapper, `?ids=` saved-pets view, illustrated empty state. |
| `pet.php` | Heart next to the name, `#inquiry` anchor, live validation on the inquiry form. |
| `login.php` | Floating labels + live validation. `register.php`: live validation only. |
| `notifications.php`, `announcements.php`, `shelters.php`, `stories.php`, `adopter/inquiries.php`, `adopter/checkins.php`, `staff/pets.php` | Illustrated empty states. |

## Bug fixed
The v8 scroll-reveal on `.grid > .card` used `animation: rise ... both`. A fill-forwards animation keeps `transform: none` and overrides the hover `translateY`, so the card lift was blocked wherever `animation-timeline` is supported. Cards now use a time-based stagger (`--i` x 50ms, fill `backwards`), and hover works again.

## How to use
```php
<?= heart_button((int)$p['pet_id'], $p['pet_name']) ?>                       // inside a position:relative card
<?= empty_state('search', 'Title', 'One sentence.', [['href' => url('x.php'), 'label' => 'Primary', 'icon' => 'rotate-cw']]) ?>
```
Art kinds: `search`, `bowl`, `inbox`, `bell`, `error` (pass `true` as the 5th argument for the red-bordered error variant).

```js
pawsToast.success('Saved', {title: 'Profile updated'});
pawsToast.error('We could not send that.', {action: {label: 'Try again', onClick: fn}});
pawsConfirm('Delete this post?', {danger: true}).then(ok => { ... });
```
Forms: add `data-validate` to a `<form>`. Floating field markup: `.field > input.field__input[placeholder=" "] + label.field__label`.
Skeletons: wrap results in `<div data-skeleton="grid|profile|chat">` and add `data-skeleton-for="#id"` to the form that reloads it.
Drawer: `button[data-drawer-open="#id"]` + `form#id.drawer` + `.drawer-backdrop[data-drawer-backdrop="#id"][data-drawer-close]`.

## Rules kept
- Colour only from tokens. Accent stays a fill that carries navy text (heart when saved, primary chip in the FAB, count badges). The FAB itself is navy, so the page keeps one accent CTA.
- Every transition and keyframe animates `transform` and/or `opacity` (`visibility` is toggled with a delay to hide closed panels). Checked by script.
- CSP unchanged: no inline styles or scripts. Dynamic values go through `el.style.setProperty`.
- `prefers-reduced-motion`: shimmer, toast bar, spring and shake are removed; toasts still time out in JS.

## Accessibility
- Measured today: AA throughout (see v8 table). Body text is AAA already (ink 15.9:1, ink-2 9.3:1). `--muted` 5.8:1, teal links 5.5:1 and badge text 5.7 to 7.2:1 are AA, not AAA.
- With `prefers-contrast: more`, those tokens step to 7.2 to 8.3:1 (muted 8.2:1 on white, 7.7:1 on `--bg`).
- Focus ring is 3px navy with a surface halo inside overlays. Esc closes the FAB, drawer, dialog and toast. Dialog and drawer return focus to their trigger. FAB is a disclosure button (`aria-expanded`, `aria-controls`), not a menu role.
- Errors: `aria-invalid`, `aria-describedby`, one reserved message line per field (no layout shift), `role="alert"` summary toast.

## Limits
- Favorites live in `localStorage` on the device. Saving to an account would need a 7th table, which the 6-table ERD rules out.
- "Notify me" is not built: it needs a server-side alert job.
- Tested with a jsdom smoke test and a PHP parser; not run in a real browser or against PHP/MySQL here.
