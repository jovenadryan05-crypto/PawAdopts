# UI refresh v10: dark theme + glow

Built on v9. The tokens, 60-30-10 palette, composite-only motion and CSP rules were already in place, so v10 adds a theme layer and keeps every old class and token name.

## Files
| File | Change |
|---|---|
| `assets/css/style.css` | Section 1b: new tokens (light defaults + `:root[data-theme="dark"]` override). ~45 hard-coded colours replaced by tokens. Section 12: theme toggle, glow layers, focus bloom, mobile toggle row. |
| `assets/js/theme-init.js` | **New.** Blocking `<head>` script: reads `localStorage.pawsTheme` (or the OS setting) and sets `data-theme` before first paint. |
| `assets/js/ui.js` | Theme module appended: toggle, persistence, OS-follow, cross-tab sync, View-Transition cross-fade, `pawsTheme` API. |
| `includes/header.php` | `color-scheme: light dark`, `themeColorMeta`, `theme-init.js`, the toggle button, `glow-effect` on the brand mark. |
| `includes/icons.php` | `sun`, `moon` (Lucide). |
| `index.php` | Featured pet cards get `is-featured` (resting halo). |

## Design decisions
- **`--ink` flips; `--band` does not.** `--ink` is text in light mode and a light text colour in dark mode. Surfaces that must stay dark in both themes (footer, CTA band, mission cards, own chat bubble, active pager, FAB) now use `--band` / `--footer-bg` with `--on-band` text.
- **Accent unchanged.** `#ffb703` with navy text passes in both themes and is the focus colour in dark.
- **No inline script.** The CSP (`script-src 'self'`) blocks the usual inline theme snippet, so `theme-init.js` is an external, synchronous script placed before the stylesheet.
- **Glow obeys the motion rule.** Glows are pseudo-element layers; only `opacity` transitions. Resting glow is on in dark (`--glow-rest:.55`) and off in light (appears on hover/focus).
- **Theme switch is one cross-fade** (View Transitions API), skipped under `prefers-reduced-motion` and in browsers without the API.

## Utilities
- `.glow-card`: any panel; spotlight inside + ring on hover/focus-within. (Not for `.stat`: it already uses `::before`.)
- `.glow-effect`: aura behind a small element (brand mark, icon tile).
- `.pet-card.is-featured`: featured listing with a resting halo.
- Primary `.btn` glows automatically; `.btn-ghost`, `.btn-danger`, `.btn-danger-solid` stay flat.

## Rules for new code
1. Never hard-code a colour; read a token. Need a dark feature surface in both themes? Use `--band`.
2. Text on `--band` is `--on-band`; on accent is `--on-accent`.
3. Animate only `transform` and `opacity`. A new glow = a pseudo-element with `box-shadow` and an `opacity` transition.
4. API: `pawsTheme.get() / set('light'|'dark'|'system') / toggle()`; listen with `document.addEventListener('pawstheme', e => e.detail.theme)`.

## Contrast (dark theme, computed)
Body ink 14.9:1 on surface, muted 7.3:1, teal links 10.7:1, navy-on-accent buttons 9.1:1, form borders 5.1:1 (needs 3:1), badges 7.2 to 9.7:1, white on band 9.9:1, white on teal band 5.2:1. `prefers-contrast: more` lifts muted tones further. Light theme values are unchanged from v9 (AA).

## Limits
- Not run against PHP/MySQL (no PHP in the build environment). Checked with a static HTML harness in Chromium (toggle, persistence, OS default, both renders) and `node --check`.
- Email templates (`includes/notify.php`, `security.php`) keep inline light colours on purpose; mail clients ignore the site's CSS.
- Photos are not dimmed in dark mode; add `filter:brightness(.92)` to `.thumb img` if you prefer that.
