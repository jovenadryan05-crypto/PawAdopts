<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('adopter');
$title = 'Post-adoption check-ins'; $page = 'checkins'; $errors = [];
// Check-ins at 1 week, 1 month and 3 months after an adoption: how is the pet doing, plus an optional photo.
// Shelters get welfare data; with the adopter's permission the note and photo also appear on the Success Stories page.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $row = q('SELECT f.*, p.pet_name, p.shelter_id FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
              WHERE f.followup_id = ? AND i.adopter_id = ?', [(int)($_POST['id'] ?? 0), $u['user_id']])->fetch();
    $wb = $_POST['wellbeing'] ?? ''; $notes = trim($_POST['notes'] ?? '');
    if (!$row || $row['submitted_at'] || strtotime($row['due_at']) > time()) $errors[] = 'That check-in is not available.';
    elseif (!isset(wellbeing_options()[$wb])) $errors[] = 'Please choose how your pet is doing.';
    elseif (str_len($notes) > 1000) $errors[] = 'Please keep your note under 1000 characters.';
    else {
        $photo = null;
        if (!empty($_FILES['photo']['name'])) { $photo = save_upload($_FILES['photo'], 'checkins'); if (!$photo) $errors[] = 'The photo could not be saved, so the check-in was not sent. Use a JPG, PNG or WEBP under 5 MB, or send it without a photo.'; }
        if (!$errors) {
            q('UPDATE adoption_followups SET submitted_at = NOW(), wellbeing = ?, notes = ?, photo = ?, share_ok = ? WHERE followup_id = ? AND submitted_at IS NULL',
              [$wb, $notes ?: null, $photo, !empty($_POST['share_ok']) ? 1 : 0, $row['followup_id']]);
            $ms = followup_milestones()[$row['milestone']][0];
            notify_users(shelter_staff_ids((int)$row['shelter_id']), 'checkin', $row['pet_name'] . ': ' . $ms . ' check-in' . ($wb === 'struggling' ? ' (needs advice)' : ''), $u['first_name'] . ' reports: ' . strtolower(explode(':', wellbeing_options()[$wb])[0]), 'staff/followups.php');
            flash('success', 'Thank you! ' . $row['pet_name'] . "'s shelter has your update.");
            redirect('adopter/checkins.php');
        }
    }
}
$rows = q('SELECT f.*, p.pet_name, p.species, s.shelter_name, (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS pet_photo
           FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id JOIN shelters s ON s.shelter_id = p.shelter_id
           WHERE i.adopter_id = ? ORDER BY f.inquiry_id DESC, f.due_at', [$u['user_id']])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Post-adoption check-ins</h1>
<p class="muted">A short update 1 week, 1 month and 3 months after you bring a pet home. It helps the shelter know their animals are safe, and a photo is a lovely bonus.</p>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<?php if (!$rows): ?><?= empty_state('inbox', 'No check-ins yet', 'When a shelter marks an adoption as complete, your check-ins are scheduled automatically.') ?><?php endif; ?>
<?php $last = null; foreach ($rows as $r): $due = strtotime($r['due_at']) <= time(); $label = followup_milestones()[$r['milestone']][0];
  if ($last !== $r['inquiry_id']) { $last = $r['inquiry_id']; echo '<h2 class="sec">' . e($r['pet_name']) . ' <span class="muted small">' . e($r['species']) . ' from ' . e($r['shelter_name']) . '</span></h2>'; } ?>
<article class="panel" id="f<?= $r['followup_id'] ?>">
  <div class="split"><h3><?= e(ucfirst($label)) ?> check-in</h3>
    <?= $r['submitted_at'] ? '<span class="badge b-approved">Sent ' . e(fdate($r['submitted_at'])) . '</span>' : ($due ? '<span class="badge b-pending">Due now</span>' : '<span class="badge">Opens ' . e(fdate($r['due_at'])) . '</span>') ?></div>
  <?php if ($r['submitted_at']): ?>
    <p><strong><?= e(wellbeing_options()[$r['wellbeing']] ?? '') ?></strong></p>
    <?php if ($r['notes']): ?><p class="quote"><?= nl2br(e($r['notes'])) ?></p><?php endif; ?>
    <?php if ($r['photo']): ?><img class="checkin-photo" src="<?= url($r['photo']) ?>" alt="Your photo of <?= e($r['pet_name']) ?>"><?php endif; ?>
    <p class="small muted"><?= $r['share_ok'] ? 'You allowed the note and photo to appear on the Success Stories page (first name only).' : 'Only the shelter can see this.' ?></p>
  <?php elseif ($due): ?>
  <form method="post" enctype="multipart/form-data" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['followup_id'] ?>">
    <fieldset class="choice col"><legend>How is <?= e($r['pet_name']) ?> doing?</legend>
      <?php foreach (wellbeing_options() as $k => $t): ?><label><input type="radio" name="wellbeing" value="<?= $k ?>" required> <?= e($t) ?></label><?php endforeach; ?></fieldset>
    <label>Anything to share? (optional)<textarea name="notes" rows="3" maxlength="1000" placeholder="Eating well, new tricks, a funny habit, or anything you are worried about."></textarea></label>
    <label>Photo (optional; JPG, PNG, WEBP up to 5 MB)<input type="file" name="photo" accept="image/*"></label>
    <label class="check"><input type="checkbox" name="share_ok" value="1"> <span>You may show my note and photo on the public Success Stories page with my first name only.</span></label>
    <button class="btn">Send check-in</button>
  </form>
  <?php else: ?><p class="muted">This check-in opens on <?= fdate($r['due_at']) ?>. We will remind you.</p><?php endif; ?>
</article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
