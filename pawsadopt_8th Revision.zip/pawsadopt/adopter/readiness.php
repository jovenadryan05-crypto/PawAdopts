<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('adopter');
$title = 'Home-readiness check'; $page = 'profile'; $error = '';
$petId = (int)($_GET['pet'] ?? $_POST['pet'] ?? 0);
$opt = readiness_options(); $cur = get_readiness((int)$u['user_id']);
// Adoption readiness checklist: asked once before the first inquiry; shelters then read structured answers instead of free text.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $err = save_readiness((int)$u['user_id'], ['landlord' => $_POST['landlord'] ?? '', 'budget' => $_POST['budget'] ?? '', 'caregiver' => $_POST['caregiver'] ?? '', 'confirm' => $_POST['confirm'] ?? '']);
    if ($err) $error = $err;
    else { flash('success', 'Thank you. Your readiness check is saved. You can change it any time from your profile.'); redirect($petId ? 'pet.php?id=' . $petId : 'adopter/inquiries.php'); }
}
$val = fn($k) => $_POST[$k] ?? ($cur[$k] ?? '');
include __DIR__ . '/../includes/header.php';
?>
<div class="auth">
  <h1>Home-readiness check</h1>
  <p class="muted">Three quick questions, asked once. They are sent to a shelter together with your inquiry, so it can see at a glance that you are ready.</p>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack panel"><?= csrf_field() ?><input type="hidden" name="pet" value="<?= $petId ?>">
    <?php foreach (['landlord' => 'Do you have permission to keep a pet where you live?', 'budget' => 'What can you set aside each month for food, vet care and supplies?', 'caregiver' => 'Who will take care of the pet day to day?'] as $key => $question): ?>
    <fieldset class="choice col"><legend><?= e($question) ?></legend>
      <?php foreach ($opt[$key] as $v => $label): ?><label><input type="radio" name="<?= $key ?>" value="<?= e($v) ?>" <?= $val($key) === $v ? 'checked' : '' ?> required> <?= e($label) ?></label><?php endforeach; ?>
    </fieldset>
    <?php endforeach; ?>
    <label class="check"><input type="checkbox" name="confirm" value="1" required> My answers are honest and up to date.</label>
    <div class="actions"><button class="btn"><?= $petId ? 'Save and continue' : 'Save' ?></button><a class="btn btn-ghost" href="<?= url($petId ? 'pet.php?id=' . $petId : 'profile.php') ?>">Cancel</a></div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
