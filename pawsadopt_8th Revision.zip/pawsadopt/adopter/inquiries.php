<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('adopter');
$title = 'My inquiries'; $page = 'inq';
// UC-11 View and withdraw inquiries (+ answer a shelter's request to share the adoption story)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'story_consent') {
    $choice = $_POST['choice'] ?? '';
    $st = q('SELECT s.*, p.pet_name FROM success_stories s JOIN adoption_inquiries i ON i.inquiry_id=s.inquiry_id JOIN pets p ON p.pet_id=i.pet_id WHERE s.story_id=? AND i.adopter_id=?', [(int)($_POST['story_id'] ?? 0), $u['user_id']])->fetch();
    if (!$st || !in_array($choice, ['full', 'anonymous', 'declined'], true)) flash('error', 'That request was not found.');
    else {
        q('UPDATE success_stories SET consent=?, consent_at=NOW() WHERE story_id=?', [$choice, $st['story_id']]);
        notify_users(shelter_staff_ids((int)$st['shelter_id']), 'story', ['full' => 'Story approved with name and photo', 'anonymous' => 'Story approved anonymously', 'declined' => 'Story declined'][$choice], $st['pet_name'], 'staff/stories.php');
        flash('success', $choice === 'declined' ? 'Understood. The story will not be shown publicly.' : 'Thank you! The story is now public' . ($choice === 'anonymous' ? ' without your name or photo.' : ' with your first name and photo.'));
    }
    redirect('adopter/inquiries.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = q("UPDATE adoption_inquiries SET status='withdrawn' WHERE inquiry_id=? AND adopter_id=? AND status='pending'", [(int)($_POST['id'] ?? 0), $u['user_id']])->rowCount();
    if ($n) inquiry_event((int)($_POST['id'] ?? 0), 'withdrawn', (int)$u['user_id']);
    flash($n ? 'success' : 'error', $n ? 'Inquiry withdrawn.' : 'Only pending inquiries can be withdrawn.');
    redirect('adopter/inquiries.php');
}
$rows = q('SELECT i.*, p.pet_name, p.species, s.shelter_name, s.shelter_id,
           (SELECT COUNT(*) FROM inquiry_messages m WHERE m.inquiry_id=i.inquiry_id AND m.read_at IS NULL AND m.sender_id<>i.adopter_id) AS unread,
           (SELECT COUNT(*) FROM inquiry_messages m WHERE m.inquiry_id=i.inquiry_id) AS msgs FROM adoption_inquiries i
           JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id
           WHERE i.adopter_id=? ORDER BY i.submitted_at DESC', [$u['user_id']])->fetchAll();
$events = inquiry_events_for(array_column($rows, 'inquiry_id'));
$stories = [];
if ($rows) foreach (q('SELECT * FROM success_stories WHERE inquiry_id IN (' . implode(',', array_map('intval', array_column($rows, 'inquiry_id'))) . ')')->fetchAll() as $st) $stories[$st['inquiry_id']] = $st;
include __DIR__ . '/../includes/header.php';
?>
<h1>My inquiries</h1>
<?php if (!$rows): ?><?= empty_state('inbox', 'No inquiries yet', 'Find a pet you like and send the shelter a message. Replies show up here.', [['href' => url('pets.php'), 'label' => 'Explore available pets', 'icon' => 'paw-print']]) ?><?php endif; ?>
<?php foreach ($rows as $r): ?>
  <article class="panel inq">
    <div class="split"><h2><a href="<?= url('pet.php?id=' . $r['pet_id']) ?>"><?= e($r['pet_name']) ?></a> <span class="muted small"><?= e($r['species']) ?> at <a href="<?= url('shelter.php?id=' . $r['shelter_id']) ?>"><?= e($r['shelter_name']) ?></a></span></h2><?= badge($r['status']) ?></div>
    <p class="small muted">Sent <?= fdate($r['submitted_at']) ?></p>
    <p class="quote"><?= nl2br(e($r['message'])) ?></p>
    <?php if ($r['responded_at']): ?>
      <div class="reply"><strong>Shelter response (<?= fdate($r['responded_at']) ?>)</strong><p><?= nl2br(e($r['response_message'] ?: 'No message provided.')) ?></p></div>
    <?php endif; ?>
    <h3>Timeline</h3><?= render_timeline($events[$r['inquiry_id']] ?? []) ?>
    <?php if ($st = $stories[$r['inquiry_id']] ?? null): ?>
    <div class="consent-box" id="story-<?= $st['story_id'] ?>">
      <?php if ($st['status'] === 'hidden'): ?><p><strong>Success story:</strong> this story was hidden by an administrator.</p>
      <?php else: ?>
        <p><strong><?= $st['consent'] === 'requested' ? e($r['shelter_name']) . ' would like to share ' . e($r['pet_name']) . "'s adoption story" : 'Success story' ?></strong></p>
        <p class="quote"><strong><?= e($st['title']) ?></strong><br><?= nl2br(e($st['body'])) ?></p>
        <p class="small"><?php if ($st['consent'] === 'requested'): ?>It is only published if you agree. Choose how it appears:
          <?php elseif ($st['consent'] === 'declined'): ?>You declined, so it is not public. You can change your mind:
          <?php else: ?>It is public <?= $st['consent'] === 'full' ? 'with your first name and profile photo' : 'without your name or photo' ?>. You can change this any time:<?php endif; ?></p>
        <form method="post" class="actions"><?= csrf_field() ?><input type="hidden" name="action" value="story_consent"><input type="hidden" name="story_id" value="<?= $st['story_id'] ?>">
          <?php if ($st['consent'] !== 'full'): ?><button class="btn btn-sm" name="choice" value="full">Yes, show my first name and photo</button><?php endif; ?>
          <?php if ($st['consent'] !== 'anonymous'): ?><button class="btn btn-sm btn-ghost" name="choice" value="anonymous">Yes, but anonymously</button><?php endif; ?>
          <?php if ($st['consent'] !== 'declined'): ?><button class="btn btn-sm btn-danger" name="choice" value="declined">No thanks / withdraw</button><?php endif; ?></form>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    <p><a class="btn btn-ghost btn-sm" href="<?= url('chat.php?inquiry=' . $r['inquiry_id']) ?>"><?= $r['msgs'] ? 'Open conversation' : 'Start a conversation' ?><?= count_badge((int)$r['unread']) ?></a></p>
    <?php if ($r['status'] === 'pending'): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
        <button class="btn btn-ghost" data-confirm="Withdraw this inquiry?">Withdraw inquiry</button></form>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
