<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (empty($_SESSION['reset_email'])) redirect('forgot_password.php');
$title = 'Enter code'; $error = '';
// UC-03 Reset password, step 2: verify the code and set a new password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw = $_POST['password'] ?? '';
    $uid = (int)q("SELECT user_id FROM users WHERE email = ? AND account_status = 'active'", [$_SESSION['reset_email']])->fetchColumn();
    $who = $uid ? q('SELECT user_id, first_name, last_name, email, role, profile_photo FROM users WHERE user_id = ?', [$uid])->fetch() : null;
    if ($err = password_error($pw)) $error = $err;
    elseif ($who && ($err = password_context_error($pw, $who))) $error = $err;
    elseif ($pw !== ($_POST['confirm'] ?? '')) $error = 'Passwords do not match.';
    elseif (!$uid) $error = 'This code expired or was tried too many times. Request a new one.';
    else {
        $res = otp_verify($uid, 'reset', $_POST['code'] ?? '', false);       // check the code, but do not use it up yet
        if ($res === 'expired') $error = 'This code expired or was tried too many times. Request a new one.';
        elseif ($res === 'bad') $error = 'That code is not correct.';
        elseif (password_reused($uid, $pw)) $error = PASSWORD_REUSED_MSG . ' Your code is still valid.';   // only someone with the right code learns this
        else {
            otp_consume($uid, 'reset');
            // reaching the mailbox proves the email address too
            set_password($uid, $pw);
            q('UPDATE users SET email_verified_at = COALESCE(email_verified_at, NOW()) WHERE user_id = ?', [$uid]);
            bump_session($uid);                              // log out every device that was signed in
            otp_clear_all($uid); pending_email_cancel($uid);  // no leftover code or half-finished email change survives a reset
            security_notice($who, 'Your PawsAdopt password was reset', 'The password on your PawsAdopt account was just reset with an emailed code. All devices were signed out.');
            if ($who['role'] === 'admin') audit_for($uid, 'password_reset', 'user', $uid, 'Password reset by emailed code');
            rate_clear('login:email:' . $_SESSION['reset_email']);
            unset($_SESSION['reset_email']);
            flash('success', 'Password updated. Log in with your new password.');
            redirect('login.php');
        }
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Enter your code</h1>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?>
    <label>6-digit code<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required autofocus></label>
    <label>New password<input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><span class="hint">8+ characters with a letter and a number. It must be different from your current and recent passwords, and not a common password or your name.</span></label>
    <label>Confirm new password<input type="password" name="confirm" minlength="8" maxlength="72" autocomplete="new-password" required></label>
    <button class="btn">Update password</button>
  </form>
  <p class="muted"><a href="<?= url('forgot_password.php') ?>">Send a new code</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
