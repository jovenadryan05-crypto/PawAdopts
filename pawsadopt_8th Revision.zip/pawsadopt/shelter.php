<?php
require __DIR__ . '/includes/bootstrap.php';
$id = (int)($_GET['id'] ?? 0);
$sh = q('SELECT * FROM shelters WHERE shelter_id = ?', [$id])->fetch();
$u = user();
$live = $sh && $sh['verification_status'] === 'approved' && $sh['account_status'] === 'active';
$mine = $u && $u['role'] === 'staff' && (int)$u['shelter_id'] === $id;
if (!$sh || (!$live && !$mine && !($u && $u['role'] === 'admin'))) {
    http_response_code(404); $title = 'Shelter not found'; $page = 'shelterdir'; include __DIR__ . '/includes/header.php';
    echo '<div class="empty"><h2>Shelter not found</h2><p><a href="' . e(url('shelters.php')) . '">Browse shelters</a></p></div>'; include __DIR__ . '/includes/footer.php'; exit;
}
$title = $sh['shelter_name']; $page = 'shelterdir';
// Public shelter profile: who they are, where they are (map), their records, history, success stories and transparency numbers.
$st = $live ? (shelter_stats([$id])[$id] ?? null) : null;
$pets = q("SELECT p.*, (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
           FROM pets p WHERE p.shelter_id = ? AND p.status = 'available' ORDER BY p.created_at DESC LIMIT 8", [$id])->fetchAll();
$adopted = q("SELECT p.pet_name, p.species, p.breed, ev.created_at AS adopted_at, (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
              FROM inquiry_events ev JOIN adoption_inquiries i ON i.inquiry_id = ev.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
              WHERE ev.event_type = 'adopted' AND p.shelter_id = ? ORDER BY ev.created_at DESC LIMIT 12", [$id])->fetchAll();
$stories = q("SELECT st.story_id, st.title, st.body, st.consent, p.pet_name, p.species, a.first_name FROM success_stories st JOIN adoption_inquiries i ON i.inquiry_id = st.inquiry_id
              JOIN pets p ON p.pet_id = i.pet_id JOIN users a ON a.user_id = i.adopter_id
              WHERE st.shelter_id = ? AND st.status = 'published' AND st.consent IN ('full','anonymous') ORDER BY st.created_at DESC LIMIT 4", [$id])->fetchAll();
$updates = $live ? public_checkins(4, $id) : [];
$posts = q("SELECT * FROM announcements_donations WHERE shelter_id = ? AND status = 'published' ORDER BY created_at DESC LIMIT 4", [$id])->fetchAll();
$firstAdoption = q("SELECT MIN(ev.created_at) FROM inquiry_events ev JOIN adoption_inquiries i ON i.inquiry_id = ev.inquiry_id JOIN pets p ON p.pet_id = i.pet_id WHERE ev.event_type = 'adopted' AND p.shelter_id = ?", [$id])->fetchColumn();
$totalListed = (int)q("SELECT COUNT(*) FROM pets WHERE shelter_id = ? AND status <> 'draft'", [$id])->fetchColumn();
$place = trim(($sh['city'] ?? '') . ', ' . ($sh['province'] ?? ''), ', ');
$mapQuery = trim($sh['address'] . ', ' . $place . ', Philippines', ', ');
include __DIR__ . '/includes/header.php';
?>
<p><a href="<?= url('shelters.php') ?>">&larr; All shelters</a></p>
<?php if (!$live): ?><div class="flash flash-info">This shelter is <?= e($sh['verification_status'] === 'approved' ? 'suspended' : $sh['verification_status']) ?>, so this page is visible only to its staff and to administrators.</div><?php endif; ?>
<section class="shelter-head">
  <?= shelter_logo($sh, 'lg') ?>
  <div><h1><?= e($sh['shelter_name']) ?> <?php if ($live): ?><span class="badge b-approved">Verified shelter</span><?php endif; ?></h1>
    <p class="muted"><?= e($place ?: $sh['address']) ?> &middot; on PawsAdopt since <?= fdate($sh['created_at']) ?></p></div>
  <?php if ($mine && !empty($u['is_shelter_admin'])): ?><a class="btn btn-ghost btn-sm" href="<?= url('staff/shelter.php') ?>">Edit profile</a><?php endif; ?>
</section>

<?php if ($st): ?>
<h2>Transparency</h2>
<?= stats_cards($st) ?>
<p class="small muted">Counted automatically from adoptions completed on PawsAdopt. <?= (int)$st['checkins'] ? (int)$st['checkins_ok'] . ' of ' . (int)$st['checkins'] . ' adopter check-ins reported the pet doing well or thriving.' : 'Adopter welfare check-ins will appear here as adoptions mature.' ?></p>
<?php endif; ?>

<div class="cols">
  <div>
    <div class="panel"><h2>About</h2>
      <p class="prose"><?= $sh['about'] ? nl2br(e($sh['about'])) : '<span class="muted">This shelter has not written a description yet.</span>' ?></p>
      <p><strong>Contact</strong><br><?= e($sh['contact_email']) ?> &middot; <?= e($sh['contact_number']) ?></p></div>
    <div class="panel"><h2>History</h2>
      <ul class="history">
        <li><b><?= fdate($sh['created_at']) ?></b> Registered on PawsAdopt</li>
        <?php if ($sh['reviewed_at'] && $sh['verification_status'] === 'approved'): ?><li><b><?= fdate($sh['reviewed_at']) ?></b> Verified by a PawsAdopt administrator</li><?php endif; ?>
        <?php if ($firstAdoption): ?><li><b><?= fdate($firstAdoption) ?></b> First adoption completed</li><?php endif; ?>
        <li><b><?= $totalListed ?></b> pet<?= $totalListed === 1 ? '' : 's' ?> listed in total<?= $st ? ', <b>' . (int)$st['adopted_total'] . '</b> adopted' : '' ?></li>
      </ul></div>
  </div>
  <div class="panel"><h2>Location</h2>
    <p><?= e($sh['address']) ?><?= $place ? '<br>' . e($place) : '' ?></p>
    <iframe class="map-frame" title="Map showing <?= e($sh['shelter_name']) ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
      src="<?= e(map_embed_url($sh, $mapQuery)) ?>"></iframe>
    <p class="small"><a href="<?= e(map_open_url($sh, $mapQuery)) ?>" target="_blank" rel="noopener">Open in Google Maps / get directions</a> &middot;
      <a href="<?= e(map_osm_url($sh, $mapQuery)) ?>" target="_blank" rel="noopener">OpenStreetMap</a></p>
    <?php if (has_pin($sh)): ?><p class="hint"><span class="badge b-approved">Exact pin</span> Placed by the shelter at <?= e(pin_text($sh)) ?>.</p>
    <?php else: ?><p class="hint"><span class="badge b-pending">Approximate</span> This shelter has not set an exact pin yet, so the map is a best guess from the address. Confirm with the shelter before you travel.</p><?php endif; ?>
  </div>
</div>

<h2>Pets waiting (<?= $st ? (int)$st['waiting'] : count($pets) ?>)</h2>
<?php if (!$pets): ?><div class="empty"><p>No pets are listed right now. Check back soon.</p></div><?php else: ?>
<div class="grid"><?php foreach ($pets as $p): ?>
  <a class="card pet-card" href="<?= url('pet.php?id=' . $p['pet_id']) ?>"><div class="thumb"><?php if ($p['photo']): ?><img src="<?= url($p['photo']) ?>" alt="<?= e($p['pet_name']) ?>" loading="lazy"><?php else: ?><span class="ph"><?= icon('paw-print') ?></span><?php endif; ?></div>
    <div class="card-body"><h3><?= e($p['pet_name']) ?></h3><p class="muted"><?= e($p['breed'] ?: $p['species']) ?> &middot; <?= e(ucfirst($p['sex'])) ?> &middot; <?= age_label((int)$p['age_months']) ?></p></div></a>
<?php endforeach; ?></div>
<p><a href="<?= url('pets.php?shelter=' . $id) ?>">See all of this shelter's pets &rarr;</a></p>
<?php endif; ?>

<h2>Adoption records</h2>
<?php if (!$adopted): ?><p class="muted">No adoptions have been completed through PawsAdopt yet.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Pet</th><th>Adopted</th></tr></thead><tbody>
<?php foreach ($adopted as $a): ?><tr><td class="who"><span class="mini"><?php if ($a['photo']): ?><img src="<?= url($a['photo']) ?>" alt=""><?php else: ?><?= icon('paw-print') ?><?php endif; ?></span><span><?= e($a['pet_name']) ?> <span class="muted small"><?= e($a['breed'] ?: $a['species']) ?></span></span></td><td><?= fdate($a['adopted_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>

<?php if ($stories || $updates): ?>
<h2>Success stories</h2>
<div class="stories-grid">
<?php foreach ($stories as $r): ?><article class="story"><div class="story-body"><h3><a class="story-link" href="<?= url('story.php?id=' . (int)$r['story_id']) ?>"><?= e($r['title']) ?></a></h3><p class="small muted"><?= e($r['pet_name']) ?> the <?= e(strtolower($r['species'])) ?></p><p class="prose"><?= e(story_excerpt($r['body'], 180)) ?></p><p><a href="<?= url('story.php?id=' . (int)$r['story_id']) ?>">Read the full story &rarr;</a></p>
  <p class="small muted"><?= $r['consent'] === 'full' ? 'Adopted by ' . e($r['first_name']) : 'Adopted by a loving family' ?></p></div></article><?php endforeach; ?>
<?php foreach ($updates as $r): ?><article class="story"><?php if ($r['photo']): ?><div class="thumb"><img src="<?= url($r['photo']) ?>" alt="<?= e($r['pet_name']) ?> at home" loading="lazy"></div><?php endif; ?>
  <div class="story-body"><h3><a class="story-link" href="<?= url('story.php?update=' . (int)$r['followup_id']) ?>"><?= e($r['pet_name']) ?>, <?= e(followup_milestones()[$r['milestone']][0]) ?> after adoption</a></h3><p class="prose"><?= e(story_excerpt($r['notes'] ?: 'Settling in well.', 180)) ?></p><p><a href="<?= url('story.php?update=' . (int)$r['followup_id']) ?>">Read more &rarr;</a></p><p class="small muted">Update from <?= e($r['first_name']) ?></p></div></article><?php endforeach; ?>
</div>
<p><a href="<?= url('stories.php') ?>">More success stories &rarr;</a></p>
<?php endif; ?>

<?php if ($posts): ?><h2>Announcements &amp; donation requests</h2>
<div class="posts"><?php foreach ($posts as $p): ?><article class="post"><div class="post-head"><span class="badge b-<?= e($p['post_type']) ?>"><?= $p['post_type'] === 'donation' ? 'Donation request' : 'Announcement' ?></span></div>
  <h3><?= e($p['title']) ?></h3><p><?= e(cut_text($p['content'], 260)) ?></p><p class="small muted"><?= fdate($p['created_at']) ?></p></article><?php endforeach; ?></div><?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
