<?php
// JSON endpoint behind the chat page: poll for new messages, send a message, unread count for the navigation badge.
require __DIR__ . '/includes/bootstrap.php';
$u = user();
if (!$u) respond_json(['ok' => false, 'error' => 'You were logged out. Please log in again.', 'login' => true], 401);
if (($u['terms_version'] ?? null) !== TERMS_VERSION || $u['must_change_password']) respond_json(['ok' => false, 'error' => 'Please finish the pending account steps first.', 'reload' => true], 403);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) respond_json(['ok' => false, 'error' => 'Your page expired. Refresh and try again.'], 419);
    session_write_close();                                   // do not hold the session lock while we work
    $i = chat_inquiry((int)($_POST['inquiry'] ?? 0));
    $viewer = $i ? chat_viewer($i, $u) : null;
    if (!$viewer) respond_json(['ok' => false, 'error' => 'Conversation not found.'], 404);
    if ($viewer !== 'admin' && !email_verified($u)) respond_json(['ok' => false, 'error' => 'Verify your email to send messages.', 'verify' => true], 403);
    $r = chat_send($i, $viewer, $u, (string)($_POST['body'] ?? ''));
    if (!$r['ok']) respond_json(['ok' => false, 'error' => $r['error']], $r['status']);
    chat_mark_read($i, $viewer);
    respond_json(['ok' => true, 'message' => $r['message']]);
}

// GET: abort (not just close) the session so polling neither holds the lock nor keeps an idle login alive
session_abort();
if (isset($_GET['unread'])) respond_json(['ok' => true, 'unread' => nav_unread($u), 'notifications' => notif_count($u)]);
$i = chat_inquiry((int)($_GET['inquiry'] ?? 0));
$viewer = $i ? chat_viewer($i, $u) : null;
if (!$viewer) respond_json(['ok' => false, 'error' => 'Conversation not found.'], 404);
if ($viewer !== 'admin' && !email_verified($u)) respond_json(['ok' => false, 'error' => 'Verify your email to use messages.', 'verify' => true], 403);
chat_mark_read($i, $viewer);
$reason = chat_closed_reason($i, $viewer, $u);
$msgs = chat_messages($i, $viewer, $u, max(0, (int)($_GET['after'] ?? 0)));
respond_json(['ok' => true, 'messages' => $msgs, 'can_send' => $reason === null, 'closed_reason' => $reason,
              'seen_upto' => chat_seen_upto($i, $viewer), 'unread' => nav_unread($u), 'notifications' => notif_count($u)]);
