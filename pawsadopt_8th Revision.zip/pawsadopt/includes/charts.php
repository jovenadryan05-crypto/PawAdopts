<?php
// Plain server-rendered SVG charts: no JavaScript library, so they work under our script-src 'self' policy.
// Colours come from CSS classes (inline style attributes are blocked by the policy too).
function svg_bar_chart(array $labels, array $values, string $title): string {
    $n = count($values); if (!$n) return '';
    $W = 440; $H = 190; $left = 30; $bottom = 30; $top = 22; $max = max(1, max($values));
    $slot = ($W - $left - 10) / $n; $bw = min(46, $slot - 12); $plotH = $H - $top - $bottom;
    $id = 'c' . substr(md5($title), 0, 6);
    $s = '<svg class="chart" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-labelledby="' . $id . '"><title id="' . $id . '">' . e($title) . '</title>';
    foreach ([0, 0.5, 1] as $f) { $y = $top + $plotH * (1 - $f); $s .= '<line class="chart-grid" x1="' . $left . '" x2="' . ($W - 6) . '" y1="' . $y . '" y2="' . $y . '"/><text class="chart-axis" x="' . ($left - 5) . '" y="' . ($y + 3) . '" text-anchor="end">' . round($max * $f) . '</text>'; }
    foreach ($values as $i => $v) {
        $h = $plotH * $v / $max; $x = $left + $i * $slot + ($slot - $bw) / 2; $y = $top + $plotH - $h;
        $s .= '<rect class="chart-bar" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($bw, 1) . '" height="' . round($h, 1) . '" rx="3"><title>' . e($labels[$i] . ': ' . $v) . '</title></rect>'
            . '<text class="chart-val" x="' . round($x + $bw / 2, 1) . '" y="' . round($y - 4, 1) . '" text-anchor="middle">' . (int)$v . '</text>'
            . '<text class="chart-axis" x="' . round($x + $bw / 2, 1) . '" y="' . ($H - 10) . '" text-anchor="middle">' . e($labels[$i]) . '</text>';
    }
    return $s . '</svg>';
}
