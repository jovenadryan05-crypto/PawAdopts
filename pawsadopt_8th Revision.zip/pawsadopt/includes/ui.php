<?php
// v9 UI helpers: favorite heart, illustrated empty state, quick-action (FAB) items.
// Everything is plain HTML + inline SVG, so it works under the strict CSP (no inline styles or scripts).

/** Favorite toggle. assets/js/ui.js wires every [data-fav]; before the script loads it is just an inert button. */
function heart_button(int $petId, string $petName, string $extra = ''): string {
    $outline = ICONS['heart'];
    $fill = str_replace('<path ', '<path class="heart__fill" ', $outline);
    return '<button type="button" class="heart' . ($extra !== '' ? ' ' . e($extra) : '') . '" data-fav="' . $petId . '" data-name="' . e($petName)
        . '" aria-pressed="false" aria-label="Save ' . e($petName) . ' to favorites">'
        . '<svg class="heart__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
        . $fill . $outline . '</svg></button>';
}

/** Custom illustrations drawn only with the palette tokens (classes are styled in style.css). */
function empty_art(string $kind): string {
    $a = [
        'search' => '<ellipse class="art-soft" cx="100" cy="146" rx="62" ry="8"/><circle class="art-fill" cx="88" cy="70" r="42"/>'
            . '<path class="art-line" stroke-width="9" d="M120 102 156 138"/>'
            . '<ellipse class="art-accent" cx="88" cy="80" rx="15" ry="12"/><circle class="art-accent" cx="69" cy="62" r="6"/><circle class="art-accent" cx="80" cy="52" r="6"/>'
            . '<circle class="art-accent" cx="96" cy="52" r="6"/><circle class="art-accent" cx="107" cy="62" r="6"/>',
        'bowl' => '<ellipse class="art-soft" cx="100" cy="146" rx="64" ry="8"/><g transform="rotate(-16 100 66)"><rect class="art-accent" x="68" y="58" width="64" height="16" rx="8"/>'
            . '<circle class="art-accent" cx="70" cy="58" r="9"/><circle class="art-accent" cx="70" cy="74" r="9"/><circle class="art-accent" cx="130" cy="58" r="9"/><circle class="art-accent" cx="130" cy="74" r="9"/></g>'
            . '<path class="art-fill" d="M48 96h104l-10 34a8 8 0 0 1-8 6H66a8 8 0 0 1-8-6z"/><path class="art-line" d="M62 110h76"/>',
        'inbox' => '<ellipse class="art-soft" cx="100" cy="146" rx="62" ry="8"/><rect class="art-fill" x="38" y="52" width="124" height="82" rx="10"/>'
            . '<path class="art-line" d="m42 58 58 42 58-42"/><circle class="art-accent" cx="100" cy="100" r="11"/><path class="art-line" stroke-width="2" d="M96 100h8"/>'
            . '<path class="art-teal" d="M150 34c6 4 10 10 10 18M158 24c10 7 16 16 16 28"/>',
        'bell' => '<ellipse class="art-soft" cx="100" cy="148" rx="52" ry="7"/><path class="art-fill" d="M58 116c10-10 12-24 12-42a30 30 0 0 1 60 0c0 18 2 32 12 42z"/>'
            . '<path class="art-line" d="M90 128a10 10 0 0 0 20 0"/><circle class="art-accent" cx="100" cy="38" r="6"/><path class="art-teal" d="M152 52c8 6 12 14 12 24M160 40c12 9 18 22 18 36"/>',
        'error' => '<ellipse class="art-soft" cx="100" cy="148" rx="62" ry="8"/><path class="art-fill" d="M100 26 170 130H30z"/><path class="art-line" d="M100 64v38"/><circle class="art-accent" cx="100" cy="116" r="5"/>',
    ];
    return '<svg class="empty__art" viewBox="0 0 200 160" aria-hidden="true" focusable="false">' . ($a[$kind] ?? $a['search']) . '</svg>';
}

/**
 * Illustrated empty state with a way forward.
 * @param array $actions list of ['href' => url, 'label' => text, 'ghost' => bool, 'icon' => icon name]; the first is the primary action
 */
function empty_state(string $art, string $title, string $text = '', array $actions = [], bool $error = false): string {
    $h = '<section class="empty empty--art' . ($error ? ' empty--error' : '') . '">' . empty_art($art) . '<h2>' . e($title) . '</h2>';
    if ($text !== '') $h .= '<p>' . e($text) . '</p>';
    if ($actions) {
        $h .= '<div class="actions">';
        foreach ($actions as $i => $a) {
            $ghost = !empty($a['ghost']) || $i > 0;
            $h .= '<a class="btn' . ($ghost ? ' btn-ghost' : '') . '" href="' . e($a['href']) . '">' . (!empty($a['icon']) ? icon($a['icon']) : '') . e($a['label']) . '</a>';
        }
        $h .= '</div>';
    }
    return $h . '</section>';
}

/**
 * Quick actions for the floating button, by role. Returns [label, href, icon, extra-html, primary?].
 * The first item is drawn nearest the button. Uses the counts header.php already computed.
 */
function fab_items(?array $u, bool $onPetPage = false): array {
    global $unread, $notifs, $checkins, $navNoResp, $navPetitions;
    if (!$u) return [];
    $unread = (int)($unread ?? 0); $notifs = (int)($notifs ?? 0);
    $items = [];
    if ($u['role'] === 'adopter') {
        if ($onPetPage) $items[] = ['Send an inquiry', '#inquiry', 'message-circle', '', true];
        if (!empty($checkins)) $items[] = ['Check-ins due', url('adopter/checkins.php'), 'clipboard-list', '<span class="count">' . (int)$checkins . '</span>', !$onPetPage];
        $items[] = ['Messages', url('adopter/inquiries.php'), 'message-circle', count_badge($unread), false];
        $items[] = ['Find a pet', url('pets.php'), 'search', '', false];
    } elseif ($u['role'] === 'staff') {
        if (!empty($navNoResp)) $items[] = ['Needs welfare check', url('staff/followups.php'), 'clipboard-list', '<span class="count">' . (int)$navNoResp . '</span>', true];
        $items[] = ['Add a pet', url('staff/pet_form.php'), 'plus', '', false];
        $items[] = ['Inquiries', url('staff/inquiries.php'), 'message-circle', count_badge($unread), false];
    } elseif ($u['role'] === 'admin') {
        if (!empty($navPetitions)) $items[] = ['Open petitions', url('admin/petitions.php'), 'file-text', '<span class="count">' . (int)$navPetitions . '</span>', true];
        $items[] = ['Moderation', url('admin/moderation.php'), 'shield-check', count_badge($unread), false];
        $items[] = ['Shelters', url('admin/shelters.php'), 'building-2', '', false];
    }
    if ($u['role'] !== 'admin') $items[] = ['Notifications', url('notifications.php'), 'bell', notif_badge($notifs), false];
    return array_slice($items, 0, 6);
}

/** Floating action button: a disclosure (aria-expanded + aria-controls), never a menu role, so every link stays a normal tab stop. */
function fab_html(?array $u, bool $onPetPage = false): string {
    $items = fab_items($u, $onPetPage);
    if (!$items) return '';
    $h = '<div class="fab" data-fab><div class="fab__scrim" data-fab-close aria-hidden="true"></div><ul class="fab__menu" id="fabMenu" aria-label="Quick actions">';
    foreach (array_reverse($items) as $it) {   // markup order = visual order top to bottom; the first item sits closest to the button
        [$label, $href, $ic, $extra, $primary] = $it;
        $h .= '<li class="fab__item"><a class="fab__link' . ($primary ? ' fab__link--primary' : '') . '" href="' . e($href) . '"><span>' . e($label) . '</span>' . $extra
            . '<span class="fab__chip">' . icon($ic) . '</span></a></li>';
    }
    $h .= '</ul><button type="button" class="fab__toggle" aria-expanded="false" aria-controls="fabMenu" aria-label="Quick actions">' . icon('plus')
        . '<span class="count fab__badge" data-unread' . ((int)($GLOBALS['unread'] ?? 0) > 0 ? '' : ' hidden') . '>' . (int)($GLOBALS['unread'] ?? 0) . '</span></button></div>';
    return $h;
}
