<?php
// Welcome popup + chime shown once right after a user logs in (flag set in login_user(), cleared here).
// Included by header.php, so it shares that file's variables. It is a native <dialog> that stays closed unless assets/js/app.js opens it,
// so without JavaScript nothing blocks the page. All text is escaped.
if ($u && !empty($_SESSION['login_popup'])) {
    unset($_SESSION['login_popup']);
    $lpItems = [];
    $lpRecent = q('SELECT notification_id, title FROM notifications WHERE user_id = ? AND read_at IS NULL ORDER BY notification_id DESC LIMIT 4', [$u['user_id']])->fetchAll();
    if ($notifs > 0) $lpItems[] = [$notifs . ' unread notification' . ($notifs === 1 ? '' : 's'), 'notifications.php'];
    if ($u['role'] === 'admin') {
        if ($unread > 0) $lpItems[] = [$unread . ' reported conversation' . ($unread === 1 ? '' : 's') . ' to review', 'admin/moderation.php'];
        if ($navPetitions > 0) $lpItems[] = [$navPetitions . ' reactivation petition' . ($navPetitions === 1 ? '' : 's') . ' waiting', 'admin/petitions.php'];
        $lpPending = (int)q("SELECT COUNT(*) FROM shelters WHERE verification_status = 'pending'")->fetchColumn();
        if ($lpPending > 0) $lpItems[] = [$lpPending . ' shelter' . ($lpPending === 1 ? '' : 's') . ' awaiting review', 'admin/shelters.php'];
    } else {
        if ($unread > 0) $lpItems[] = [$unread . ' unread message' . ($unread === 1 ? '' : 's'), $u['role'] === 'staff' ? 'staff/inquiries.php' : 'adopter/inquiries.php'];
        if ($u['role'] === 'adopter' && $checkins) $lpItems[] = [$checkins . ' check-in' . ($checkins === 1 ? '' : 's') . ' due', 'adopter/checkins.php'];
        if ($u['role'] === 'staff' && $navNoResp > 0) $lpItems[] = [$navNoResp . ' adoption' . ($navNoResp === 1 ? '' : 's') . ' with no response: consider a welfare call or visit', 'staff/followups.php?s=noresponse'];
        if (shelter_suspended($u)) $lpItems[] = ['Your shelter is suspended. You can petition to be reactivated.', 'staff/petition.php'];
    }
    ?>
<dialog id="loginPopup" class="login-popup" data-sound="<?= e(url('assets/sounds/notify.wav')) ?>" aria-labelledby="lpTitle">
  <div class="lp-body"><div class="lp-head"><span class="lp-paw"><?= icon('paw-print') ?></span><div><h2 id="lpTitle">Welcome back, <?= e($u['first_name']) ?></h2>
    <p class="muted small"><?= $lpItems || $lpRecent ? 'Here is what is waiting for you.' : 'You are all caught up. Nothing new right now.' ?></p></div></div>
  <?php if ($lpItems): ?><ul class="lp-list"><?php foreach ($lpItems as [$lpT, $lpL]): ?><li><a href="<?= e(url($lpL)) ?>"><?= e($lpT) ?></a></li><?php endforeach; ?></ul><?php endif; ?>
  <?php if ($lpRecent): ?><p class="small muted lp-sub">Latest</p><ul class="lp-list lp-recent"><?php foreach ($lpRecent as $lpN): ?><li><a href="<?= e(url('notifications.php?go=' . (int)$lpN['notification_id'])) ?>"><?= e($lpN['title']) ?></a></li><?php endforeach; ?></ul><?php endif; ?>
  <div class="actions"><button type="button" class="btn" data-popup-close>Continue</button>
    <button type="button" class="btn btn-ghost btn-sm" data-sound-toggle aria-pressed="true">Sound on</button></div></div>
</dialog>
<?php } ?>
