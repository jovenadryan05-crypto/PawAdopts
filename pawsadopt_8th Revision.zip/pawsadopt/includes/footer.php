</main>
<footer class="site-footer"><div class="wrap foot"><span class="foot-brand"><span class="paw"><?= icon('paw-print') ?></span>PawsAdopt</span><span class="foot-tag">PawsAdopt connects adopters with verified animal shelters. Adopt, don't shop.</span>
  <span class="legal-links"><a href="<?= url('terms.php') ?>">Terms</a><a href="<?= url('privacy.php') ?>">Privacy Notice</a></span></div></footer>
<?php $noFab = in_array(basename($_SERVER['SCRIPT_NAME']), ['login.php','register.php','forgot_password.php','reset_password.php','verify_email.php','verify_login.php','consent.php','chat.php','logout.php'], true);
if (!$noFab && ($fab ?? true)) echo fab_html(user(), !empty($fabInquiry)); ?>
<div id="toastRegion" class="toast-region" role="region" aria-label="Notifications" aria-live="polite" aria-relevant="additions"></div>
<div id="pageLoader" class="page-loader" hidden aria-hidden="true"><span class="page-loader-bar"></span></div>
<script src="<?= url('assets/js/app.js') ?>"></script>
<script src="<?= url('assets/js/ui.js') ?>"></script>
<?php foreach (($scripts ?? []) as $sc): ?><script src="<?= url($sc) ?>"></script>
<?php endforeach; ?>
</body>
</html>
