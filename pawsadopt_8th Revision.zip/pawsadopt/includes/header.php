<?php $u = user(); $page = $page ?? ''; $unread = $u ? nav_unread($u) : 0; $notifs = $u ? notif_count($u) : 0;
// adopters who adopted through PawsAdopt see a Check-ins link; reminders are created here (in-app) when a check-in is due
$on = fn(string $key, string $extra = '') => ' class="' . trim($extra . ($page === $key ? ' on' : '')) . '"' . ($page === $key ? ' aria-current="page"' : '');
$navPetitions = ($u && $u['role'] === 'admin') ? petition_open_count() : 0; $checkins = null; $navNoResp = ($u && shelter_ready($u)) ? followups_no_response_count((int)$u['shelter_id']) : 0;
if ($u && $u['role'] === 'adopter') {
    $hasAdoption = (bool)q("SELECT 1 FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id WHERE i.adopter_id = ? LIMIT 1", [$u['user_id']])->fetch();
    if ($hasAdoption) { followups_process($u, false); $checkins = followups_due_count((int)$u['user_id']); $notifs = notif_count($u); }
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#ffffff" id="themeColorMeta">
<script src="<?= url('assets/js/theme-init.js') ?>"></script>
<title><?= e($title ?? 'PawsAdopt') ?> | PawsAdopt</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body<?= $u ? ' data-unread-url="' . e(url('chat_api.php?unread=1')) . '"' : '' ?>>
<a class="skip-link" href="#main">Skip to main content</a>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?= url($u ? home_for($u) : 'index.php') ?>"><span class="paw glow-effect"><?= icon('paw-print') ?></span>PawsAdopt</a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="nav"><?= icon('menu', 'i-open') ?><?= icon('x', 'i-close') ?><span>Menu</span></button>
    <nav id="nav" class="nav" aria-label="Main">
      <?php if (!$u): ?><a href="<?= url('index.php') ?>" <?= $on('home') ?>>Home</a><?php endif; ?>
      <a href="<?= url('pets.php') ?>" <?= $on('browse') ?>>Find a pet</a>
      <a href="<?= url('shelters.php') ?>" <?= $on('shelterdir') ?>>Shelters</a>
      <a href="<?= url('announcements.php') ?>" <?= $on('news') ?>>Announcements</a>
      <a href="<?= url('stories.php') ?>" <?= $on('stories') ?>>Success stories</a>
      <?php if ($u && $u['role']==='adopter'): ?>
        <a href="<?= url('adopter/inquiries.php') ?>" <?= $on('inq') ?>>My inquiries<?= count_badge($unread) ?></a>
        <?php if ($checkins !== null): ?><a href="<?= url('adopter/checkins.php') ?>" <?= $on('checkins') ?>>Check-ins<?= $checkins ? '<span class="count">' . $checkins . '</span>' : '' ?></a><?php endif; ?>
      <?php elseif ($u && $u['role']==='staff'): ?>
        <a href="<?= url('staff/dashboard.php') ?>" <?= $on('dash') ?>>Dashboard</a>
        <?php if (shelter_suspended($u)): ?><a href="<?= url('staff/petition.php') ?>" <?= $on('petition') ?>>Reactivation</a><?php endif; ?>
        <a href="<?= url('staff/pets.php') ?>" <?= $on('pets') ?>>Pet listings</a>
        <a href="<?= url('staff/inquiries.php') ?>" <?= $on('inq') ?>>Inquiries<?= count_badge($unread) ?></a>
        <a href="<?= url('staff/posts.php') ?>" <?= $on('posts') ?>>Posts</a>
        <a href="<?= url('staff/followups.php') ?>" <?= $on('sfollow') ?>>Welfare<?= $navNoResp ? '<span class="count">' . $navNoResp . '</span>' : '' ?></a>
        <?php if (!empty($u['is_shelter_admin'])): ?><a href="<?= url('staff/team.php') ?>" <?= $on('team') ?>>Team</a><?php endif; ?>
        <a href="<?= url('staff/stories.php') ?>" <?= $on('sstories') ?>>Stories</a>
      <?php elseif ($u && $u['role']==='admin'): ?>
        <a href="<?= url('admin/dashboard.php') ?>" <?= $on('dash') ?>>Dashboard</a>
        <a href="<?= url('admin/shelters.php') ?>" <?= $on('shelters') ?>>Shelters</a>
        <a href="<?= url('admin/petitions.php') ?>" <?= $on('petitions') ?>>Petitions<?= $navPetitions ? '<span class="count">' . $navPetitions . '</span>' : '' ?></a>
        <a href="<?= url('admin/users.php') ?>" <?= $on('users') ?>>Users</a>
        <a href="<?= url('admin/moderation.php') ?>" <?= $on('mod') ?>>Moderation<?= count_badge($unread) ?></a>
        <a href="<?= url('admin/audit.php') ?>" <?= $on('audit') ?>>Audit log</a>
      <?php endif; ?>
      <span class="nav-sep"></span>
      <button type="button" class="theme-toggle" role="switch" aria-checked="false" data-theme-toggle><?= icon('sun', 'i-sun') ?><?= icon('moon', 'i-moon') ?><span class="theme-toggle__label">Dark mode</span></button>
      <?php if ($u): ?>
        <a href="<?= url('notifications.php') ?>" <?= $on('notif', 'bell') ?>><?= icon('bell') ?><span class="bell-label">Notifications</span><?= notif_badge($notifs) ?></a>
        <a href="<?= url('profile.php') ?>" <?= $on('profile', 'me') ?>><?= avatar($u, 'sm') ?><?= e($u['first_name']) ?></a>
        <form method="post" action="<?= url('logout.php') ?>" class="inline"><?= csrf_field() ?><button class="linklike"><?= icon('log-out') ?><span>Log out</span></button></form>
      <?php else: ?>
        <a href="<?= url('login.php') ?>">Log in</a>
        <a href="<?= url('register.php') ?>" class="btn btn-sm">Sign up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php include __DIR__ . '/login_popup.php'; ?>
<?php if ($u && $u['role'] !== 'admin' && !email_verified($u) && basename($_SERVER['SCRIPT_NAME']) !== 'verify_email.php'): ?>
<div class="verify-banner" role="status"><div class="wrap"><?= icon('triangle-alert') ?><span>Your email is not verified yet, so you cannot send inquiries or messages. <a href="<?= url('verify_email.php') ?>">Verify it now</a></span></div></div>
<?php endif; ?>
<main id="main" class="wrap main" tabindex="-1">
<?php foreach (flash() as [$t, $m]): ?>
  <div class="flash flash-<?= e($t) ?>" role="<?= $t === 'error' ? 'alert' : 'status' ?>"><?= e($m) ?></div>
<?php endforeach; ?>
