<?php
// Extra protection for the two most sensitive profile actions: changing the sign-in email and changing the password.
// Used by profile.php (all three roles: adopter, shelter staff, administrator) and reset_password.php.
//
//  * Re-entering the current password is rate limited (5 wrong tries per 15 minutes per account, 15 per IP), so a stolen
//    session cannot be used to guess the password.
//  * Email change: password -> a code sent to the NEW address (proves you own it) AND, when the current address is
//    verified, a code sent to the CURRENT address (proves the owner approves). Nothing changes until both are entered
//    within 10 minutes. The new address is then already verified, other devices are signed out, and the old address is told.
//  * Password change: current password + (when the email is verified) a code emailed to it. A notice is emailed afterwards,
//    other devices are signed out, and all unused codes and any pending email change are cancelled.

const PENDING_EMAIL_MINUTES = 10;

/** Check the current password for a sensitive action. @return string 'ok' | 'bad' | 'locked' */
function reauth(array $u, string $password): string {
    $b = 'reauth:' . (int)$u['user_id']; $bi = 'reauth:ip:' . client_ip();
    if (rate_blocked($b, 5, 900) || rate_blocked($bi, 15, 900)) return 'locked';
    if ($password !== '' && password_verify($password, $u['password_hash'])) { rate_clear($b); return 'ok'; }
    rate_hit($b); rate_hit($bi);
    return 'bad';
}
function reauth_error(string $r, string $what = 'make this change'): ?string {
    if ($r === 'locked') return 'Too many incorrect passwords. Please wait 15 minutes before trying again.';
    if ($r === 'bad') return 'Your current password is incorrect, so we did not ' . $what . '.';
    return null;
}

/** "ana.cruz@gmail.com" -> "a***@gmail.com" (used in emails and on screen so a code request does not reveal a whole address) */
function mask_email(string $email): string {
    [$local, $domain] = array_pad(explode('@', $email, 2), 2, '');
    return ($local === '' ? '' : substr($local, 0, 1)) . '***@' . $domain;
}

/** Very common or personal passwords are refused even when they satisfy the length / letter / number rule. */
function password_context_error(string $pw, array $u): ?string {
    $p = strtolower($pw);
    foreach (['password', 'pawsadopt', 'qwerty', 'asdfgh', 'letmein', 'iloveyou', 'welcome', 'admin123', 'abc123', '12345678', '123456789', '11111111', '00000000', 'dragon', 'monkey'] as $bad)
        if (strpos($p, $bad) !== false) return 'That password is too easy to guess. Please choose something less common.';
    $parts = [strtolower((string)($u['first_name'] ?? '')), strtolower((string)($u['last_name'] ?? '')), strtolower(explode('@', (string)($u['email'] ?? ''))[0])];
    foreach ($parts as $x) { $x = preg_replace('/[^a-z0-9]/', '', $x); if (strlen($x) >= 4 && strpos($p, $x) !== false) return 'Your password should not contain your name or email.'; }
    return null;
}

/** Email that tells the owner about a security change. Only goes to a verified address (an unverified one may not be theirs). */
function security_notice(array $u, string $subject, string $what, ?string $to = null): void {
    $to = $to ?: $u['email'];
    send_mail_later($to, $subject, mail_layout($subject,
        '<p>Hi ' . e($u['first_name']) . ',</p><p>' . $what . '</p>'
        . '<p style="font-size:13px;color:#6b7690">When: ' . e(date('M j, Y g:i A')) . ' (Philippine time) &middot; From IP address: ' . e(client_ip()) . '</p>'
        . '<p><b>Was this not you?</b> Reset your password right away with &ldquo;Forgot your password?&rdquo; on the log-in page, then contact us at ' . e(SITE_CONTACT_EMAIL) . '.</p>',
        user_sender($u, 'Your PawsAdopt account')));
}

/** The pending email change of this user, or null when there is none or it expired. */
function pending_email_change(array $u): ?array {
    if (empty($u['pending_email']) || empty($u['pending_email_at'])) return null;
    if (strtotime($u['pending_email_at']) < time() - PENDING_EMAIL_MINUTES * 60) return null;
    return ['new' => $u['pending_email'], 'needs_old' => email_verified($u)];
}
function pending_email_cancel(int $uid): void {
    q('UPDATE users SET pending_email = NULL, pending_email_at = NULL WHERE user_id = ?', [$uid]);
    q("DELETE FROM password_resets WHERE user_id = ? AND purpose IN ('email_old','email_new')", [$uid]);
}
/** Send the code(s) for a pending change. Returns false when rate limited. */
function pending_email_send_codes(array $u, string $newEmail): bool {
    $masked = mask_email($newEmail);
    if (!otp_issue($u, 'email_new', 'Confirm your new PawsAdopt email', 'Use this code to confirm that this address is yours and can be used for your PawsAdopt account.', 3, $newEmail)) return false;
    if (email_verified($u) && !otp_issue($u, 'email_old', 'Approve your PawsAdopt email change', 'Someone (hopefully you) asked to change the email on your PawsAdopt account to ' . $masked . '. Use this code only if it was you.', 3)) return false;
    return true;
}
