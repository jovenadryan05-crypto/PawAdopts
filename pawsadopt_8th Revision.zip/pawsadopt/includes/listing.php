<?php
// Listing quality checks for staff: photo count and possible duplicates.
function pet_photo_count(int $petId): int { return (int)q('SELECT COUNT(*) FROM pet_photos WHERE pet_id = ?', [$petId])->fetchColumn(); }

/** Warnings (plain text) about one listing: same name and species already listed, or the same photo file used elsewhere. */
function pet_duplicates(int $petId): array {
    $p = q('SELECT pet_id, shelter_id, pet_name, species FROM pets WHERE pet_id = ?', [$petId])->fetch();
    if (!$p) return [];
    $out = [];
    foreach (q("SELECT pet_id, pet_name, status FROM pets WHERE shelter_id = ? AND pet_id <> ? AND LOWER(pet_name) = LOWER(?) AND LOWER(species) = LOWER(?) AND status IN ('draft','available','pending')",
               [$p['shelter_id'], $petId, $p['pet_name'], $p['species']])->fetchAll() as $d)
        $out[] = 'You already have a ' . strtolower($p['species']) . ' named "' . $d['pet_name'] . '" (' . $d['status'] . '). Is this a duplicate listing?';
    foreach (q("SELECT DISTINCT p.pet_name, p.shelter_id FROM pet_photos a JOIN pet_photos b ON b.content_hash = a.content_hash AND b.pet_id <> a.pet_id
                JOIN pets p ON p.pet_id = b.pet_id WHERE a.pet_id = ? AND a.content_hash IS NOT NULL AND p.status <> 'removed'", [$petId])->fetchAll() as $d)
        $out[] = (int)$d['shelter_id'] === (int)$p['shelter_id']
            ? 'The same photo is already used on "' . $d['pet_name'] . '". Use a photo of this animal.'
            : 'One of these photos also appears on another shelter\'s listing. Please use your own photos.';
    return array_values(array_unique($out));
}

/** Short plain-text preview of a story for list pages (cut at a word boundary, newlines flattened). The full text is on story.php. */
function story_excerpt(string $text, int $max = 180): string {
    $t = trim(preg_replace('/\s+/u', ' ', $text));
    if (str_len($t) <= $max) return $t;
    $cut = cut_text($t, $max); $sp = strrpos($cut, ' ');
    return rtrim($sp !== false && $sp > $max * 0.6 ? substr($cut, 0, $sp) : $cut, " ,.;:-") . '...';
}
