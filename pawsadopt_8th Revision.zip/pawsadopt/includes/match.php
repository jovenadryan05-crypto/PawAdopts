<?php
// Compatibility match (pet vs. the adopter's profile) and the home-readiness checklist.
// Everything here is explainable: each point of the score comes with a plain-language reason.

function readiness_options(): array {
    return [
        'landlord' => ['own_home' => 'I own my home', 'yes_written' => 'Yes, my landlord allows pets in writing', 'yes_verbal' => 'Yes, my landlord said it is fine (verbal)',
                       'not_yet' => 'I have not asked my landlord yet', 'no' => 'No, pets are not allowed where I live'],
        'budget'   => ['under_1000' => 'Under P1,000 a month', '1000_3000' => 'P1,000 to P3,000 a month', '3000_5000' => 'P3,000 to P5,000 a month', 'over_5000' => 'Over P5,000 a month'],
        'caregiver' => ['me' => 'Mostly me', 'family' => 'Another adult in my family', 'shared' => 'Shared by everyone at home', 'someone_else' => 'A helper or someone outside the home'],
    ];
}
function readiness_labels(): array { return ['landlord' => 'Landlord permission', 'budget' => 'Monthly budget for the pet', 'caregiver' => 'Who will care for the pet']; }

function get_readiness(int $uid): ?array {
    $r = q('SELECT landlord_permission, monthly_budget, caregiver FROM adopter_readiness WHERE user_id = ?', [$uid])->fetch();
    return $r ? ['landlord' => $r['landlord_permission'], 'budget' => $r['monthly_budget'], 'caregiver' => $r['caregiver']] : null;
}
/** Validate and save the checklist. Returns an error message or null. */
function save_readiness(int $uid, array $in): ?string {
    $o = readiness_options();
    $l = $in['landlord'] ?? ''; $b = $in['budget'] ?? ''; $c = $in['caregiver'] ?? '';
    if (!isset($o['landlord'][$l]) || !isset($o['budget'][$b]) || !isset($o['caregiver'][$c])) return 'Please answer all three questions.';
    if (empty($in['confirm'])) return 'Please confirm that your answers are honest and up to date.';
    q('INSERT INTO adopter_readiness (user_id, landlord_permission, monthly_budget, caregiver) VALUES (?,?,?,?)
       ON DUPLICATE KEY UPDATE landlord_permission = VALUES(landlord_permission), monthly_budget = VALUES(monthly_budget), caregiver = VALUES(caregiver)', [$uid, $l, $b, $c]);
    return null;
}
/** Structured, escaped rows for shelters (and emails): label => answer text. */
function readiness_rows(?string $json): array {
    $d = $json ? json_decode($json, true) : null; if (!is_array($d)) return [];
    $o = readiness_options(); $lab = readiness_labels(); $rows = [];
    foreach (['landlord', 'budget', 'caregiver'] as $k) if (!empty($d[$k]) && isset($o[$k][$d[$k]])) $rows[$lab[$k]] = $o[$k][$d[$k]];
    return $rows;
}
/** Flag answers a shelter will want to look at. */
function readiness_flags(?string $json): array {
    $d = $json ? json_decode($json, true) : null; $f = [];
    if (!is_array($d)) return $f;
    if (in_array($d['landlord'] ?? '', ['not_yet', 'no'], true)) $f[] = 'No landlord permission yet';
    if (($d['budget'] ?? '') === 'under_1000') $f[] = 'Low monthly budget';
    if (($d['caregiver'] ?? '') === 'someone_else') $f[] = 'Care would be done by someone outside the home';
    return $f;
}

/**
 * Compatibility between one pet and one adopter profile.
 * @return array|null null when the adopter shared nothing we can compare;
 *   otherwise ['score' => 0-100, 'good' => bool, 'reasons' => [...], 'cautions' => [...]]
 */
function pet_match(array $pet, array $a): ?array {
    $name = $pet['pet_name']; $housing = $a['housing_type'] ?? ''; $exp = $a['pet_experience'] ?? ''; $others = trim((string)($a['other_pets'] ?? ''));
    $got = 0.0; $max = 0.0; $reasons = []; $cautions = []; $criteria = 0;
    $home = ['house_owned' => 'a house you own', 'house_rented' => 'a rented house', 'apartment' => 'an apartment', 'condo' => 'a condo'];

    // 1. Space (30): home type against size, energy and yard needs
    if (isset($home[$housing])) {
        $small = ($pet['size'] ?? '') === 'small'; $large = ($pet['size'] ?? '') === 'large'; $yard = $pet['needs_yard'] ?? 'unknown'; $en = $pet['energy_level'] ?? '';
        $compact = in_array($housing, ['apartment', 'condo'], true);
        if ($compact) {
            $bad = $yard === 'yes' || $large || $en === 'high';
            $great = ($small || ($pet['size'] ?? '') === 'medium') && $yard !== 'yes' && $en !== 'high' && ($pet['size'] ?? '') !== '';
            $unknownAll = ($pet['size'] ?? '') === '' && $yard === 'unknown' && $en === '';
            if (!$unknownAll) {
                $criteria++; $max += 30;
                if ($great) { $got += 30; $reasons[] = 'You live in ' . $home[$housing] . ', and ' . $name . ' is ' . (($pet['size'] ?? '') === 'small' ? 'small' : 'a manageable size') . ' and apartment-friendly.'; }
                elseif ($bad) {
                    if ($yard === 'yes') $cautions[] = $name . ' needs a yard, and ' . $home[$housing] . ' usually does not have one.';
                    elseif ($large) $cautions[] = $name . ' is a large pet; check that your building allows and has room for one.';
                    else $cautions[] = $name . ' has high energy and needs lots of exercise, which is harder in ' . $home[$housing] . '.';
                } else { $got += 18; }
            }
        } else {
            $criteria++; $max += 30;
            if ($yard === 'yes' && $housing === 'house_owned') { $got += 30; $reasons[] = 'You own your house, so there is space for ' . $name . "'s yard needs."; }
            elseif ($yard === 'yes' && $housing === 'house_rented') { $got += 18; $cautions[] = $name . ' needs a yard; confirm with your landlord that you can use one.'; }
            else { $got += 30; $reasons[] = 'Your ' . ($housing === 'house_owned' ? 'own house' : 'house') . ' gives ' . $name . ' plenty of room.'; }
        }
    }
    // 2. Other pets (25)
    $gwp = $pet['good_with_pets'] ?? 'unknown';
    if ($gwp !== 'unknown' && ($others !== '' || !empty($a['housing_type']) || !empty($a['pet_experience']))) {
        $hasPets = $others !== '' && !preg_match('/^(none|no|n\/a|wala|0)\b/i', $others);
        $criteria++; $max += 25;
        if ($hasPets && $gwp === 'yes') { $got += 25; $reasons[] = 'You have other pets at home, and ' . $name . ' gets along with other animals.'; }
        elseif ($hasPets && $gwp === 'no') $cautions[] = $name . ' does better as the only pet, and you have other pets at home.';
        elseif (!$hasPets && $gwp === 'no') { $got += 25; $reasons[] = 'You have no other pets, which suits ' . $name . ', who prefers to be the only one.'; }
        else $got += 25;
    }
    // 3. Experience (25)
    $rank = ['first_time' => 1, 'some' => 2, 'experienced' => 3]; $need = $pet['experience_needed'] ?? '';
    if (isset($rank[$exp]) && isset($rank[$need])) {
        $criteria++; $max += 25;
        if ($rank[$exp] >= $rank[$need]) { $got += 25; $reasons[] = $need === 'first_time' ? $name . ' is a great fit for ' . ($exp === 'first_time' ? 'first-time owners like you.' : 'your experience level.') : 'Your pet experience matches what ' . $name . ' needs.'; }
        elseif ($rank[$need] - $rank[$exp] === 1) { $got += 10; $cautions[] = $name . ' does best with ' . ($need === 'experienced' ? 'an experienced owner' : 'some pet experience') . '; ask the shelter for tips.'; }
        else $cautions[] = $name . ' needs an experienced owner, and you are new to pets.';
    }
    // 4. Energy for beginners (20): a first-time owner with a high-energy pet
    if ($exp === 'first_time' && ($pet['energy_level'] ?? '') !== '') {
        $criteria++; $max += 20;
        if ($pet['energy_level'] === 'high') $cautions[] = $name . ' has high energy, which can be a lot for a first-time owner.';
        else { $got += 20; $reasons[] = $name . ' has ' . $pet['energy_level'] . ' energy, which is easier for a first-time owner.'; }
    }
    if ($criteria === 0 || $max <= 0) return null;
    $score = (int)round($got / $max * 100);
    return ['score' => $score, 'good' => $score >= 75 && $criteria >= 2 && !$cautions, 'reasons' => $reasons, 'cautions' => $cautions, 'criteria' => $criteria];
}
/** Small badge for cards and the pet page. */
function match_badge(?array $m): string {
    if (!$m) return '';
    if ($m['good']) return '<span class="match good">' . icon('check') . ' Good match for you &middot; ' . (int)$m['score'] . '%</span>';
    if ($m['score'] >= 50) return '<span class="match ok">' . (int)$m['score'] . '% match</span>';
    return '<span class="match low">' . (int)$m['score'] . '% match</span>';
}
/** The full explanation shown on the pet page. */
function match_panel(?array $m, bool $loggedAdopter): string {
    if (!$loggedAdopter) return '';
    if (!$m) return '<div class="match-panel"><h3>Is this a good match?</h3><p class="muted">Add your home type, other pets and pet experience in <a href="' . e(url('profile.php')) . '">your profile</a> and we will explain how well this pet fits you.</p></div>';
    $h = '<div class="match-panel ' . ($m['good'] ? 'good' : '') . '"><h3>' . ($m['good'] ? 'Good match for you' : 'Your compatibility') . ' <span class="match-score">' . (int)$m['score'] . '%</span></h3>';
    if ($m['reasons']) { $h .= '<ul class="reasons">'; foreach ($m['reasons'] as $r) $h .= '<li class="yes">' . e($r) . '</li>'; $h .= '</ul>'; }
    if ($m['cautions']) { $h .= '<p class="small"><strong>Worth thinking about</strong></p><ul class="reasons">'; foreach ($m['cautions'] as $r) $h .= '<li class="warn">' . e($r) . '</li>'; $h .= '</ul>'; }
    return $h . '<p class="hint">Based only on the details in your profile and the shelter\'s description. It is a guide, not a decision; the shelter makes the final call.</p></div>';
}
