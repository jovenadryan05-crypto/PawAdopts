<?php
if (!function_exists('send_mail')) {
    /**
     * Send an HTML email through SMTP (PHPMailer). Returns true/false and never throws,
     * so a mail problem can never break the page that triggered it.
     * If MAIL_HOST is empty (development), the email is written to logs/mail.log instead of being sent.
     */
    function send_mail(string $to, string $subject, string $html): bool {
        if (MAIL_HOST === '') {
            @file_put_contents(__DIR__ . '/../logs/mail.log',
                '[' . date('Y-m-d H:i:s') . "] TO: $to | SUBJECT: $subject\n" . trim(strip_tags($html)) . "\n----\n", FILE_APPEND);
            return true;
        }
        $base = __DIR__ . '/PHPMailer/src/';
        if (!is_file($base . 'PHPMailer.php')) { error_log('Mail error: PHPMailer files are missing in includes/PHPMailer/src/'); return false; }
        require_once $base . 'PHPMailer.php';
        require_once $base . 'SMTP.php';
        require_once $base . 'Exception.php';
        $m = new PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $m->isSMTP();
            $m->Host = MAIL_HOST; $m->Port = (int)MAIL_PORT; $m->Timeout = 10; $m->CharSet = 'UTF-8';
            $m->getSMTPInstance()->Timelimit = 12;   // PHPMailer's default is 300s: a mail server that never answers must fail fast
            $m->SMTPAuth = true; $m->Username = MAIL_USER; $m->Password = MAIL_PASS;
            $m->SMTPSecure = ((int)MAIL_PORT === 465) ? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS : PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $m->setFrom(MAIL_FROM ?: MAIL_USER, 'PawsAdopt');
            $m->addAddress($to);
            $m->isHTML(true); $m->Subject = $subject; $m->Body = $html; $m->AltBody = strip_tags($html);
            // profile photos referenced as cid:imgXXXX (see mail_embed) travel inside the email, so they show without internet access to this site
            if (preg_match_all('/cid:(img[a-f0-9]{12})/', $html, $mm)) foreach (array_unique($mm[1]) as $cid) {
                $file = $GLOBALS['mail_cids'][$cid] ?? null;
                if ($file && is_file($file)) $m->addEmbeddedImage($file, $cid, basename($file), 'base64', (new finfo(FILEINFO_MIME_TYPE))->file($file) ?: 'image/jpeg');
            }
            $m->send();
            return true;
        } catch (Throwable $t) {
            error_log('Mail error: ' . $t->getMessage() . ' | ' . $m->ErrorInfo);
            return false;
        }
    }
}
