<?php
// Public transparency numbers for shelters (shown on shelter.php and shelters.php).
// "Adoptions" are counted from the 'adopted' timeline event, so one adoption is counted once.

/** @return array [shelter_id => stats] for the given shelter ids (or all approved, active shelters when null) */
function shelter_stats(?array $ids = null): array {
    $where = "s.verification_status = 'approved' AND s.account_status = 'active'"; $args = [];
    if ($ids !== null) { if (!$ids) return []; $where .= ' AND s.shelter_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')'; $args = array_values($ids); }
    $rows = q("SELECT s.shelter_id,
        (SELECT COUNT(*) FROM pets p WHERE p.shelter_id = s.shelter_id AND p.status = 'available') AS waiting,
        (SELECT COUNT(*) FROM inquiry_events ev JOIN adoption_inquiries i ON i.inquiry_id = ev.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
           WHERE ev.event_type = 'adopted' AND p.shelter_id = s.shelter_id AND YEAR(ev.created_at) = YEAR(NOW())) AS adopted_year,
        (SELECT COUNT(*) FROM inquiry_events ev JOIN adoption_inquiries i ON i.inquiry_id = ev.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
           WHERE ev.event_type = 'adopted' AND p.shelter_id = s.shelter_id) AS adopted_total,
        (SELECT ROUND(AVG(DATEDIFF(ev.created_at, p.created_at))) FROM inquiry_events ev JOIN adoption_inquiries i ON i.inquiry_id = ev.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
           WHERE ev.event_type = 'adopted' AND p.shelter_id = s.shelter_id) AS avg_days,
        (SELECT ROUND(AVG(TIMESTAMPDIFF(HOUR, i.submitted_at, i.responded_at))) FROM adoption_inquiries i JOIN pets p ON p.pet_id = i.pet_id
           WHERE p.shelter_id = s.shelter_id AND i.responded_at IS NOT NULL) AS avg_response_hours,
        (SELECT COUNT(*) FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
           WHERE p.shelter_id = s.shelter_id AND f.submitted_at IS NOT NULL) AS checkins,
        (SELECT COUNT(*) FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
           WHERE p.shelter_id = s.shelter_id AND f.submitted_at IS NOT NULL AND f.wellbeing IN ('thriving','good')) AS checkins_ok
      FROM shelters s WHERE $where", $args)->fetchAll();
    $out = []; foreach ($rows as $r) $out[(int)$r['shelter_id']] = $r;
    return $out;
}
function days_label($d): string { return $d === null ? 'Not enough data yet' : ((int)$d === 1 ? '1 day' : (int)$d . ' days'); }
function hours_label($h): string {
    if ($h === null) return 'No responses yet';
    $h = (int)$h; if ($h < 1) return 'Under 1 hour'; if ($h < 48) return $h . ' hour' . ($h === 1 ? '' : 's');
    return round($h / 24) . ' days';
}
/** The four public numbers as stat cards. */
function stats_cards(array $st): string {
    $items = [[(int)$st['adopted_year'], 'Adoptions in ' . date('Y')], [(int)$st['waiting'], 'Pets waiting now'], [days_label($st['avg_days']), 'Average days to adoption'], [hours_label($st['avg_response_hours']), 'Average reply to inquiries']];
    $h = '<div class="stats">';
    foreach ($items as [$v, $l]) $h .= '<div class="stat"><b' . (is_string($v) ? ' class="txt"' : '') . '>' . e($v) . '</b><span>' . e($l) . '</span></div>';
    return $h . '</div>';
}
