<?php
// Adoption timeline, drawn from the inquiry_events table. The inquiry's own status column stays simple
// (pending/approved/rejected/withdrawn) because the unique keys uq_active_inquiry and uq_one_approved depend on it.
function timeline_labels(): array {
    return ['submitted' => 'Inquiry sent', 'under_review' => 'Under review by the shelter', 'approved' => 'Approved', 'rejected' => 'Not approved',
            'approval_revoked' => 'Approval withdrawn', 'withdrawn' => 'Inquiry withdrawn', 'meeting_scheduled' => 'Meeting scheduled', 'adopted' => 'Adopted',
            'closed_adopted' => 'Closed: the pet was adopted by another applicant', 'closed_removed' => 'Closed: the listing was removed'];
}
function inquiry_event(int $inquiryId, string $type, ?int $actorId = null, ?string $note = null, ?string $meetingAt = null): void {
    q('INSERT INTO inquiry_events (inquiry_id, event_type, actor_id, note, meeting_at) VALUES (?,?,?,?,?)',
      [$inquiryId, $type, $actorId, $note !== null && $note !== '' ? cut_text($note, 255) : null, $meetingAt]);
}
/** @return array inquiry_id => list of events (oldest first) */
function inquiry_events_for(array $ids): array {
    if (!$ids) return [];
    $rows = q('SELECT * FROM inquiry_events WHERE inquiry_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY event_id', array_values($ids))->fetchAll();
    $out = []; foreach ($rows as $r) $out[$r['inquiry_id']][] = $r;
    return $out;
}
function render_timeline(array $events): string {
    if (!$events) return '';
    $labels = timeline_labels(); $h = '<ol class="timeline">';
    foreach ($events as $ev) {
        $label = e($labels[$ev['event_type']] ?? $ev['event_type']);
        $when = '';
        if ($ev['event_type'] === 'meeting_scheduled' && $ev['meeting_at']) {
            $t = strtotime($ev['meeting_at']);
            $label .= ' for <b>' . e(date('D, M j \a\t g:i A', $t)) . '</b>' . ($t < time() ? ' <span class="muted">(past)</span>' : '');
        }
        $h .= '<li class="tl tl-' . e($ev['event_type']) . '"><span class="tl-dot"></span><div class="tl-body"><strong>' . $label . '</strong>'
            . ' <span class="tl-time">' . e(date('M j, g:i A', strtotime($ev['created_at']))) . '</span>'
            . ($ev['note'] ? '<div class="tl-note">' . nl2br(e($ev['note'])) . '</div>' : '') . '</div></li>';
    }
    return $h . '</ol>';
}
