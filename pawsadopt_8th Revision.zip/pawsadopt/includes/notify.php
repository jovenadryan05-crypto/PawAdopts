<?php
// Email notifications. All sending is deferred (send_mail_later), so a mail problem never loses data or slows a page.
// Every value that came from a user is escaped with e() because these are HTML emails.
// Every email that comes from a person, a shelter or the admin shows their profile photo (embedded in the email itself,
// so it displays even on a local XAMPP install where the site is not reachable from the internet).

/** Register an uploaded photo for embedding. Returns the cid, or null when the file is not a safe upload. */
function mail_embed(?string $rel): ?string {
    if (!$rel || strpos($rel, 'uploads/') !== 0) return null;
    $base = realpath(__DIR__ . '/../uploads'); $f = realpath(__DIR__ . '/../' . $rel);
    if (!$base || !$f || strpos($f, $base) !== 0 || !is_file($f)) return null;
    $cid = 'img' . substr(md5($f), 0, 12);
    $GLOBALS['mail_cids'][$cid] = $f;
    return $cid;
}
/** Round profile picture for an email: the photo if there is one, otherwise coloured initials. */
function mail_avatar(?string $photo, string $name, int $size = 52): string {
    if ($cid = mail_embed($photo))
        return '<img src="cid:' . $cid . '" width="' . $size . '" height="' . $size . '" alt="' . e($name) . '" style="display:block;width:' . $size . 'px;height:' . $size . 'px;border-radius:50%;object-fit:cover;border:2px solid #ffb703">';
    $parts = preg_split('/\s+/', trim($name)); $ini = '';
    foreach (array_slice($parts, 0, 2) as $w) $ini .= function_exists('mb_substr') ? mb_strtoupper(mb_substr($w, 0, 1)) : strtoupper(substr($w, 0, 1));
    return '<div style="width:' . $size . 'px;height:' . $size . 'px;border-radius:50%;background:#ffb703;color:#14213d;font:bold ' . round($size * .38) . 'px/' . $size . 'px Arial,sans-serif;text-align:center">' . e($ini ?: '?') . '</div>';
}
/** "Who this email is from": profile photo, name and role. $s = ['name', 'photo', 'role', optional 'link' (site path)] */
function mail_sender_block(array $s): string {
    $name = '<b style="font-size:16px">' . e($s['name']) . '</b>';
    if (!empty($s['link'])) $name = '<a href="' . e(SITE_URL . '/' . ltrim($s['link'], '/')) . '" style="color:#14213d;text-decoration:none">' . $name . '</a>';
    return '<table role="presentation" style="border-collapse:collapse;margin:0 0 16px"><tr><td style="padding:0 12px 0 0;vertical-align:middle">' . mail_avatar($s['photo'] ?? null, $s['name']) . '</td>'
         . '<td style="vertical-align:middle">' . $name . '<br><span style="font-size:13px;color:#6b7690">' . e($s['role'] ?? '') . '</span></td></tr></table>';
}
function user_sender(array $u, ?string $role = null): array {
    return ['name' => trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')), 'photo' => $u['profile_photo'] ?? null,
            'role' => $role ?? ['adopter' => 'Adopter', 'staff' => 'Shelter staff', 'admin' => 'PawsAdopt administrator'][$u['role'] ?? ''] ?? ''];
}
/** A shelter as the sender: its logo (or the staff member's photo), with the staff member's name when known. $staff = users row or null */
function shelter_sender(array $shelter, ?array $staff = null): array {
    $logo = $shelter['logo'] ?? ($shelter['shelter_logo'] ?? null);
    return ['name' => $shelter['shelter_name'], 'photo' => $logo ?: ($staff['profile_photo'] ?? null),
            'role' => 'Shelter' . ($staff ? ' · ' . trim($staff['first_name'] . ' ' . ($staff['last_name'] ?? '')) : ''), 'link' => !empty($shelter['shelter_id']) ? 'shelter.php?id=' . (int)$shelter['shelter_id'] : null];
}

function mail_layout(string $heading, string $body, ?array $sender = null): string {
    return '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:auto;color:#14213d;line-height:1.5">'
         . ($sender ? mail_sender_block($sender) : '')
         . '<h2 style="margin:0 0 14px">' . e($heading) . '</h2>' . $body
         . '<hr style="border:0;border-top:1px solid #dde3ee;margin:22px 0"><p style="font-size:12px;color:#6b7690">Sent by PawsAdopt because of activity on your account or shelter.</p></div>';
}
function mail_button(string $label, string $path): string {
    return '<p><a href="' . e(SITE_URL . '/' . ltrim($path, '/')) . '" style="display:inline-block;background:#14213d;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">' . e($label) . '</a></p>';
}
function mail_quote(string $text): string {
    return '<blockquote style="margin:12px 0;padding:8px 14px;border-left:4px solid #ffb703;background:#fffaf0">' . nl2br(e($text)) . '</blockquote>';
}

/** UC-10 follow-up: tell the shelter about a new inquiry (sent to the shelter's contact email). */
function notify_new_inquiry(array $pet, array $adopter, string $message, ?string $readinessJson = null): void {
    $opt = profile_options();
    $rows = ['Name' => $adopter['first_name'] . ' ' . $adopter['last_name'], 'Mobile' => $adopter['contact_number'], 'Email' => $adopter['email']];
    if (!empty($adopter['city'])) $rows['City'] = $adopter['city'];
    if (!empty($adopter['housing_type'])) $rows['Home'] = $opt['housing'][$adopter['housing_type']] ?? '';
    if (!empty($adopter['other_pets'])) $rows['Other pets'] = $adopter['other_pets'];
    if (!empty($adopter['pet_experience'])) $rows['Experience'] = $opt['experience'][$adopter['pet_experience']] ?? '';
    $t = '<table style="border-collapse:collapse;margin:8px 0">';
    foreach ($rows as $k => $v) $t .= '<tr><td style="padding:3px 14px 3px 0;color:#6b7690">' . e($k) . '</td><td style="padding:3px 0"><b>' . e($v) . '</b></td></tr>';
    $t .= '</table>';
    $ready = '';
    if ($rr = readiness_rows($readinessJson)) {
        $ready = '<p style="margin:14px 0 4px"><b>Home-readiness checklist</b></p><table style="border-collapse:collapse;margin:0 0 8px">';
        foreach ($rr as $k => $v) $ready .= '<tr><td style="padding:3px 14px 3px 0;color:#6b7690">' . e($k) . '</td><td style="padding:3px 0"><b>' . e($v) . '</b></td></tr>';
        $ready .= '</table>';
        if ($fl = readiness_flags($readinessJson)) $ready .= '<p style="color:#8a2217;margin:0 0 8px">Worth a look: ' . e(implode('; ', $fl)) . '.</p>';
    }
    send_mail_later($pet['contact_email'], 'New adoption inquiry for ' . $pet['pet_name'],
        mail_layout('New inquiry for ' . $pet['pet_name'], '<p>An adopter is interested in <b>' . e($pet['pet_name']) . '</b>.</p>' . $t . $ready . '<p>Their message:</p>' . mail_quote($message)
            . '<p>Review and respond from your dashboard.</p>' . mail_button('Open inquiries', 'staff/inquiries.php'), user_sender($adopter, 'Adopter')));
    notify_users(shelter_staff_ids((int)$pet['shelter_id']), 'inquiry', 'New inquiry for ' . $pet['pet_name'], $adopter['first_name'] . ' ' . $adopter['last_name'] . ' is interested.', 'staff/inquiries.php');
}

/** Tell an adopter what the shelter decided. $kind: approved | rejected | revoked | adopted_other */
function notify_adopter_update(array $adopter, string $petName, string $shelterName, string $kind, ?string $note = null, ?array $sender = null): void {
    $lines = [
        'approved'      => ['Good news about ' . $petName, '<b>' . e($shelterName) . '</b> approved your inquiry for <b>' . e($petName) . '</b>. They will reach you on the contact details in your profile.'],
        'rejected'      => ['Update on your inquiry for ' . $petName, '<b>' . e($shelterName) . '</b> is not able to move forward with your inquiry for <b>' . e($petName) . '</b>. Please keep looking; there are many animals waiting.'],
        'revoked'       => ['Update on your inquiry for ' . $petName, '<b>' . e($shelterName) . '</b> withdrew its earlier approval for <b>' . e($petName) . '</b>.'],
        'under_review'  => ['Your inquiry for ' . $petName . ' is being reviewed', '<b>' . e($shelterName) . '</b> has started reviewing your inquiry for <b>' . e($petName) . '</b>.'],
        'meeting'       => ['Meeting scheduled for ' . $petName, '<b>' . e($shelterName) . '</b> scheduled a meeting about <b>' . e($petName) . '</b>.'],
        'story_request' => ['May we share ' . $petName . "'s story?", '<b>' . e($shelterName) . '</b> would like to feature the adoption story of <b>' . e($petName) . '</b> on their Success Stories page. It is only published if you say yes, and you choose whether your name and photo appear.'],
        'adopted_other' => [$petName . ' has been adopted', '<b>' . e($petName) . '</b> was adopted by another applicant, so your inquiry was closed.'],
    ][$kind];
    $body = '<p>Hi ' . e($adopter['first_name']) . ',</p><p>' . $lines[1] . '</p>' . ($note ? '<p>Message from the shelter:</p>' . mail_quote($note) : '') . mail_button('View my inquiries', 'adopter/inquiries.php');
    send_mail_later($adopter['email'], $lines[0], mail_layout($lines[0], $body, $sender ?? ['name' => $shelterName, 'photo' => null, 'role' => 'Shelter']));
    if (!empty($adopter['user_id'])) notify_user((int)$adopter['user_id'], 'inquiry_update', $lines[0], $note ? cut_text(strip_tags($note), 200) : null, 'adopter/inquiries.php');
}

/** Starter text for the inquiry box, built from the adopter's own profile (they can edit or delete it). */
function profile_intro(array $u): string {
    $opt = profile_options(); $parts = [];
    if (!empty($u['housing_type'])) $parts[] = 'I live in a ' . strtolower($opt['housing'][$u['housing_type']] ?? 'home') . (!empty($u['city']) ? ' in ' . $u['city'] : '') . '.';
    elseif (!empty($u['city'])) $parts[] = 'I live in ' . $u['city'] . '.';
    if (!empty($u['other_pets'])) $parts[] = 'Other pets at home: ' . $u['other_pets'] . '.';
    if (!empty($u['pet_experience'])) $parts[] = 'Pet experience: ' . strtolower($opt['experience'][$u['pet_experience']] ?? '') . '.';
    return $parts ? implode(' ', $parts) . "\n\n" : '';
}
