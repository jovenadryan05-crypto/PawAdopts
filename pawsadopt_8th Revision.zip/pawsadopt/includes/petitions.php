<?php
// Reactivation petitions: a suspended shelter asks the administrators to lift the suspension, and the two sides can exchange messages.
// One open petition per shelter (database unique key). The shelter administrator opens and answers it; employees can read it.

const PETITION_MAX_LEN = 1500;

function shelter_suspended(?array $u): bool {
    return $u && $u['role'] === 'staff' && $u['shelter_id'] && $u['verification_status'] === 'approved' && $u['shelter_status'] === 'suspended';
}
function petition_open_for(int $shelterId): ?array {
    return q("SELECT * FROM shelter_petitions WHERE shelter_id = ? AND status = 'open'", [$shelterId])->fetch() ?: null;
}
function petition_latest_for(int $shelterId): ?array {
    return q('SELECT * FROM shelter_petitions WHERE shelter_id = ? ORDER BY petition_id DESC LIMIT 1', [$shelterId])->fetch() ?: null;
}
function petition_messages(int $petitionId): array {
    return q("SELECT m.*, u.first_name, u.last_name, u.profile_photo FROM shelter_petition_messages m LEFT JOIN users u ON u.user_id = m.sender_id WHERE m.petition_id = ? ORDER BY m.message_id", [$petitionId])->fetchAll();
}
function petition_add_message(int $petitionId, ?int $senderId, string $side, string $body): void {
    q('INSERT INTO shelter_petition_messages (petition_id, sender_id, sender_side, body) VALUES (?,?,?,?)', [$petitionId, $senderId, $side, $body]);
}
function petition_open_count(): int { return (int)q("SELECT COUNT(*) FROM shelter_petitions WHERE status = 'open'")->fetchColumn(); }
/** Text check shared by the shelter and the admin side. Returns an error message or null. */
function petition_body_error(string $body): ?string {
    $body = trim($body);
    if (str_len($body) < 10) return 'Please write at least a sentence (10 characters).';
    if (str_len($body) > PETITION_MAX_LEN) return 'Please keep the message under ' . PETITION_MAX_LEN . ' characters.';
    return null;
}
function petition_status_badge(string $status): string {
    return ['open' => '<span class="badge b-pending">Awaiting review</span>', 'approved' => '<span class="badge b-approved">Approved</span>', 'denied' => '<span class="badge b-rejected">Denied</span>'][$status] ?? '';
}
/** Render a message thread (used by both sides). Every value is escaped. */
function petition_thread_html(array $msgs): string {
    if (!$msgs) return '<p class="muted">No messages yet.</p>';
    $o = '<div class="petition-thread">';
    foreach ($msgs as $m) {
        $admin = $m['sender_side'] === 'admin';
       $who = $admin ? 'PawsAdopt administrator' : (trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')) ?: 'Shelter');
        $o .= '<div class="pmsg ' . ($admin ? 'from-admin' : 'from-shelter') . '"><div class="small muted"><b>' . e($who) . '</b> &middot; ' . e(date('M j, g:i A', strtotime($m['created_at']))) . '</div><p>' . nl2br(e($m['body'])) . '</p></div>';
    }
    return $o . '</div>';
}

/** Lift a suspension. Also closes the shelter's open petition as approved and tells the staff (in-app and by email). */
function shelter_reactivate(array $sh, array $admin, ?string $message = null): void {
    $id = (int)$sh['shelter_id'];
    q("UPDATE shelters SET account_status='active', suspension_reason=NULL, suspended_at=NULL WHERE shelter_id=?", [$id]);
    $p = petition_open_for($id);
    if ($p) {
        q("UPDATE shelter_petitions SET status='approved', resolved_by=?, resolved_at=NOW() WHERE petition_id=? AND status='open'", [$admin['user_id'], $p['petition_id']]);
        petition_add_message((int)$p['petition_id'], (int)$admin['user_id'], 'admin', $message !== null && trim($message) !== '' ? trim($message) : 'Your petition was approved and the shelter is active again.');
    }
    audit('shelter_reactivated', 'shelter', $id, $sh['shelter_name'] . ($p ? ' (petition approved)' : ''));
    notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter was reactivated', 'Your listings are visible again.', 'staff/dashboard.php');
    send_mail_later($sh['contact_email'], 'Your shelter is active again on PawsAdopt', mail_layout('Your shelter is active again',
        '<p><b>' . e($sh['shelter_name']) . '</b> has been reactivated. Your listings and announcements are visible again.</p>' . ($message ? '<p>Message from the administrator:</p>' . mail_quote($message) : '') . mail_button('Open your dashboard', 'staff/dashboard.php'), user_sender($admin)));
}
/** Suspend an approved, active shelter. The reason is required and is shown to the shelter, which can then petition to be reactivated. */
function shelter_suspend(array $sh, array $admin, string $reason): void {
    $id = (int)$sh['shelter_id'];
    q("UPDATE shelters SET account_status='suspended', suspension_reason=?, suspended_at=NOW() WHERE shelter_id=?", [$reason, $id]);
    audit('shelter_suspended', 'shelter', $id, $sh['shelter_name'] . ': ' . $reason);
    notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter was suspended', cut_text($reason, 200) . ' You can petition to be reactivated.', 'staff/petition.php');
    send_mail_later($sh['contact_email'], 'Your shelter was suspended on PawsAdopt', mail_layout('Your shelter was suspended',
        '<p><b>' . e($sh['shelter_name']) . '</b> was suspended and its listings are hidden from the public.</p><p><b>Reason:</b></p>' . mail_quote($reason)
        . '<p>If you believe this can be resolved, the shelter administrator can send a petition for reactivation and explain what was fixed.</p>' . mail_button('Send a petition', 'staff/petition.php'), user_sender($admin)));
}
