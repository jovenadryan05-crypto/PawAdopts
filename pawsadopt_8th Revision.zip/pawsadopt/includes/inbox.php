<?php
// In-app notifications (the bell). Email stays for important events; this is the in-site copy.
function cut_text(string $s, int $n): string { return function_exists('mb_substr') ? mb_substr($s, 0, $n) : substr($s, 0, $n); }
function notify_user(int $uid, string $type, string $title, ?string $body = null, ?string $link = null): void {
    q('INSERT INTO notifications (user_id, type, title, body, link) VALUES (?,?,?,?,?)', [$uid, $type, cut_text($title, 120), $body !== null ? cut_text($body, 255) : null, $link]);
    if (random_int(1, 200) === 1) q('DELETE FROM notifications WHERE created_at < NOW() - INTERVAL 90 DAY');   // keep 90 days
}
function notify_users(array $uids, string $type, string $title, ?string $body = null, ?string $link = null): void {
    foreach (array_unique($uids) as $uid) notify_user((int)$uid, $type, $title, $body, $link);
}
function shelter_staff_ids(int $shelterId): array {
    return q("SELECT user_id FROM users WHERE shelter_id = ? AND role = 'staff' AND account_status = 'active'", [$shelterId])->fetchAll(PDO::FETCH_COLUMN);
}
function admin_ids(): array { return q("SELECT user_id FROM users WHERE role = 'admin' AND account_status = 'active'")->fetchAll(PDO::FETCH_COLUMN); }
function notif_count(array $u): int { return (int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$u['user_id']])->fetchColumn(); }
function notif_badge(int $n): string { return '<span class="count" data-notif' . ($n > 0 ? '' : ' hidden') . '>' . $n . '</span>'; }
