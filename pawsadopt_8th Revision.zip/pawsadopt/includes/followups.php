<?php
// Post-adoption check-ins at 1 week, 1 month and 3 months.
// There is no cron job on plain XAMPP, so reminders are created lazily: in-app when the adopter opens the site,
// and by email when they log in (a request that ends in a redirect, which is when deferred emails are safe).

function followup_milestones(): array { return ['1_week' => ['1 week', 7], '1_month' => ['1 month', 30], '3_months' => ['3 months', 90]]; }
function wellbeing_options(): array { return ['thriving' => 'Thriving: happy and settled', 'good' => 'Doing well', 'adjusting' => 'Still adjusting', 'struggling' => 'Struggling: we could use advice']; }

/** Called once when an approved adoption is completed. Safe to call twice (unique key). */
function followups_schedule(int $inquiryId): void {
    foreach (followup_milestones() as $key => [$label, $days])
        q('INSERT IGNORE INTO adoption_followups (inquiry_id, milestone, due_at) VALUES (?,?, NOW() + INTERVAL ? DAY)', [$inquiryId, $key, $days]);
}
/** Check-ins that are due now and not answered yet, for one adopter. */
function followups_due(int $adopterId): array {
    return q('SELECT f.*, p.pet_name, p.pet_id, s.shelter_name FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id
              JOIN pets p ON p.pet_id = i.pet_id JOIN shelters s ON s.shelter_id = p.shelter_id
              WHERE i.adopter_id = ? AND f.submitted_at IS NULL AND f.due_at <= NOW() ORDER BY f.due_at', [$adopterId])->fetchAll();
}
function followups_due_count(int $adopterId): int {
    return (int)q('SELECT COUNT(*) FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id WHERE i.adopter_id = ? AND f.submitted_at IS NULL AND f.due_at <= NOW()', [$adopterId])->fetchColumn();
}
/**
 * Create the in-app reminder (and, when $email is true, the email) for due check-ins. Each is done once.
 * $email = true only from a request that ends in redirect() (login).
 */
function followups_process(array $adopter, bool $email = false): void {
    $due = q('SELECT f.followup_id, f.milestone, f.notified_at, f.emailed_at, p.pet_name, s.shelter_id, s.shelter_name, s.logo
              FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id JOIN shelters s ON s.shelter_id = p.shelter_id
              WHERE i.adopter_id = ? AND f.submitted_at IS NULL AND f.due_at <= NOW() AND (f.notified_at IS NULL OR f.emailed_at IS NULL)', [$adopter['user_id']])->fetchAll();
    $ms = followup_milestones();
    foreach ($due as $d) {
        $label = $ms[$d['milestone']][0];
        if (!$d['notified_at']) {
            notify_user((int)$adopter['user_id'], 'checkin', 'How is ' . $d['pet_name'] . ' doing? (' . $label . ' check-in)', 'A short check-in, with an optional photo.', 'adopter/checkins.php');
            q('UPDATE adoption_followups SET notified_at = NOW() WHERE followup_id = ?', [$d['followup_id']]);
        }
        if ($email && !$d['emailed_at']) {
            $subj = 'How is ' . $d['pet_name'] . ' settling in? (' . $label . ' check-in)';
            send_mail_later($adopter['email'], $subj, mail_layout($subj,
                '<p>Hi ' . e($adopter['first_name']) . ',</p><p>It has been about <b>' . e($label) . '</b> since <b>' . e($d['pet_name']) . '</b> came home. <b>' . e($d['shelter_name']) . '</b> would love to know how things are going. It takes a minute, and a photo is optional.</p>'
                . mail_button('Send my check-in', 'adopter/checkins.php'), shelter_sender($d)));
            q('UPDATE adoption_followups SET emailed_at = NOW() WHERE followup_id = ?', [$d['followup_id']]);
        }
    }
}
/** Public "Where are they now?" updates: only check-ins the adopter chose to share. */
function public_checkins(int $limit = 12, ?int $shelterId = null): array {
    return q("SELECT f.*, p.pet_name, p.species, s.shelter_id, s.shelter_name, a.first_name,
                (SELECT photo_url FROM pet_photos WHERE pet_id=p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS pet_photo
              FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
              JOIN shelters s ON s.shelter_id = p.shelter_id JOIN users a ON a.user_id = i.adopter_id
              WHERE f.submitted_at IS NOT NULL AND f.share_ok = 1 AND a.account_status = 'active' AND s.verification_status = 'approved' AND s.account_status = 'active'"
              . ($shelterId ? ' AND s.shelter_id = ' . (int)$shelterId : '') . ' ORDER BY f.submitted_at DESC LIMIT ' . (int)$limit)->fetchAll();
}

// ---- "No response" flag: all three check-ins went unanswered -> suggest a welfare call or visit ----
// An adoption is flagged when its 1-week, 1-month and 3-month check-ins are ALL unanswered and the last one (3 months) is at least
// NO_RESPONSE_GRACE_DAYS past due, so an adopter is not flagged the minute the final check-in opens. It clears when the adopter
// answers, or when the shelter logs a welfare check (call, visit or message) for it.
defined('NO_RESPONSE_GRACE_DAYS') || define('NO_RESPONSE_GRACE_DAYS', 7);

function welfare_methods(): array { return ['call' => 'Phone call', 'visit' => 'Welfare visit', 'message' => 'Message sent']; }
function welfare_outcomes(): array { return ['ok' => 'Reached them: pet is doing well', 'needs_help' => 'Reached them: pet needs help', 'unreachable' => 'Could not reach them', 'returned' => 'Pet was returned to the shelter']; }

/** SQL fragment: inquiries (alias i) whose three check-ins all went unanswered (and the last is past the grace period). */
function no_response_sql(): string {
    return "(SELECT COUNT(*) FROM adoption_followups f WHERE f.inquiry_id = i.inquiry_id) = 3
        AND NOT EXISTS (SELECT 1 FROM adoption_followups f WHERE f.inquiry_id = i.inquiry_id AND f.submitted_at IS NOT NULL)
        AND NOT EXISTS (SELECT 1 FROM adoption_followups f WHERE f.inquiry_id = i.inquiry_id AND f.due_at > NOW() - INTERVAL " . (int)NO_RESPONSE_GRACE_DAYS . " DAY)";
}
/** Adoptions of this shelter that need a welfare call or visit (flagged and no welfare check logged yet). */
function followups_no_response(int $shelterId): array {
    return q("SELECT i.inquiry_id, i.no_response_flagged_at, p.pet_name, p.species, a.first_name, a.last_name, a.email, a.contact_number, a.city,
                (SELECT MIN(ev.created_at) FROM inquiry_events ev WHERE ev.inquiry_id = i.inquiry_id AND ev.event_type = 'adopted') AS adopted_at
              FROM adoption_inquiries i JOIN pets p ON p.pet_id = i.pet_id JOIN users a ON a.user_id = i.adopter_id
              WHERE p.shelter_id = ? AND " . no_response_sql() . "
                AND NOT EXISTS (SELECT 1 FROM welfare_checks w WHERE w.inquiry_id = i.inquiry_id)
              ORDER BY adopted_at", [$shelterId])->fetchAll();
}
function followups_no_response_count(int $shelterId): int { return count(followups_no_response($shelterId)); }
/** Notify the shelter's staff once per adoption when it becomes flagged. Cheap; call it where staff land (dashboard, welfare page). */
function followups_flag_no_response(int $shelterId): void {
    $new = q("SELECT i.inquiry_id, p.pet_name FROM adoption_inquiries i JOIN pets p ON p.pet_id = i.pet_id
              WHERE p.shelter_id = ? AND i.no_response_flagged_at IS NULL AND " . no_response_sql(), [$shelterId])->fetchAll();
    foreach ($new as $n) {
        if (q('UPDATE adoption_inquiries SET no_response_flagged_at = NOW() WHERE inquiry_id = ? AND no_response_flagged_at IS NULL', [$n['inquiry_id']])->rowCount() === 1)
            notify_users(shelter_staff_ids($shelterId), 'welfare', 'No response about ' . $n['pet_name'], 'All three check-ins went unanswered. Consider a welfare call or visit.', 'staff/followups.php?s=noresponse');
    }
}
function welfare_checks_for(int $inquiryId): array {
    return q('SELECT w.*, u.first_name, u.last_name FROM welfare_checks w LEFT JOIN users u ON u.user_id = w.staff_id WHERE w.inquiry_id = ? ORDER BY w.check_id DESC', [$inquiryId])->fetchAll();
}
