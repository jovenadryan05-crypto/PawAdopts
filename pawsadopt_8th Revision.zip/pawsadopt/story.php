<?php
require __DIR__ . '/includes/bootstrap.php';
// Read one success story in full (story.php?id=N), or one "Where are they now?" adopter update (story.php?update=N).
// Same public rules as the list: only published stories with the adopter's consent, from approved and active shelters.
// The adopter's name and photo appear only with "full" consent.
$isUpdate = isset($_GET['update']);
$r = null; $photos = [];
if ($isUpdate) {
    $r = q("SELECT f.*, p.pet_id, p.pet_name, p.species, p.breed, s.shelter_id, s.shelter_name, s.city, a.first_name
            FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
            JOIN shelters s ON s.shelter_id = p.shelter_id JOIN users a ON a.user_id = i.adopter_id
            WHERE f.followup_id = ? AND f.submitted_at IS NOT NULL AND f.share_ok = 1 AND a.account_status = 'active' AND s.verification_status = 'approved' AND s.account_status = 'active'",
           [(int)$_GET['update']])->fetch();
} else {
    $r = q("SELECT st.*, p.pet_id, p.pet_name, p.species, p.breed, sh.shelter_id, sh.shelter_name, sh.city, a.first_name, a.last_name, a.profile_photo
            FROM success_stories st JOIN adoption_inquiries i ON i.inquiry_id = st.inquiry_id JOIN pets p ON p.pet_id = i.pet_id
            JOIN shelters sh ON sh.shelter_id = st.shelter_id JOIN users a ON a.user_id = i.adopter_id
            WHERE st.story_id = ? AND st.status = 'published' AND st.consent IN ('full','anonymous') AND sh.verification_status = 'approved' AND sh.account_status = 'active'",
           [(int)($_GET['id'] ?? 0)])->fetch();
}
if (!$r) {
    http_response_code(404); $title = 'Story not found'; $page = 'stories'; include __DIR__ . '/includes/header.php';
    echo '<div class="empty"><h2>Story not found</h2><p>It may have been removed, or the family chose not to share it. <a href="' . e(url('stories.php')) . '">Back to success stories</a></p></div>';
    include __DIR__ . '/includes/footer.php'; exit;
}
$photos = q('SELECT photo_url FROM pet_photos WHERE pet_id = ? ORDER BY is_primary DESC, photo_id LIMIT 6', [$r['pet_id']])->fetchAll(PDO::FETCH_COLUMN);
$title = $isUpdate ? $r['pet_name'] . ' after adoption' : $r['title']; $page = 'stories';
include __DIR__ . '/includes/header.php';
?>
<p><a href="<?= url('stories.php') ?>">&larr; All success stories</a></p>
<article class="panel story-full">
  <h1><?= e($isUpdate ? $r['pet_name'] . ', ' . followup_milestones()[$r['milestone']][0] . ' after adoption' : $r['title']) ?></h1>
  <p class="muted"><?= e($r['pet_name']) ?> the <?= e(strtolower($r['species'])) ?><?= $r['breed'] ? ' (' . e($r['breed']) . ')' : '' ?> &middot;
    <a href="<?= url('shelter.php?id=' . (int)$r['shelter_id']) ?>"><?= e($r['shelter_name']) ?></a><?= $r['city'] ? ', ' . e($r['city']) : '' ?>
    <?= $isUpdate ? '' : ' &middot; ' . e(fdate($r['created_at'])) ?></p>
  <?php if ($isUpdate && $r['photo']): ?><img class="story-hero" src="<?= url($r['photo']) ?>" alt="<?= e($r['pet_name']) ?> at home">
  <?php elseif ($photos): ?><div class="story-gallery"><?php foreach ($photos as $ph): ?><img src="<?= url($ph) ?>" alt="<?= e($r['pet_name']) ?>" loading="lazy"><?php endforeach; ?></div><?php endif; ?>
  <p class="prose"><?= nl2br(e($isUpdate ? ($r['notes'] ?: 'Settling in well.') : $r['body'])) ?></p>
  <div class="who">
    <?php if ($isUpdate): ?><span class="muted">Update from <b><?= e($r['first_name']) ?></b> &middot; <?= e(explode(':', wellbeing_options()[$r['wellbeing']])[0]) ?></span>
    <?php elseif ($r['consent'] === 'full'): ?><?= avatar($r) ?><span>Adopted by <b><?= e($r['first_name']) ?></b></span>
    <?php else: ?><span class="muted">Adopted by a loving family</span><?php endif; ?>
  </div>
</article>
<p><a class="btn btn-ghost" href="<?= url('pets.php?shelter=' . (int)$r['shelter_id']) ?>">See pets waiting at <?= e($r['shelter_name']) ?></a></p>
<?php include __DIR__ . '/includes/footer.php'; ?>
