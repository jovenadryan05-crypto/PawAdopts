<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Terms and Conditions'; $page = '';
include __DIR__ . '/includes/header.php';
?>
<article class="legal">
  <h1>Terms and Conditions</h1>
  <p class="muted">Version <?= e(TERMS_VERSION) ?>. Please read these together with our <a href="<?= url('privacy.php') ?>">Privacy Notice</a>.</p>

  <h2>1. Acceptance</h2>
  <p>By creating an account or using PawsAdopt you agree to these Terms and to the Privacy Notice. If you do not agree, please do not use the platform.</p>

  <h2>2. What PawsAdopt is</h2>
  <p>PawsAdopt is an online platform that connects adopters with verified animal shelters. We provide listings, inquiries and announcements. We are not a shelter, we do not own or hold any animal, and we are not a party to any adoption. Every adoption decision, screening step and agreement is between the adopter and the shelter.</p>

  <h2>3. Eligibility and accounts</h2>
  <ul>
    <li>You must be at least 18 years old to create an account.</li>
    <li>Give accurate information and keep it up to date, including a working Philippine mobile number and email address.</li>
    <li>Keep your password private. You are responsible for activity under your account. Tell us if you think it was compromised.</li>
    <li>One person, one account. Do not impersonate anyone.</li>
  </ul>

  <h2>4. Adopters</h2>
  <ul>
    <li>Inquiries must be honest and sent in good faith. Do not send inquiries you do not intend to follow up.</li>
    <li>Sending an inquiry shares your name, email, mobile number and the profile details you filled in with that shelter (see the Privacy Notice).</li>
    <li>An approved inquiry is not a guarantee of adoption. Shelters may ask for interviews, home checks, fees and agreements of their own.</li>
  </ul>

  <h2>5. Shelters and shelter staff</h2>
  <ul>
    <li>Shelters must be verified by an administrator before they can list animals. You confirm that the documents you submit are genuine and that you are authorised to act for the shelter.</li>
    <li>Listings must be accurate and about animals genuinely available for adoption. Listings that sell animals for profit are not allowed.</li>
    <li>You may use adopters' personal data only to handle their inquiry and the adoption. You must not sell it, share it for marketing, or keep it longer than needed.</li>
    <li>Success stories may be published only after the adopter has agreed. Do not include an adopter's surname, contact details or address in a story, and respect their choice about name and photo.</li>
    <li>Only the shelter administrator creates accounts for employees and hands over their login details. Do not share your own login with anyone.</li>
  </ul>

  <h2>6. Donations</h2>
  <p>Donation requests are posted by shelters. PawsAdopt does not collect, hold or process money, and does not verify how donations are used. Confirm a request with the shelter before you send any money.</p>

  <h2>7. Acceptable use</h2>
  <p>You must not: post false, misleading, abusive or unlawful content; harass other users; upload files you have no right to share; scrape the site or try to bypass its security; attempt to access other people's accounts or data; use the platform to send spam; or send abusive, threatening or unlawful messages in conversations.</p>

  <h2>8. Content and moderation</h2>
  <p>You keep ownership of what you post (such as photos and descriptions) and give PawsAdopt a limited licence to display it on the platform for as long as it is posted. Administrators may hide or remove listings and posts, reject shelter registrations, and suspend accounts that break these Terms. Administrator actions are recorded in an audit log. Conversations between an adopter and a shelter are private to those two sides: an administrator can read one only after a participant reports it, and that is logged.</p>

  <h2>9. Availability and liability</h2>
  <p>We work to keep the platform available and accurate, but it is provided "as is". We cannot guarantee that listings are current, that a shelter will respond, or that an adoption will succeed. To the extent the law allows, PawsAdopt is not liable for losses arising from adoptions, donations, or dealings between users.</p>

  <h2>10. Ending your account</h2>
  <p>You can delete your account at any time from Profile &rarr; Your data and privacy. We may suspend or end accounts that break these Terms.</p>

  <h2>11. Post-adoption check-ins</h2>
  <p>A check-in is a short welfare update about a pet after it goes home. It exists so that shelters know their animals are safe and so that adopters can ask for advice early. This section applies whenever a shelter marks an adoption that began on PawsAdopt as completed.</p>
  <h3>11.1 How check-ins work</h3>
  <ul>
    <li>Three check-ins are scheduled automatically, about <b>1 week</b>, <b>1 month</b> and <b>3 months</b> after the shelter marks the adoption as completed.</li>
    <li>When one is due we remind you in the notification bell and by email the next time you log in. We do not send check-in reminders for any other purpose, and we do not send marketing email.</li>
    <li>Each check-in asks how the pet is doing. A written note and a photo are optional.</li>
  </ul>
  <h3>11.2 What adopters agree to</h3>
  <ul>
    <li>You agree to receive these reminders and to answer each check-in honestly and in good faith. It is a friendly update, not a test, and you can ask for advice in it.</li>
    <li>Photos must show the pet. Do not upload photos of other people (especially children), documents, or anything unlawful or abusive, and only upload photos you have the right to share.</li>
    <li>Your answers and photo are visible to the shelter you adopted from. They appear on the public Success Stories page and the shelter's public profile <b>only if you tick the box</b> to allow it, and then only with your first name. Leaving the box unticked has no effect on your adoption.</li>
    <li>If you want a shared note or photo taken down, contact us at the address in section 13; deleting your account also removes it from the public pages.</li>
    <li>If you cannot answer a check-in or your circumstances change (for example you can no longer keep the pet), please tell the shelter directly. Check-ins are not an emergency channel: for an urgent animal-welfare problem contact the shelter, a veterinarian or the local authorities.</li>
  </ul>
  <h3>11.3 If check-ins go unanswered</h3>
  <ul>
    <li>Not answering a check-in does not by itself break these Terms or end your account.</li>
    <li>If <b>all three</b> check-ins stay unanswered, PawsAdopt flags the adoption to the shelter. The shelter may then contact you using the phone number and email on your account, usually by a call or message first. The shelter records what it did and the result.</li>
    <li>Any welfare visit is arranged with you and is governed by the adoption agreement between you and the shelter. These Terms do not give a shelter or PawsAdopt any right to enter your home.</li>
  </ul>
  <h3>11.4 What shelters agree to</h3>
  <ul>
    <li>Use check-in answers, photos and welfare-check contact details only to look after the animal's welfare and to support the adopter. Do not use them for marketing, fundraising lists, or to pass on to anyone else.</li>
    <li>Be respectful and proportionate: do not pressure, threaten or repeatedly contact an adopter, and respond helpfully when an adopter reports a problem or asks for advice.</li>
    <li>Publish an adopter's note, photo or name only if the adopter allowed it, and remove it when asked.</li>
    <li>Keep welfare-check notes accurate and factual and keep them no longer than needed. These notes are erased if the adopter deletes their account.</li>
  </ul>
  <h3>11.5 Limits</h3>
  <p>PawsAdopt does not verify check-in answers or photos, does not inspect homes, and does not investigate or decide animal-welfare disputes. A good, missing or poor check-in is not a finding about the adopter, the pet or the shelter. Any decision to follow up, to offer help or to take a pet back is made by the shelter under its own adoption agreement and the law. Reports of animal cruelty or neglect should go to the proper authorities.</p>

  <h2>12. Changes to these Terms</h2>
  <p>When we change these Terms or the Privacy Notice, the version number above changes and you will be asked to review and accept them again before you continue.</p>

  <h2>13. Governing law and contact</h2>
  <p>These Terms are governed by the laws of the Republic of the Philippines. Questions: <a href="mailto:<?= e(SITE_CONTACT_EMAIL) ?>"><?= e(SITE_CONTACT_EMAIL) ?></a>.</p>
</article>
<?php include __DIR__ . '/includes/footer.php'; ?>
