<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/account.php';
csrf_check();
$u = require_role();
$title = 'My profile'; $page = 'profile'; $errors = [];
$opt = profile_options();
$isAdopter = $u['role'] === 'adopter'; $isStaff = $u['role'] === 'staff';
$act = $_POST['action'] ?? '';

// UC-04 Manage profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    if ($act === 'photo') {
        $path = save_upload($_FILES['photo'] ?? [], 'avatars', false, 400);     // cropped to a 400x400 square, EXIF removed
        if ($path) { delete_public_file($u['profile_photo']); q('UPDATE users SET profile_photo=? WHERE user_id=?', [$path, $u['user_id']]); flash('success', 'Profile photo updated.'); }
        elseif (empty($_FILES['photo']['name'])) flash('error', 'Choose an image first.');
        redirect('profile.php');
    } elseif ($act === 'remove_photo') {
        delete_public_file($u['profile_photo']); q('UPDATE users SET profile_photo=NULL WHERE user_id=?', [$u['user_id']]);
        flash('success', 'Profile photo removed.'); redirect('profile.php');
    } elseif ($act === 'password_code') {                // step-up: emailed code before the password can change
        if (!email_verified($u)) flash('error', 'Verify your email address first.');
        elseif (otp_issue($u, 'pw_change', 'Your PawsAdopt password-change code', 'Use this code to confirm the password change you started in your profile.')) flash('success', 'We sent a 6-digit code to ' . mask_email($u['email']) . '. It expires in 10 minutes.');
        else flash('error', 'You asked for several codes recently. Please wait a while and try again.');
        redirect('profile.php#password');
    } elseif ($act === 'password') {
        $needCode = email_verified($u);
        $new = $_POST['password'] ?? '';
        $r = reauth($u, $_POST['current'] ?? '');
        if ($r !== 'ok') $errors[] = reauth_error($r, 'change your password');
        elseif ($err = password_error($new)) $errors[] = $err;
        elseif ($err = password_context_error($new, $u)) $errors[] = $err;
        elseif ($new !== ($_POST['confirm'] ?? '')) $errors[] = 'New passwords do not match.';
        elseif (password_reused((int)$u['user_id'], $new)) $errors[] = PASSWORD_REUSED_MSG;
        elseif ($needCode && ($res = otp_verify((int)$u['user_id'], 'pw_change', $_POST['code'] ?? '', false)) !== 'ok')
            $errors[] = $res === 'bad' ? 'That code is not correct.' : 'There is no active code. Press "Email me a code" first (codes expire after 10 minutes and allow 5 tries).';
        else {
            set_password((int)$u['user_id'], $new);
            otp_clear_all((int)$u['user_id']);                 // no old reset / verification code survives a password change
            pending_email_cancel((int)$u['user_id']);          // and neither does a half-finished email change
            bump_session((int)$u['user_id'], true);            // every other device is signed out
            session_regenerate_id(true);
            if ($needCode) security_notice($u, 'Your PawsAdopt password was changed', 'The password on your PawsAdopt account was just changed. All other devices were signed out.');
            notify_user((int)$u['user_id'], 'security', 'Your password was changed', 'Other devices were signed out.', 'profile.php');
            if ($u['role'] === 'admin') audit('password_changed', 'user', (int)$u['user_id'], 'Own password changed');
            flash('success', 'Password changed. Any other devices were signed out.');
            redirect(home_for($u));
        }
    } elseif ($act === 'email_request') {                  // step 1 of an email change: password, then codes to the new (and current) address
        $new = strtolower(substr(trim($_POST['new_email'] ?? ''), 0, 150));
        $r = reauth($u, $_POST['current_password_for_email'] ?? '');
        if ($r !== 'ok') $errors[] = reauth_error($r, 'start the email change');
        elseif (!filter_var($new, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        elseif ($new === strtolower($u['email'])) $errors[] = 'That is already your email address.';
        elseif (q('SELECT 1 FROM users WHERE email = ? AND user_id <> ?', [$new, $u['user_id']])->fetch()) $errors[] = 'That email address cannot be used. Please try a different one.';
        else {
            q('UPDATE users SET pending_email = ?, pending_email_at = NOW() WHERE user_id = ?', [$new, $u['user_id']]);
            if (pending_email_send_codes($u, $new)) { flash('success', 'We sent a code to ' . mask_email($new) . (email_verified($u) ? ' and another to your current email' : '') . '. Enter them below within 10 minutes.'); }
            else { pending_email_cancel((int)$u['user_id']); flash('error', 'You asked for several codes recently. Please wait a while and try again.'); }
            redirect('profile.php#email');
        }
    } elseif ($act === 'email_resend') {
        $pend = pending_email_change($u);
        if (!$pend) flash('info', 'There is no email change in progress.');
        elseif (pending_email_send_codes($u, $pend['new'])) flash('success', 'New code(s) sent. The earlier ones no longer work.');
        else flash('error', 'You asked for several codes recently. Please wait a while and try again.');
        redirect('profile.php#email');
    } elseif ($act === 'email_cancel') {
        pending_email_cancel((int)$u['user_id']); flash('info', 'Email change cancelled. Your email stays the same.'); redirect('profile.php#email');
    } elseif ($act === 'email_confirm') {                  // step 2: both codes entered -> the change is applied
        $pend = pending_email_change($u);
        if (!$pend) $errors[] = 'That email change expired. Please start again.';
        else {
            $rn = otp_verify((int)$u['user_id'], 'email_new', $_POST['code_new'] ?? '', false);
            $ro = $pend['needs_old'] ? otp_verify((int)$u['user_id'], 'email_old', $_POST['code_old'] ?? '', false) : 'ok';
            if ($rn === 'expired' || $ro === 'expired') $errors[] = 'A code expired or was tried too many times. Press "Send new codes".';
            elseif ($rn !== 'ok') $errors[] = 'The code sent to your new email is not correct.';
            elseif ($ro !== 'ok') $errors[] = 'The code sent to your current email is not correct.';
            elseif (q('SELECT 1 FROM users WHERE email = ? AND user_id <> ?', [$pend['new'], $u['user_id']])->fetch()) { pending_email_cancel((int)$u['user_id']); $errors[] = 'That email address cannot be used. Please try a different one.'; }
            else {
                $old = $u['email']; $wasVerified = email_verified($u);
                q('UPDATE users SET email = ?, email_verified_at = NOW(), pending_email = NULL, pending_email_at = NULL WHERE user_id = ?', [$pend['new'], $u['user_id']]);
                q("DELETE FROM password_resets WHERE user_id = ?", [$u['user_id']]);
                bump_session((int)$u['user_id'], true); session_regenerate_id(true);
                if ($wasVerified) security_notice($u, 'Your PawsAdopt email was changed', 'The email on your PawsAdopt account was changed to <b>' . e(mask_email($pend['new'])) . '</b>. You can no longer sign in with this address.', $old);
                notify_user((int)$u['user_id'], 'security', 'Your email address was changed', 'Other devices were signed out.', 'profile.php');
                if ($u['role'] === 'admin') audit('email_changed', 'user', (int)$u['user_id'], 'Own email changed');
                flash('success', 'Email changed and verified. Any other devices were signed out.');
                redirect('profile.php');
            }
        }
    } elseif ($act === 'export') {                       // right to access / portability
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="pawsadopt-my-data-' . date('Ymd') . '.json"');
        header('Cache-Control: private, no-store');
        echo json_encode(export_user_data($u), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    } elseif ($act === 'delete') {                       // right to erasure
        if ($u['role'] === 'admin') $errors[] = 'Administrator accounts cannot be deleted here.';
        elseif (($r = reauth($u, $_POST['confirm_password'] ?? '')) !== 'ok') $errors[] = reauth_error($r, 'delete the account');
        elseif (empty($_POST['understand'])) $errors[] = 'Please tick the box to confirm you understand.';
        else {
            delete_account($u);
            $_SESSION = []; session_destroy(); session_start();
            flash('success', 'Your account was deleted and your personal details were removed.');
            redirect('login.php');
        }
    } else {
        $phone = ph_mobile($f('contact_number'));
        $housing = $f('housing_type'); $exp = $f('pet_experience');
        $first = clean_name($f('first_name')); $last = clean_name($f('last_name'));
        if ($err = name_error('First name', $first)) $errors[] = $err;
        if ($err = name_error('Last name', $last)) $errors[] = $err;
        if (!$phone) $errors[] = 'Contact number must be a Philippine mobile number: 11 digits starting with 09.';
        if (str_len($f('city')) > 80) $errors[] = 'City must be 80 characters or fewer.';
        if (str_len($f('bio')) > 500) $errors[] = 'Bio must be 500 characters or fewer.';
        if ($isAdopter) {
            if ($housing !== '' && !isset($opt['housing'][$housing])) $errors[] = 'Choose a valid housing type.';
            if ($exp !== '' && !isset($opt['experience'][$exp])) $errors[] = 'Choose a valid experience level.';
            if (str_len($f('other_pets')) > 150) $errors[] = 'Other pets must be 150 characters or fewer.';
        }
        if ($isStaff && str_len($f('position')) > 80) $errors[] = 'Job title must be 80 characters or fewer.';
        if (!$errors) {
            q('UPDATE users SET first_name=?, last_name=?, contact_number=?, city=?, bio=?, housing_type=?, other_pets=?, pet_experience=?, `position`=? WHERE user_id=?',
              [$first, $last, $phone, $f('city') ?: null, $f('bio') ?: null,
               $isAdopter && $housing ? $housing : null, $isAdopter ? ($f('other_pets') ?: null) : null, $isAdopter && $exp ? $exp : null,
               $isStaff ? ($f('position') ?: null) : null, $u['user_id']]);
            flash('success', 'Profile updated.'); redirect('profile.php');
        }
    }
}
$v = fn($k) => e($_POST[$k] ?? ($u[$k] ?? ''));
include __DIR__ . '/includes/header.php';
?>
<div class="profile-head">
  <?= avatar($u, 'lg') ?>
  <div><h1><?= e($u['first_name'] . ' ' . $u['last_name']) ?></h1>
  <p class="muted"><?= e(ucfirst($u['role'])) ?> account &middot; member since <?= fdate($u['created_at']) ?></p></div>
</div>
<?php if ($u['must_change_password']): ?><div class="flash flash-error"><strong>Action required:</strong> you are using a temporary password. Set a new one below before continuing.</div><?php endif; ?>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>

<div class="cols">
  <div>
    <form method="post" class="stack panel"><?= csrf_field() ?><h2>Details</h2>
      <div class="two"><label>First name<input name="first_name" value="<?= $v('first_name') ?>" data-name maxlength="60" pattern="[A-Za-z&#192;-&#255;&#209;&#241;][A-Za-z&#192;-&#255;&#209;&#241;\s'.\-]*" title="Letters only (spaces, hyphens, apostrophes and periods are allowed)" required></label>
      <label>Last name<input name="last_name" value="<?= $v('last_name') ?>" data-name maxlength="60" pattern="[A-Za-z&#192;-&#255;&#209;&#241;][A-Za-z&#192;-&#255;&#209;&#241;\s'.\-]*" title="Letters only (spaces, hyphens, apostrophes and periods are allowed)" required></label></div>
      <p class="field-static"><b>Email</b><br><?= e($u['email']) ?> <?= email_verified($u) ? '<span class="badge b-approved">Verified</span>' : '<span class="badge b-pending">Not verified</span> <a href="' . e(url('verify_email.php')) . '">Verify now</a>' ?>
        <span class="hint">To change it, use <a href="#email">Sign-in email</a> below. It needs your password and a code.</span></p>
      <label>Mobile number<input type="tel" name="contact_number" value="<?= $v('contact_number') ?>" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="09XXXXXXXXX" title="11 digits, starting with 09" data-ph required></label>
      <label>City or municipality (optional)<input name="city" maxlength="80" value="<?= $v('city') ?>"></label>
      <?php if ($isStaff): ?><label>Job title (optional)<input name="position" maxlength="80" value="<?= $v('position') ?>" placeholder="e.g. Adoption coordinator"></label><?php endif; ?>
      <label>About me (optional)<textarea name="bio" rows="3" maxlength="500"><?= $v('bio') ?></textarea></label>
      <?php if ($isAdopter): ?>
        <h3>Your home (helps shelters match you)</h3>
        <p class="hint">Shared with a shelter only when you send it an inquiry. All optional.</p>
        <div class="two">
          <label>Housing<select name="housing_type"><option value="">Prefer not to say</option>
            <?php $h = $_POST['housing_type'] ?? ($u['housing_type'] ?? ''); foreach ($opt['housing'] as $k => $lbl): ?><option value="<?= $k ?>" <?= $h === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select></label>
          <label>Pet experience<select name="pet_experience"><option value="">Prefer not to say</option>
            <?php $x = $_POST['pet_experience'] ?? ($u['pet_experience'] ?? ''); foreach ($opt['experience'] as $k => $lbl): ?><option value="<?= $k ?>" <?= $x === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select></label>
        </div>
        <label>Other pets at home<input name="other_pets" maxlength="150" value="<?= $v('other_pets') ?>" placeholder="e.g. 2 cats, 1 dog, none"></label>
      <?php endif; ?>
      <button class="btn">Save changes</button>
    </form>
  </div>

  <div>
    <div class="panel"><h2>Profile photo</h2>
      <form method="post" enctype="multipart/form-data" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="photo">
        <label>Choose an image (JPG, PNG, WEBP; max 5 MB)<input type="file" name="photo" accept="image/*" data-preview="#avatarPreview" required></label>
        <div id="avatarPreview" class="previews one"></div>
        <p class="hint">It is cropped to a square. Hidden data such as location is removed. Shelters you contact can see it.</p>
        <div class="actions"><button class="btn">Upload photo</button></div>
      </form>
      <?php if ($u['profile_photo']): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="remove_photo"><button class="btn btn-ghost btn-sm" data-confirm="Remove your profile photo?">Remove current photo</button></form>
      <?php endif; ?>
    </div>

    <?php if ($isAdopter): ?><div class="panel"><h2>Adoption readiness</h2><p class="muted">Landlord permission, budget and who cares for the pet. Shelters see your answers with each inquiry.</p>
      <a class="btn btn-ghost btn-sm" href="<?= url('adopter/readiness.php') ?>"><?= get_readiness((int)$u['user_id']) ? 'Review my answers' : 'Complete the checklist' ?></a></div><?php endif; ?>
    <?php $pend = pending_email_change($u); ?>
    <div class="panel" id="email"><h2>Sign-in email</h2>
      <p>Your email is your username and receives security codes. Now: <b><?= e($u['email']) ?></b>.</p>
      <?php if ($pend): ?>
        <p>We are changing it to <b><?= e(mask_email($pend['new'])) ?></b>. Enter the code<?= $pend['needs_old'] ? 's' : '' ?> within 10 minutes. Nothing changes until then.</p>
        <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="email_confirm">
          <label>Code sent to the new address (<?= e(mask_email($pend['new'])) ?>)<input name="code_new" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required></label>
          <?php if ($pend['needs_old']): ?><label>Code sent to your current address (<?= e(mask_email($u['email'])) ?>)<span class="hint">This proves the owner of the account approves the change.</span><input name="code_old" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="off" required></label><?php endif; ?>
          <button class="btn">Confirm email change</button>
        </form>
        <div class="actions"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="email_resend"><button class="btn btn-ghost btn-sm">Send new codes</button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="email_cancel"><button class="btn btn-ghost btn-sm">Cancel the change</button></form></div>
      <?php else: ?>
        <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="email_request">
          <label>New email address<input type="email" name="new_email" maxlength="150" autocomplete="off" required></label>
          <label>Current password<input type="password" name="current_password_for_email" autocomplete="current-password" required></label>
          <p class="hint">We email a code to the new address<?= email_verified($u) ? ' and another to your current one' : '' ?>. After you enter <?= email_verified($u) ? 'both' : 'it' ?>, the new address is verified, and your other devices are signed out.</p>
          <button class="btn">Send codes</button>
        </form>
      <?php endif; ?>
    </div>

    <div class="panel" id="password"><h2>Change password</h2>
      <?php if (email_verified($u)): ?>
      <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="password_code">
        <p class="hint" style="margin:0">Step 1. For your safety we email a 6-digit code to <?= e(mask_email($u['email'])) ?>.</p>
        <button class="btn btn-ghost btn-sm">Email me a code</button>
      </form>
      <?php endif; ?>
      <form method="post" class="stack" data-match="password,confirm"><?= csrf_field() ?><input type="hidden" name="action" value="password">
        <?php if (email_verified($u)): ?><label>6-digit code from your email<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required></label><?php endif; ?>
        <label>Current password<input type="password" name="current" autocomplete="current-password" required></label>
        <label>New password<input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><span class="hint">8+ characters with a letter and a number. Not a common password, not your name or email, and not one you used recently.</span></label>
        <label>Confirm new password<input type="password" name="confirm" minlength="8" maxlength="72" autocomplete="new-password" required></label>
        <button class="btn">Change password</button>
      </form>
    </div>
  </div>
</div>

<div class="panel">
  <h2>Your data and privacy</h2>
  <p class="muted">You accepted the <a href="<?= url('terms.php') ?>">Terms</a> and <a href="<?= url('privacy.php') ?>">Privacy Notice</a> (version <?= e($u['terms_version'] ?? '-') ?>) on <?= fdate($u['consent_at']) ?>. Under the Data Privacy Act you can get a copy of your data or have it erased.</p>
  <form method="post" data-no-loader><?= csrf_field() ?><input type="hidden" name="action" value="export"><button class="btn btn-ghost">Download my data (JSON)</button></form>
  <?php if ($u['role'] !== 'admin'): ?>
  <details class="danger-zone">
    <summary>Delete my account</summary>
    <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="delete">
      <p>This removes your name, email, mobile number, photo and profile details right away and cannot be undone.
        <?= $isAdopter ? 'Your open inquiries are withdrawn and your inquiry messages are erased.' : 'You will also be removed from your shelter; its pets and posts stay.' ?></p>
      <label>Confirm with your password<input type="password" name="confirm_password" required autocomplete="current-password"></label>
      <label class="check"><input type="checkbox" name="understand" value="1" required> I understand this is permanent.</label>
      <button class="btn btn-danger" data-confirm="Permanently delete your account?">Delete my account</button>
    </form>
  </details>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
