<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Reset password'; $error = '';
// UC-03 Reset password, step 1: email a 6-digit one-time code (hashed in the DB, valid 10 minutes). Protected by a CAPTCHA because it sends email.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_switch'])) captcha_new($_POST['captcha_switch'] === 'text' ? 'text' : 'image');
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(substr(trim($_POST['email'] ?? ''), 0, 150)); $ip = client_ip();
    if (!captcha_check($_POST['captcha'] ?? '')) $error = 'The security check was not correct. Please try the new one.';
    else {
        if (filter_var($email, FILTER_VALIDATE_EMAIL) && !rate_blocked("reset:ip:$ip", 8, 3600) && !rate_blocked("reset:email:$email", 3, 3600)) {
            rate_hit("reset:ip:$ip"); rate_hit("reset:email:$email");
            $row = q("SELECT user_id, first_name, last_name, role, profile_photo, email FROM users WHERE email = ? AND account_status = 'active'", [$email])->fetch();
            if ($row) otp_issue($row, 'reset', 'Your PawsAdopt reset code', 'Use this code to reset your PawsAdopt password.');
        }
        // Same response whether or not the email exists, and whether or not we were rate limited
        $_SESSION['reset_email'] = $email;
        flash('info', 'If that email is registered, a 6-digit code is on its way. It expires in 10 minutes.');
        redirect('reset_password.php');
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Forgot your password?</h1>
  <p class="muted">Enter your account email and we will send you a 6-digit code.</p>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required autofocus></label>
    <?= captcha_widget() ?>
    <button class="btn">Send code</button>
    <?= captcha_switch_button() ?>
  </form>
  <p class="muted"><a href="<?= url('login.php') ?>">Back to log in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
