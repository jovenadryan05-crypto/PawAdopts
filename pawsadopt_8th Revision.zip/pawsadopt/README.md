# PawsAdopt: Pet Adoption System (PHP + MySQL + CSS + JS)

Built from the project's UML use case, Level 0 DFD, class diagram and ERD.
Plain PHP 8+ with PDO, MySQL/MariaDB, vanilla CSS and JS. PHPMailer is bundled (includes/PHPMailer).

## Fresh install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\pawsadopt`.
2. Copy `config/config.example.php` to `config/config.php` and edit it (database, BASE_URL, email).
3. Start Apache and MySQL. In phpMyAdmin > Import, choose `database/schema.sql`
   (WARNING: it starts with DROP DATABASE, so only use it on a fresh install).
4. Make sure `extension=gd` is enabled in `php.ini` (it is by default in XAMPP). Photos are re-encoded with GD.
5. Visit http://localhost/pawsadopt
   Default admin: `admin@pawsadopt.local` / `Admin@12345`. You are forced to change it at first login.

## Updating an existing install
1. **Back up first**: phpMyAdmin > pawsadopt > Export.
2. phpMyAdmin > pawsadopt > SQL: run the migration(s) you have not run yet, in order. Never import `schema.sql` on a database you want to keep (it starts with DROP DATABASE).
   - from the original version: `001`, `002`, `003`, `004` (in `database/migrations/`)
   - from batch 1: `002`, `003`, `004`;  from batch 2: `003`, `004`;  from batch 3: only `004_verification_notifications_timeline.sql`
3. Unzip this package over your project folder. `config/config.php` is not in the package, so your settings are kept.
   See `config/config.example.php` for optional settings (APP_DEBUG, SESSION_IDLE, PRIVATE_DIR, ADMIN_2FA).
4. The contact email shown in the Terms and Privacy Notice defaults to your `MAIL_FROM`; to use another address add
   `define('SITE_CONTACT_EMAIL', 'privacy@yourdomain.ph');` to config.php.
5. The legal text changed again, so `TERMS_VERSION` is now `2026-10.3`: everyone accepts it at their next login (intended).
6. **Existing users must verify their email once** (they can still browse). Existing shelters should add their city and province (a hint appears on their dashboard).
7. **Admin:** set a real email in Profile and verify it. From then on every admin sign-in also needs a code emailed to that address.
   Until the admin email is verified, two-step sign-in stays off (so the seeded fake address cannot lock you out).
   If email ever breaks, set `define('ADMIN_2FA', false);` in config.php to sign in with the password only, then fix the email.

## Updating from batch 6 to batch 7
1. **Back up first**, then run `database/migrations/007_batch7.sql` in phpMyAdmin (SQL tab). Fresh installs: `schema.sql` already includes everything.
   The migration **permanently deletes** foster volunteer profiles, offers and rescue cases, and hides announcements that were published together with a rescue case.
2. Unzip over your project folder (`config/config.php` is kept). Deleted files: `board.php`, `foster.php`, `staff/board.php`. If you copy over an old folder, delete them by hand.
3. `TERMS_VERSION` is now `2026-10.5` (Terms section 11 on check-ins is new, and the foster volunteer lines left the Privacy Notice): everyone accepts it once at next login (intended).

## What changed in batch 7
- **Foster and emergency-rescue board removed.** Removed the public board, the foster volunteer profile, the shelter "Rescue board", the "Urgent needs" block on shelter profiles, the nav and dashboard links, the Privacy Notice lines, and every "rescue" wording (landing page, suspension notices). Shelters can still post ordinary announcements and donation requests.
- **Terms and Conditions, new section 11 "Post-adoption check-ins"** (`terms.php`): how the 1-week / 1-month / 3-month check-ins work, what adopters and shelters agree to, what happens when all three go unanswered (call or message first; no right to enter a home), and the limits (PawsAdopt does not verify answers or investigate). The Privacy Notice now also mentions the welfare follow-up and the new security codes. Please have your adviser review the wording before launch.
- **Safer profile security for all three roles (administrator, shelter staff, adopter)** (`profile.php`, `includes/security.php`):
  - *Current password is rate limited* (5 wrong tries per 15 minutes per account, 15 per IP) for changing the email, the password and deleting the account.
  - *Changing the email* is now its own panel. Step 1: new address + current password. Step 2: a code is emailed to the **new** address and, when the current address is verified, a second code to the **current** address; both must be entered within 10 minutes. Only then does the email change; it is marked verified at once, other devices are signed out and the old address gets a notice. An unverified current address (for example the seeded `admin@pawsadopt.local`) cannot receive a code, so only the new address is checked. The email field in *Details* is read-only.
  - *Changing the password* needs the current password **and** a code emailed to the verified address (accounts whose email is not verified, such as employees on a temporary password, only need the current password). Afterwards: other devices signed out, all unused codes and any pending email change cancelled, a notice emailed, an in-app notification created.
  - *Stronger password rule* (sign-up, reset and change): common passwords and passwords that contain your name or email are refused, on top of the existing length / letter / number / no-reuse rules.
  - Password reset now also cancels any pending email change and emails a notice. Administrator email and password changes are written to the audit log.
  - Deleting an account now also erases the adopter's check-in notes and photos.

1. **Back up first**, then run `database/migrations/006_batch6.sql` in phpMyAdmin (SQL tab). Fresh installs: `schema.sql` already includes everything.
2. Unzip over your project folder (`config/config.php` is kept). No config changes are needed. `TERMS_VERSION` is **not** bumped (see "Legal text" below).
3. **Existing shelters have no exact map pin yet.** Until the shelter administrator sets one (Shelter profile > Edit), the public map falls back to a guess from the address and is labelled *Approximate*. The pin is required the next time a shelter's details are saved.
4. Already-suspended shelters have no recorded reason; the administrator can type one the next time (the field is required when suspending). The shelter can still petition without it.

## What changed in batch 6
- **Exact map pin** (`includes/geo.php`, `staff/shelter.php`, `register.php`, `shelter.php`): shelters store latitude/longitude instead of relying on a geocoded address. The administrator taps *Use my current location* (accuracy is shown, and a warning appears when it is poor), or pastes coordinates, or a full Google Maps / OpenStreetMap link; a live preview shows the pin before saving. Only points inside the Philippines are accepted (catches swapped latitude/longitude). The public profile shows an *Exact pin* or *Approximate* badge; administrators get a "Check map pin" link when reviewing a shelter. Shortened `maps.app.goo.gl` links are rejected because they cannot be read without visiting them.
- **"No response" flag** (`includes/followups.php`, `staff/followups.php`, dashboard, nav badge): when an adoption's 1-week, 1-month and 3-month check-ins are **all** unanswered (and the last one is `NO_RESPONSE_GRACE_DAYS` = 7 days past due), the shelter gets a notification, a dashboard alert, a badge on *Welfare*, and a *No response* tab suggesting a welfare **call first, then a visit**, with the adopter's contact details. The shelter logs what it did and what happened (`welfare_checks`), which clears the flag and keeps a record. If the adopter answers late, the flag disappears by itself. Notes are erased when an adopter deletes their account.
- **Clickable success stories** (`story.php`): story cards on the Success Stories page and on shelter profiles show a short excerpt and open the full story (all pet photos, shelter, adopter name only with "full" consent). Adopter "Where are they now?" updates open too (`story.php?update=ID`). The same consent and shelter-status rules as the list apply, so a hidden or non-consented story returns "not found".
- **Choose first, then sign up** (`register.php`): *Create account* now asks **"I want to adopt a pet"** or **"I represent an animal shelter"** before showing any form. The adopter form has no shelter fields at all; the shelter form requires a verification document and still needs administrator approval. Employees still cannot sign up (the shelter administrator creates their accounts).
- **Reactivation petitions** (`staff/petition.php`, `admin/petitions.php`, `includes/petitions.php`): suspending a shelter now **requires a reason**, which the shelter sees (and gets by email and notification). The shelter administrator can send one petition at a time, and both sides can exchange messages in a thread. The administrator replies, **reactivates** the shelter (the petition closes as approved) or **denies** it with an explanation; a denied shelter may send a new petition (max 3 per week; 10 messages per hour). Employees can read but not write. Reactivating from *Shelters* also closes an open petition. Every decision is in the audit log.
- **Login popup and chime** (`includes/login_popup.php`, `assets/js/app.js`, `assets/sounds/notify.wav`): right after any login (including the admin two-step) a welcome popup lists what is waiting (unread notifications and messages, due check-ins, no-response adoptions, petitions, and so on) and plays a short chime; it has a *Sound on/off* switch remembered in the browser. Browsers decide whether sound may play without a click: if blocked, the chime plays on the first click or key press. Without JavaScript the popup simply does not appear. Nothing external is loaded (CSP unchanged).
- **Scope notice on the inquiry form** (`pet.php`): see "Does PawsAdopt handle the adoption itself?" below.

## Does PawsAdopt handle the adoption itself?
**Partly, and by design only up to the hand-over.** PawsAdopt handles *connecting and screening*: pet listings, inquiries with the adopter's profile and home-readiness checklist, the shelter's review, meetings, approve / reject, marking the pet adopted, and the welfare check-ins afterwards. It does **not** handle the legal or physical adoption: identity checks, interview, home visit, adoption fee, signed adoption agreement and handing over the animal happen directly between the shelter and the adopter, under the shelter's own rules.
Why there is no "verified adopter" step: the Philippines has no single national procedure for adopting a pet (the Animal Welfare Act, RA 8485 as amended by RA 10631, regulates animal *facilities* such as shelters, not adopters), and each shelter sets its own requirements; typical ones are a valid ID, photos of the home, an application or interview, an adoption fee and an agreement. Verifying IDs on PawsAdopt would also mean collecting and storing ID documents under RA 10173. The statement for your paper or defence: *"PawsAdopt connects adopters and verified shelters. The adoption process itself, including the shelter's requirements, interview, contract and fees, is outside the system's scope and is agreed between the shelter and the adopter."*
If a future version needs it, the lightest option is a shelter-controlled checkbox on each inquiry ("requirements confirmed in person") rather than platform-held documents.

## Legal text
Batch 6 does not edit the Terms or Privacy Notice, so nobody is asked to re-accept. Before launch, have your adviser add: shelter map location is public; adopter welfare-check notes kept by shelters; petition messages kept between a shelter and administrators. Then bump `TERMS_VERSION`.

## Updating from batch 4 to batch 5
1. **Back up first**, then run `database/migrations/005_batch5.sql` in phpMyAdmin (SQL tab). Fresh installs: `schema.sql` already includes everything.
2. Unzip over your project folder (`config/config.php` is kept). `TERMS_VERSION` is now `2026-10.4`: everyone accepts the updated Privacy Notice once at next login.
3. The migration turns live pets that have **no photo** into **drafts** (hidden until a photo is added) and makes the earliest staff account of each existing shelter its **shelter administrator**.
4. Maps use an embedded Google Maps frame (CSP now allows `frame-src` for google.com / openstreetmap.org). Everything else is unchanged: still no external scripts.

## What changed in batch 5
**Features**
- **Compatibility match** (`includes/match.php`): pets now have *good with other pets*, *needs a yard*, *energy level* and *experience needed*. Adopters see a "Good match for you" badge plus the reasons ("You live in a condo, and Mochi is small and apartment-friendly") and cautions on the pet page; browse can sort by best match; shelters see the match and reasons beside each inquiry.
- **Home-readiness checklist** (`adopter/readiness.php`): landlord permission, monthly budget, who cares for the pet. Asked once, required before the first inquiry, snapshotted onto each inquiry and shown to shelters (and in the email) with flags such as "No landlord permission yet".
- **Post-adoption check-ins** (`adopter/checkins.php`, `staff/followups.php`): scheduled at 1 week, 1 month and 3 months when a pet is marked adopted. In-app reminder when due; email at next login (no cron needed). Optional photo; adopters can allow the note and photo on the public Success Stories page ("Where are they now?"). Shelters get a welfare dashboard (doing well %, needs advice, overdue).
- ~~Foster and emergency-rescue board~~: removed in batch 7 (PawsAdopt now focuses only on connecting adopters and shelters and on the adoption process).
- **Shelter transparency** (`shelters.php`, `shelter.php`): adoptions this year, pets waiting, average days to adoption, average reply time, all counted from real data.
- **Photo and duplicate checks**: a new listing is a **draft** until it has a photo; a live listing cannot lose its last photo; staff are warned about same-name duplicates and re-used photo files (file hash).

**Fixes**
- First and last names: letters only (spaces, hyphen, apostrophe, period), enforced on the server and in the form (`name_error()`).
- **CAPTCHA**: the old image code called `imagerotate()`, which many hosts' PHP builds lack, so the image silently failed. It now uses only core GD functions, checks every function it needs (otherwise uses the text question), and has a "New image" button.
- Show / hide password button on every password field.
- Password reuse: a reset or change cannot reuse the current password or any of the last 5 (`password_history`). On reset the emailed code stays valid if the chosen password is rejected.
- Public **shelter profile** page with map, history, adoption records, success stories, announcements and transparency numbers; shelter names link to it everywhere.
- **Landing page** (`index.php`: about us, mission, vision, values, how it works, log in / sign up). Browsing pets moved to `pets.php`.
- Emails show the sender's **profile photo** (adopter, shelter logo or staff photo, administrator), embedded in the message so it also works on localhost.
- **Shelter registration**: sign-up now asks *adopter* or *shelter*. A shelter registers once (with its document) and becomes the shelter administrator; **employees cannot sign up**, the administrator creates each account under *Team* and hands over a one-time temporary password (change forced at first login). The invite-code join was removed.

## What changed in batch 4
- **Email verification** (`verify_email.php`): a 6-digit code (hashed, 10 minutes, 5 tries, 3 sends per hour). Unverified adopters and staff can browse, but cannot send inquiries or use chat. Changing your email needs your current password and re-verifies it. Resetting a password by emailed code also proves the email. The same one-time-code module (`includes/otp.php`, column `password_resets.purpose`) serves password reset, verification and admin sign-in, and codes of one purpose never work for another.
- **Admin two-step sign-in** (`verify_login.php`): after the password, a code is emailed to the admin (only when the admin's email is verified).
- **CAPTCHA** on sign-up and forgot-password (the two forms that send email), self-hosted so it fits the strict Content-Security-Policy: an image drawn with GD (`captcha.php`) or, for screen-reader users or when GD is missing, a simple text question. Single use, 10 minutes, case-insensitive, failures rate limited. It deters casual bots; it is not a defence against determined attackers or modern AI solvers.
- **Notifications**: bell icon with an unread count (refreshes every 30s), `notifications.php` list, mark-all-read, kept 90 days. Created wherever an email is sent (new inquiry, decisions, meetings, messages, shelter approval, reports, story requests).
- **Locations and pet details**: shelters now have city and province (required; pets inherit them, no retyping). Pets have size, vaccinated, spayed/neutered, good with kids. The browse page filters by location, size and the three yes/no details.
- **Adoption timeline** (table `inquiry_events`): sent, under review, meeting scheduled (with date), approved, revoked, withdrawn, adopted, closed because another applicant was adopted, closed because the listing was removed. Shown to the adopter and the shelter. `adoption_inquiries.status` is deliberately unchanged, so the unique keys that prevent duplicates and double approvals keep working. Staff can mark an inquiry "under review" and schedule meetings.
- **Success stories** (`staff/stories.php`, `stories.php`): a shelter writes a story for an adopted pet; the adopter is asked and chooses yes with first name and photo, yes anonymously, or no, and can change this any time. Editing the text asks for consent again. Admins can hide stories; a suspended shelter or a deleted adopter removes them from the public page.
- **Admin dashboard charts** (inquiries and adoptions per month) drawn as plain SVG, with no JavaScript library.
- **Page-transition loader**: a small paw appears only if a click or form submit is still loading after 120 ms, never delays navigation, and is static for visitors who prefer reduced motion.
- The CSP is unchanged (`script-src 'self'`); nothing in this batch needs an external script, inline script or inline style.

## What changed in batch 3
- **Conversations about an inquiry** (`chat.php`, `chat_api.php`, `assets/js/chat.js`, table `inquiry_messages`): adopter and the shelter's staff can message each other while the inquiry is pending or approved.
  "Real time" is AJAX polling every 3 seconds (paused while the tab is hidden, backs off on errors); it works on plain XAMPP with no extra software. Without JavaScript the page still works with normal form posts.
- Unread badge in the navigation (refreshes every 30s and instantly on the chat page), "Seen" marker under your last read message, Enter to send / Shift+Enter for a new line.
- **Rules:** only the adopter and staff of that shelter can read or send; messages are plain text (max 1000 chars, always escaped); 20 per minute and 300 per hour per user; the conversation becomes read-only when the inquiry is rejected or withdrawn, or when an administrator locks it.
- **Email alerts:** the other side is emailed about a new message only when they have nothing unread from you yet. The email names the sender and the pet but never contains the message text.
- **Moderation:** either participant can report a conversation. Only then can an administrator open it (read-only, every view is written to the audit log), lock/unlock it, or dismiss the report: Admin > Moderation > Reported conversations. Admins see a badge with the number of reported chats.
- **Privacy:** conversation text is included in the data export and is erased when the adopter deletes their account. The Privacy Notice and Terms describe all of this.
- Small fix: elements with the `hidden` attribute are now really hidden (the donation "target amount" field only appears for donation posts).

## What changed in batch 2
- **Terms and Conditions + Privacy Notice** (`terms.php`, `privacy.php`, RA 10173): sign-up requires an unticked-by-default acceptance checkbox; acceptance time and version are stored (`users.consent_at`, `users.terms_version`).
  Bump `TERMS_VERSION` (bootstrap default, or define it in config.php) after editing the legal text and everyone must accept again (`consent.php`).
- **Data subject rights** (Profile > Your data and privacy): download your data as JSON, and delete your account. Deletion anonymises the account
  (name, email, mobile, photo and profile details removed; inquiry messages erased; open inquiries withdrawn; a reserved pet is released). Business records stay without personal data.
- **Richer profiles:** profile photo (cropped to a 400x400 square, EXIF removed), city, bio; adopters: housing, other pets, pet experience; staff: job title.
  Staff see the adopter's profile when reviewing an inquiry, and the inquiry box is pre-filled from the adopter's profile.
- **Inquiry emailed to the shelter** (its contact email) with the adopter's details and message; adopters are emailed when a shelter approves, rejects, revokes, or the pet is adopted by someone else.
  Emails are sent after the page response (`send_mail_later`), so a slow mail server never slows a page, holds the session lock, or loses an inquiry; failures go to `logs/php_error.log`.
  The reset-code request also uses it, so response time no longer reveals whether an email is registered. SMTP waits are capped at 12 seconds.
- 10 inquiries per adopter per hour. New columns on `users`: profile_photo, bio, city, position, housing_type, other_pets, pet_experience, consent_at, terms_version; `account_status` gains the value `deleted`.

## What changed in batch 1
**Security**
- Login lockout: 5 failed attempts per account (25 per IP) blocks for 15 minutes. Reset-code requests, sign-ups and invite-code tries are rate limited too (table `rate_limits`).
- Forced password change for the default admin; password policy (8-72 chars, letter + number) everywhere.
- Changing or resetting a password signs out the user's other devices (`users.session_version`); 30-minute idle timeout.
- One-time-code password reset: 6-digit code, stored hashed, 10 minutes, 5 tries, single use, neutral responses (no account guessing), max 3 requests/hour/account.
- Errors are logged to `logs/php_error.log`, never shown (set APP_DEBUG=true only while developing). Security headers (CSP, X-Frame-Options, nosniff, Referrer-Policy; HSTS on HTTPS). Cookies are HttpOnly + SameSite.
- Verification documents are stored outside the web root and streamed to admins only. Uploaded photos are re-encoded (EXIF/GPS and hidden code removed), resized to 1600px, and size-limited.
- Admin audit log (`admin_audit_log`, page: Admin > Audit log). Emails to shelters on approval/rejection.
- Least-privilege database user: `database/create_app_user.sql`.

**Logic**
- DB-level unique keys: one active inquiry per adopter+pet, one approved inquiry per pet (blocks double-clicks and races).
- `set_pet_status()` is the single place pet status changes; marking a pet adopted or removing a listing closes the affected inquiries. A pet cannot be set back to available while an approval exists; staff can revoke an approval.
- Staff can only approve while the pet is available. Dates use Asia/Manila. Admin lists are paginated.
- Shelters get an invite code so more than one staff member can join (the ERD allows 1..*).
- Sign-up requires confirming age 18+. Donation posts show the shelter's contact and a "no payments handled here" notice.

**PH contact numbers**: mobile numbers must be 11 digits starting with 09 (spaces, dashes and +63 are normalized). Shelters may also use a landline with area code. Enforced on the server and in the form.

## Use case coverage
| UC | Feature | File |
|----|---------|------|
| 01 | Register account | register.php |
| 02 | Log in / out | login.php, logout.php |
| 03 | Reset password (emailed code) | forgot_password.php, reset_password.php |
| 04 | Manage profile (photo, details, data export, delete account) | profile.php |
| 05 | Register shelter profile | staff/shelter.php |
| 06 | Approve or reject shelter | admin/shelters.php |
| 07 | Manage pet listings (+ photos) | staff/pets.php, staff/pet_form.php |
| 08 | Browse and search pets | index.php |
| 09 | View pet details | pet.php |
| 10 | Submit adoption inquiry | pet.php |
| 11 | View and withdraw inquiries | adopter/inquiries.php |
| 12 | Process adoption inquiries | staff/inquiries.php |
| 13 | Manage announcements & donations | staff/posts.php |
| 14 | View announcements & donations | announcements.php |
| 16 | Conversation about an inquiry | chat.php, chat_api.php |
| 19 | Verify email | verify_email.php |
| 20 | View notifications | notifications.php |
| 21 | Track adoption timeline / schedule a meeting | adopter/inquiries.php, staff/inquiries.php |
| 22 | Share and consent to a success story | staff/stories.php, adopter/inquiries.php, stories.php |
| 23 | Admin two-step sign-in (extends UC-02) | verify_login.php |
| 17 | Report a conversation / review reported conversations | chat.php, admin/moderation.php |
| 29 | Choose account type (adopter or shelter) | register.php |
| 30 | Request shelter reactivation (petition and messages) | staff/petition.php, admin/petitions.php |
| 31 | Read a success story | story.php |
| 32 | Welfare check after no response | staff/followups.php |
| 15 | Moderate content & manage accounts | admin/users.php, admin/moderation.php, admin/shelters.php, admin/audit.php |

## Legal pages
The Terms and Privacy Notice are templates written to match what the system actually does. Have your adviser or Data Protection Officer review them before launch.

## Email
Set MAIL_* in config.php (Gmail needs an App Password). If `MAIL_HOST` is left empty, emails are written to `logs/mail.log`
instead of being sent, which is handy while developing (reset codes appear there).

## Tables
The DFD data stores (users, shelters, pets, pet_photos, adoption_inquiries, announcements_donations) plus `inquiry_messages` (D7, conversations), `inquiry_events` (D8, timeline), `success_stories` (D9), plus the support
tables that are not business entities: `rate_limits`, `password_resets`, `admin_audit_log`, `notifications`. Batch 6 adds `welfare_checks`, `shelter_petitions` and `shelter_petition_messages`. Add them to your ERD as "system/security tables".
