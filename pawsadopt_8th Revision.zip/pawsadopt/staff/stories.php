<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Success stories'; $page = 'sstories'; $errors = []; $sid = (int)$u['shelter_id'];
// Success stories: only for adopted pets. The story is public ONLY after the adopter explicitly consents (and chooses whether name and photo appear).
$eligible = fn() => q("SELECT i.inquiry_id, i.adopter_id, p.pet_id, p.pet_name, p.species, a.first_name, a.last_name, a.email, st.story_id, st.title, st.body, st.consent, st.status AS story_status
    FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN users a ON a.user_id=i.adopter_id LEFT JOIN success_stories st ON st.inquiry_id=i.inquiry_id
    WHERE p.shelter_id=? AND p.status='adopted' AND i.status='approved' AND a.account_status='active' ORDER BY p.updated_at DESC", [$sid])->fetchAll();
$rows = $eligible();
$byInq = []; foreach ($rows as $r) $byInq[$r['inquiry_id']] = $r;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $iid = (int)($_POST['inquiry'] ?? 0); $r = $byInq[$iid] ?? null;
    if (!$r) { flash('error', 'That adoption was not found.'); redirect('staff/stories.php'); }
    if (($_POST['action'] ?? '') === 'delete' && $r['story_id']) {
        q('DELETE FROM success_stories WHERE story_id=? AND shelter_id=?', [$r['story_id'], $sid]); flash('success', 'Story deleted.'); redirect('staff/stories.php');
    }
    $t = trim($_POST['title'] ?? ''); $b = trim($_POST['body'] ?? '');
    if ($t === '' || str_len($t) > 150) $errors[] = 'Give the story a title (up to 150 characters).';
    if (str_len($b) < 30 || str_len($b) > 1500) $errors[] = 'The story must be between 30 and 1500 characters.';
    if (!$errors) {
        if ($r['story_id']) q("UPDATE success_stories SET title=?, body=?, consent='requested', consent_at=NULL WHERE story_id=? AND shelter_id=?", [$t, $b, $r['story_id'], $sid]);   // edited text needs fresh consent
        else q('INSERT INTO success_stories (inquiry_id, shelter_id, posted_by, title, body) VALUES (?,?,?,?,?)', [$iid, $sid, $u['user_id'], $t, $b]);
        notify_adopter_update(['user_id' => $r['adopter_id'], 'email' => $r['email'], 'first_name' => $r['first_name']], $r['pet_name'], $u['shelter_name'], 'story_request', null,
          shelter_sender(['shelter_id' => $u['shelter_id'], 'shelter_name' => $u['shelter_name'], 'logo' => $u['shelter_logo'] ?? null], $u));
        flash('success', 'Saved. We asked ' . $r['first_name'] . ' for permission; the story goes public only if they agree.'); redirect('staff/stories.php');
    }
    $_GET['inquiry'] = $iid;
}
$sel = $byInq[(int)($_GET['inquiry'] ?? 0)] ?? null;
include __DIR__ . '/../includes/header.php';
?>
<h1>Success stories</h1>
<p class="muted">Celebrate adoptions on the public Success Stories page. For privacy, a story is shown only if the adopter says yes, and they decide whether their first name and photo appear. Do not include surnames, contact details or addresses in the text.</p>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<?php if ($sel): ?>
<form method="post" class="stack panel narrow-form"><?= csrf_field() ?><input type="hidden" name="inquiry" value="<?= $sel['inquiry_id'] ?>">
  <h2><?= e($sel['pet_name']) ?>'s story</h2>
  <?php if ($sel['story_id']): ?><p class="hint">Editing resets the adopter's consent: they will be asked again.</p><?php endif; ?>
  <label>Title<input name="title" maxlength="150" value="<?= e($_POST['title'] ?? $sel['title'] ?? '') ?>" required placeholder="e.g. Buddy found his forever home"></label>
  <label>Story<textarea name="body" rows="7" maxlength="1500" required><?= e($_POST['body'] ?? $sel['body'] ?? '') ?></textarea></label>
  <div class="actions"><button class="btn"><?= $sel['story_id'] ? 'Save and ask for consent again' : 'Save and ask the adopter for consent' ?></button><a class="btn btn-ghost" href="<?= url('staff/stories.php') ?>">Cancel</a></div>
</form>
<?php endif; ?>
<?php if (!$rows): ?><div class="empty"><h2>No adopted pets yet</h2><p>When you mark a pet as adopted from an approved inquiry, it appears here and you can share its story.</p></div><?php else: ?>
<div class="table-wrap"><table>
<thead><tr><th>Pet</th><th>Adopter</th><th>Story</th><th>Adopter's choice</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr>
  <td><?= e($r['pet_name']) ?> <span class="muted small"><?= e($r['species']) ?></span></td><td><?= e($r['first_name']) ?></td>
  <td><?= $r['story_id'] ? e($r['title']) : '<span class="muted">Not written yet</span>' ?><?= $r['story_status'] === 'hidden' ? ' ' . badge('hidden') : '' ?></td>
  <td><?= $r['story_id'] ? badge(['requested' => 'pending', 'full' => 'approved', 'anonymous' => 'approved', 'declined' => 'rejected'][$r['consent']]) . ' <span class="small muted">' . e(['requested' => 'waiting for reply', 'full' => 'name and photo OK', 'anonymous' => 'anonymous only', 'declined' => 'declined'][$r['consent']]) . '</span>' : '-' ?></td>
  <td class="row-actions"><a class="btn btn-sm btn-ghost" href="?inquiry=<?= $r['inquiry_id'] ?>"><?= $r['story_id'] ? 'Edit' : 'Write story' ?></a>
    <?php if ($r['story_id']): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="inquiry" value="<?= $r['inquiry_id'] ?>"><button class="btn btn-sm btn-danger" name="action" value="delete" data-confirm="Delete this story?">Delete</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
