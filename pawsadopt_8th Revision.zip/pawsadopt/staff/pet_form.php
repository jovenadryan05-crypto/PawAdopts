<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved before you can list pets.'); redirect('staff/dashboard.php'); }
$id = (int)($_GET['id'] ?? 0);
$pet = null;
if ($id) {
    $pet = q('SELECT * FROM pets WHERE pet_id=? AND shelter_id=?', [$id, $u['shelter_id']])->fetch();
    if (!$pet) { http_response_code(404); exit('Pet not found in your shelter.'); }
}
$title = $pet ? 'Edit ' . $pet['pet_name'] : 'List a pet'; $page = 'pets'; $errors = [];

/** Save the uploaded photos; returns how many were stored. The file's hash is kept so the same picture reused on another listing is flagged. */
function save_photos(int $petId): int {
    $files = $_FILES['photos'] ?? null; $saved = 0;
    if (!$files || empty($files['name'][0])) return 0;
    $hasPrimary = (bool)q('SELECT 1 FROM pet_photos WHERE pet_id=? AND is_primary=1', [$petId])->fetch();
    foreach ($files['name'] as $i => $_) {
        $one = ['name' => $files['name'][$i], 'type' => $files['type'][$i], 'tmp_name' => $files['tmp_name'][$i], 'error' => $files['error'][$i], 'size' => $files['size'][$i]];
        $hash = !empty($one['tmp_name']) && is_uploaded_file($one['tmp_name']) ? sha1_file($one['tmp_name']) : null;   // before re-encoding moves or changes the file
        $path = save_upload($one, 'pets');
        if ($path) { q('INSERT INTO pet_photos (pet_id, photo_url, is_primary, content_hash) VALUES (?,?,?,?)', [$petId, $path, $hasPrimary ? 0 : 1, $hash]); $hasPrimary = true; $saved++; }
    }
    return $saved;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? 'save';
    if ($pet && $act === 'primary') {       // single primary-photo rule
        $ph = (int)$_POST['photo_id'];
        if (q('SELECT 1 FROM pet_photos WHERE photo_id=? AND pet_id=?', [$ph, $id])->fetch()) {
            q('UPDATE pet_photos SET is_primary = (photo_id = ?) WHERE pet_id=?', [$ph, $id]); flash('success', 'Primary photo updated.');
        }
        redirect('staff/pet_form.php?id=' . $id);
    }
    if ($pet && $act === 'delete_photo') {
        $row = q('SELECT * FROM pet_photos WHERE photo_id=? AND pet_id=?', [(int)$_POST['photo_id'], $id])->fetch();
        if ($row && in_array($pet['status'], ['available', 'pending'], true) && pet_photo_count($id) <= 1) {
            flash('error', 'A live listing needs at least one photo. Add another photo first, then delete this one.'); $row = null;
        }
        if ($row) {
            q('DELETE FROM pet_photos WHERE photo_id=?', [$row['photo_id']]);
            @unlink(__DIR__ . '/../' . $row['photo_url']);
            if ($row['is_primary']) q('UPDATE pet_photos SET is_primary=1 WHERE pet_id=? ORDER BY photo_id LIMIT 1', [$id]);
            flash('success', 'Photo deleted.');
        }
        redirect('staff/pet_form.php?id=' . $id);
    }
    $f = fn($k) => trim($_POST[$k] ?? '');
    $years = max(0, (int)$f('age_years')); $months = max(0, min(11, (int)$f('age_months')));
    $ageM = $years * 12 + $months;
    if ($f('pet_name') === '' || $f('species') === '') $errors[] = 'Name and species are required.';
    if ($ageM > 600) $errors[] = 'Enter a realistic age.';
    $sex = in_array($f('sex'), ['male', 'female', 'unknown'], true) ? $f('sex') : 'unknown';
    $yn = fn($k) => in_array($f($k), ['yes', 'no', 'unknown'], true) ? $f($k) : 'unknown';
    $size = in_array($f('size'), ['small', 'medium', 'large'], true) ? $f('size') : null;
    $status = in_array($f('status'), ['draft', 'available', 'pending', 'adopted'], true) ? $f('status') : 'available';
    $good = fn($k) => in_array($f($k), ['yes', 'no', 'unknown'], true) ? $f($k) : 'unknown';
    $energy = in_array($f('energy_level'), ['low', 'medium', 'high'], true) ? $f('energy_level') : null;
    $expNeeded = in_array($f('experience_needed'), ['first_time', 'some', 'experienced'], true) ? $f('experience_needed') : null;
    if (!$errors) {
        if ($pet) {
            q('UPDATE pets SET pet_name=?, species=?, breed=?, sex=?, age_months=?, description=?, size=?, vaccinated=?, neutered=?, good_with_kids=?, good_with_pets=?, needs_yard=?, energy_level=?, experience_needed=? WHERE pet_id=?',
              [$f('pet_name'), $f('species'), $f('breed') ?: null, $sex, $ageM, $f('description'), $size, $yn('vaccinated'), $yn('neutered'), $yn('good_with_kids'), $good('good_with_pets'), $good('needs_yard'), $energy, $expNeeded, $id]);
            save_photos($id);                                   // photos first, so the photo rule below sees them
            if ($pet['status'] === 'draft' && in_array($status, ['pending', 'adopted'], true)) $status = 'draft';
            if ($pet['status'] !== 'removed' && $status !== $pet['status'] && ($err = set_pet_status($id, $status))) flash('error', $err);
        } else {
            // a new listing starts as a DRAFT and only goes live once it has a photo
            q('INSERT INTO pets (shelter_id, listed_by, pet_name, species, breed, sex, age_months, description, size, vaccinated, neutered, good_with_kids, good_with_pets, needs_yard, energy_level, experience_needed, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
              [$u['shelter_id'], $u['user_id'], $f('pet_name'), $f('species'), $f('breed') ?: null, $sex, $ageM, $f('description'), $size, $yn('vaccinated'), $yn('neutered'), $yn('good_with_kids'), $good('good_with_pets'), $good('needs_yard'), $energy, $expNeeded, 'draft']);
            $id = (int)db()->lastInsertId();
            if (save_photos($id) > 0) q("UPDATE pets SET status='available' WHERE pet_id=? AND status='draft'", [$id]);
        }
        $live = q('SELECT status FROM pets WHERE pet_id=?', [$id])->fetchColumn();
        if ($live === 'draft') flash('info', 'Saved as a DRAFT: add at least one photo to publish this listing. Draft listings are not visible to adopters.');
        else flash('success', $pet ? 'Listing saved.' : 'Pet listed.');
        foreach (pet_duplicates($id) as $w) flash('info', 'Check: ' . $w);          // warnings never block, but staff see them straight away
        redirect('staff/pets.php');
    }
}
$photos = $pet ? q('SELECT * FROM pet_photos WHERE pet_id=? ORDER BY is_primary DESC, photo_id', [$id])->fetchAll() : [];
$v = fn($k, $d = '') => e($_POST[$k] ?? ($pet[$k] ?? $d));
$ay = $_POST['age_years'] ?? ($pet ? intdiv((int)$pet['age_months'], 12) : 0);
$am = $_POST['age_months'] ?? ($pet ? (int)$pet['age_months'] % 12 : 0);
$curSex = $_POST['sex'] ?? ($pet['sex'] ?? 'unknown');
$curStatus = $_POST['status'] ?? (($pet['status'] ?? 'available') === 'draft' ? 'available' : ($pet['status'] ?? 'available'));   // a draft is offered for publishing
include __DIR__ . '/../includes/header.php';
?>
<h1><?= e($title) ?></h1>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="stack panel narrow-form"><?= csrf_field() ?>
  <div class="two"><label>Name<input name="pet_name" value="<?= $v('pet_name') ?>" required></label>
  <label>Species<input name="species" list="species" value="<?= $v('species') ?>" placeholder="Dog, Cat, Rabbit..." required></label></div>
  <datalist id="species"><option>Dog</option><option>Cat</option><option>Rabbit</option><option>Bird</option></datalist>
  <div class="two"><label>Breed<input name="breed" value="<?= $v('breed') ?>"></label>
  <label>Sex<select name="sex"><?php foreach (['male', 'female', 'unknown'] as $s): ?><option value="<?= $s ?>" <?= $curSex === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option><?php endforeach; ?></select></label></div>
  <div class="two"><label>Age (years)<input type="number" name="age_years" min="0" max="50" value="<?= e($ay) ?>"></label>
  <label>Age (months)<input type="number" name="age_months" min="0" max="11" value="<?= e($am) ?>"></label></div>
  <div class="two">
    <label>Size<select name="size"><option value="">Not specified</option><?php $curSize = $_POST['size'] ?? ($pet['size'] ?? ''); foreach (['small', 'medium', 'large'] as $z): ?><option value="<?= $z ?>" <?= $curSize === $z ? 'selected' : '' ?>><?= ucfirst($z) ?></option><?php endforeach; ?></select></label>
    <label>Location<input value="<?= e(trim(($u['shelter_city'] ?? '') . ', ' . ($u['shelter_province'] ?? ''), ', ') ?: 'Set it in your shelter details') ?>" disabled><span class="hint">Inherited from your shelter.</span></label>
  </div>
  <div class="two">
  <?php foreach (['vaccinated' => 'Vaccinated', 'neutered' => 'Spayed / neutered', 'good_with_kids' => 'Good with kids'] as $k => $lbl): $cur = $_POST[$k] ?? ($pet[$k] ?? 'unknown'); ?>
    <label><?= $lbl ?><select name="<?= $k ?>"><?php foreach (['unknown' => 'Not sure', 'yes' => 'Yes', 'no' => 'No'] as $val => $t): ?><option value="<?= $val ?>" <?= $cur === $val ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  <?php endforeach; ?>
  </div>
  <h3>Match details <span class="hint">Helps adopters see whether this pet fits their home. Shown as a "Good match" badge.</span></h3>
  <div class="two">
    <label>Good with other pets<select name="good_with_pets"><?php $cur = $_POST['good_with_pets'] ?? ($pet['good_with_pets'] ?? 'unknown'); foreach (['unknown' => 'Not sure', 'yes' => 'Yes', 'no' => 'No, prefers to be the only pet'] as $val => $t): ?><option value="<?= $val ?>" <?= $cur === $val ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
    <label>Needs a yard<select name="needs_yard"><?php $cur = $_POST['needs_yard'] ?? ($pet['needs_yard'] ?? 'unknown'); foreach (['unknown' => 'Not sure', 'yes' => 'Yes, needs outdoor space', 'no' => 'No, fine in an apartment'] as $val => $t): ?><option value="<?= $val ?>" <?= $cur === $val ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  </div>
  <div class="two">
    <label>Energy level<select name="energy_level"><option value="">Not specified</option><?php $cur = $_POST['energy_level'] ?? ($pet['energy_level'] ?? ''); foreach (['low' => 'Low (calm, mostly relaxed)', 'medium' => 'Medium', 'high' => 'High (needs lots of exercise)'] as $val => $t): ?><option value="<?= $val ?>" <?= $cur === $val ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
    <label>Experience needed<select name="experience_needed"><option value="">Not specified</option><?php $cur = $_POST['experience_needed'] ?? ($pet['experience_needed'] ?? ''); foreach (['first_time' => 'None: great for first-time owners', 'some' => 'Some experience helps', 'experienced' => 'Experienced owner needed'] as $val => $t): ?><option value="<?= $val ?>" <?= $cur === $val ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  </div>
  <?php if ($pet && $pet['status'] !== 'removed'): ?>
  <label>Status<select name="status"><?php foreach (($pet['status'] === 'draft' ? ['draft', 'available'] : ['available', 'pending', 'adopted']) as $s): ?><option value="<?= $s ?>" <?= $curStatus === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option><?php endforeach; ?></select></label>
  <?php endif; ?>
  <label>Description<textarea name="description" rows="6" placeholder="Temperament, health, good with kids or other pets..."><?= $v('description') ?></textarea></label>
  <label>Add photos (JPG, PNG, WEBP; max 5 MB each) <strong>At least one photo is required before the listing goes live.</strong><input type="file" name="photos[]" accept="image/*" multiple data-preview="#previews"></label>
  <div id="previews" class="previews"></div>
  <div class="actions"><button class="btn">Save listing</button><a class="btn btn-ghost" href="<?= url('staff/pets.php') ?>">Cancel</a></div>
</form>

<?php if ($photos): ?>
<h2>Photos</h2>
<div class="photo-manager">
<?php foreach ($photos as $ph): ?>
  <div class="pm"><img src="<?= url($ph['photo_url']) ?>" alt="">
    <div class="pm-actions">
      <?php if ($ph['is_primary']): ?><span class="badge b-approved">Primary</span><?php else: ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="primary"><input type="hidden" name="photo_id" value="<?= $ph['photo_id'] ?>"><button class="btn btn-sm btn-ghost">Make primary</button></form><?php endif; ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete_photo"><input type="hidden" name="photo_id" value="<?= $ph['photo_id'] ?>"><button class="btn btn-sm btn-danger" data-confirm="Delete this photo?">Delete</button></form>
    </div></div>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
