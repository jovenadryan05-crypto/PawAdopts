<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Adoption welfare'; $page = 'sfollow'; $sid = (int)$u['shelter_id'];
csrf_check();
// Log a welfare check (call / visit / message) for a flagged adoption. This clears the "no response" flag and keeps a record.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'welfare_check') {
    $iid = (int)($_POST['inquiry_id'] ?? 0); $method = $_POST['method'] ?? ''; $outcome = $_POST['outcome'] ?? ''; $note = trim($_POST['note'] ?? '');
    $ok = q('SELECT 1 FROM adoption_inquiries i JOIN pets p ON p.pet_id = i.pet_id WHERE i.inquiry_id = ? AND p.shelter_id = ?', [$iid, $sid])->fetch();
    if (!$ok) flash('error', 'Adoption not found.');
    elseif (!isset(welfare_methods()[$method]) || !isset(welfare_outcomes()[$outcome])) flash('error', 'Choose what you did and what happened.');
    elseif (str_len($note) > 500) flash('error', 'Please keep the note under 500 characters.');
    else {
        q('INSERT INTO welfare_checks (inquiry_id, staff_id, method, outcome, note) VALUES (?,?,?,?,?)', [$iid, $u['user_id'], $method, $outcome, $note ?: null]);
        flash('success', $outcome === 'needs_help' || $outcome === 'unreachable' ? 'Welfare check saved. Consider a follow-up if the pet may be at risk.' : 'Welfare check saved.');
    }
    redirect('staff/followups.php?s=noresponse');
}
followups_flag_no_response($sid);
$noResp = followups_no_response($sid);
// Welfare data from post-adoption check-ins: who answered, how the pets are doing, who needs advice, who is overdue.
$sum = q("SELECT COUNT(*) AS sent, SUM(f.wellbeing = 'thriving') AS thriving, SUM(f.wellbeing = 'good') AS good, SUM(f.wellbeing = 'adjusting') AS adjusting, SUM(f.wellbeing = 'struggling') AS struggling
          FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id WHERE p.shelter_id = ? AND f.submitted_at IS NOT NULL", [$sid])->fetch();
$pending = (int)q("SELECT COUNT(*) FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id JOIN pets p ON p.pet_id = i.pet_id WHERE p.shelter_id = ? AND f.submitted_at IS NULL AND f.due_at <= NOW() - INTERVAL 7 DAY", [$sid])->fetchColumn();
$f = $_GET['s'] ?? 'all'; if (!in_array($f, ['all', 'attention', 'overdue', 'noresponse'], true)) $f = 'all';
$cond = $f === 'attention' ? "AND f.wellbeing IN ('adjusting','struggling')" : ($f === 'overdue' ? 'AND f.submitted_at IS NULL AND f.due_at <= NOW() - INTERVAL 7 DAY' : 'AND (f.submitted_at IS NOT NULL OR f.due_at <= NOW())');
$rows = q("SELECT f.*, p.pet_name, p.species, a.first_name, a.last_name, a.email, a.contact_number FROM adoption_followups f JOIN adoption_inquiries i ON i.inquiry_id = f.inquiry_id
           JOIN pets p ON p.pet_id = i.pet_id JOIN users a ON a.user_id = i.adopter_id WHERE p.shelter_id = ? $cond ORDER BY COALESCE(f.submitted_at, f.due_at) DESC LIMIT 100", [$sid])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Adoption welfare</h1>
<p class="muted">Adopters are asked for a check-in 1 week, 1 month and 3 months after an adoption. Use it to spot pets that need help and to see how your adoptions turn out.</p>
<div class="stats">
  <div class="stat"><b><?= (int)$sum['sent'] ?></b><span>Check-ins received</span></div>
  <div class="stat"><b><?= (int)$sum['sent'] ? round(((int)$sum['thriving'] + (int)$sum['good']) / (int)$sum['sent'] * 100) . '%' : '-' ?></b><span>Doing well or thriving</span></div>
  <div class="stat"><b><?= (int)$sum['adjusting'] + (int)$sum['struggling'] ?></b><span>Adjusting or struggling</span></div>
  <div class="stat"><b><?= $pending ?></b><span>Overdue by a week or more</span></div>
</div>
<?php if ($noResp && $f !== 'noresponse'): ?><div class="flash flash-error"><strong><?= count($noResp) ?> adoption<?= count($noResp) === 1 ? '' : 's' ?> with no response.</strong> All three check-ins went unanswered. <a href="?s=noresponse">See who to call or visit</a></div><?php endif; ?>
<div class="tabs"><?php foreach (['all' => 'All', 'attention' => 'Needs attention', 'overdue' => 'Overdue', 'noresponse' => 'No response' . ($noResp ? ' (' . count($noResp) . ')' : '')] as $k => $t): ?><a class="<?= $f === $k ? 'on' : '' ?>" href="?s=<?= $k ?>"><?= e($t) ?></a><?php endforeach; ?></div>
<?php if ($f === 'noresponse'): ?>
<p class="muted">These adopters did not answer any of the three check-ins (1 week, 1 month, 3 months). Silence is not proof of a problem, but it is the moment for a welfare call, and a visit if the call goes unanswered. Log what you did so the flag clears and your records show it.</p>
<?php if (!$noResp): ?><div class="empty"><h2>No unanswered adoptions</h2><p>Every adoption either answered a check-in or already has a welfare check on record.</p></div><?php endif; ?>
<?php foreach ($noResp as $r): ?>
<article class="panel flag-panel">
  <div class="split"><h2><?= e($r['pet_name']) ?> <span class="muted small"><?= e($r['species']) ?> &middot; adopted <?= $r['adopted_at'] ? e(fdate($r['adopted_at'])) : '' ?></span></h2><span class="badge b-rejected">No response</span></div>
  <p><strong><?= e($r['first_name'] . ' ' . $r['last_name']) ?></strong> did not answer any check-in. <strong>Suggested next step: call first, then visit.</strong></p>
  <p class="small">Phone: <?= e($r['contact_number']) ?> &middot; Email: <?= e($r['email']) ?><?= $r['city'] ? ' &middot; City: ' . e($r['city']) : '' ?></p>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="welfare_check"><input type="hidden" name="inquiry_id" value="<?= (int)$r['inquiry_id'] ?>">
    <div class="two"><label>What did you do?<select name="method" required><option value="">Choose...</option><?php foreach (welfare_methods() as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></label>
    <label>What happened?<select name="outcome" required><option value="">Choose...</option><?php foreach (welfare_outcomes() as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></label></div>
    <label>Note (optional)<textarea name="note" rows="2" maxlength="500" placeholder="Who you spoke to, what you saw, what was agreed."></textarea></label>
    <button class="btn btn-sm">Save welfare check</button></form>
</article>
<?php endforeach; ?>
<?php endif; ?>
<?php if ($f === 'noresponse') $rows = []; ?>
<?php if (!$rows && $f !== 'noresponse'): ?><div class="empty"><h2>Nothing here yet</h2><p>Check-ins appear after you mark an adoption as complete.</p></div><?php endif; ?>
<?php foreach ($rows as $r): ?>
<article class="panel">
  <div class="split"><h2><?= e($r['pet_name']) ?> <span class="muted small"><?= e(followup_milestones()[$r['milestone']][0]) ?> check-in &middot; <?= e($r['first_name'] . ' ' . $r['last_name']) ?></span></h2>
    <?= $r['submitted_at'] ? ($r['wellbeing'] === 'struggling' ? '<span class="badge b-rejected">Needs advice</span>' : ($r['wellbeing'] === 'adjusting' ? '<span class="badge b-pending">Adjusting</span>' : '<span class="badge b-approved">' . e(ucfirst($r['wellbeing'])) . '</span>')) : '<span class="badge b-pending">Waiting for adopter</span>' ?></div>
  <?php if ($r['submitted_at']): ?>
    <p class="small muted">Received <?= fdate($r['submitted_at']) ?></p>
    <?php if ($r['notes']): ?><p class="quote"><?= nl2br(e($r['notes'])) ?></p><?php endif; ?>
    <?php if ($r['photo']): ?><img class="checkin-photo" src="<?= url($r['photo']) ?>" alt="Photo of <?= e($r['pet_name']) ?> from the adopter"><?php endif; ?>
    <?php if (in_array($r['wellbeing'], ['struggling', 'adjusting'], true)): ?><p class="small">Reach out: <?= e($r['email']) ?> &middot; <?= e($r['contact_number']) ?></p><?php endif; ?>
    <p class="small muted"><?= $r['share_ok'] ? 'The adopter allows this to be shown on the public Success Stories page.' : 'Private to your shelter.' ?></p>
  <?php else: ?><p class="small muted">Due <?= fdate($r['due_at']) ?>. The adopter was reminded in the app<?= $r['emailed_at'] ? ' and by email' : '' ?>.</p><?php endif; ?>
</article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
