<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
$title = 'Request reactivation'; $page = 'petition'; $errors = [];
// A suspended shelter asks the administrators to lift the suspension, and they can exchange messages here.
// The shelter administrator opens and answers the petition; employees can read it. Anyone else is sent back to the dashboard.
if (!shelter_suspended($u)) { flash('info', 'This page is only for shelters that are currently suspended.'); redirect('staff/dashboard.php'); }
$sid = (int)$u['shelter_id']; $isAdmin = !empty($u['is_shelter_admin']);
$shelter = q('SELECT shelter_name, suspension_reason, suspended_at, contact_email FROM shelters WHERE shelter_id = ?', [$sid])->fetch();
$open = petition_open_for($sid);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? ''; $body = trim($_POST['body'] ?? '');
    if (!$isAdmin) $errors[] = 'Only your shelter administrator can send messages to PawsAdopt.';
    elseif ($err = petition_body_error($body)) $errors[] = $err;
    elseif (rate_blocked('petition:msg:' . $sid, 10, 3600)) $errors[] = 'You sent several messages in a short time. Please wait a little and try again.';
    elseif ($act === 'open') {
        if ($open) $errors[] = 'A petition is already open. Add your message to it instead.';
        elseif (rate_blocked('petition:open:' . $sid, 3, 7 * 86400)) $errors[] = 'You have sent three petitions this week. Please wait for a reply, or try again in a few days.';
        else {
            try {
                q('INSERT INTO shelter_petitions (shelter_id, opened_by, suspension_reason) VALUES (?,?,?)', [$sid, $u['user_id'], $shelter['suspension_reason']]);
                $pid = (int)db()->lastInsertId();
                petition_add_message($pid, (int)$u['user_id'], 'shelter', $body);
                rate_hit('petition:open:' . $sid); rate_hit('petition:msg:' . $sid);
                notify_users(admin_ids(), 'petition', 'Reactivation petition: ' . $shelter['shelter_name'], cut_text($body, 200), 'admin/petitions.php?id=' . $pid);
                flash('success', 'Your petition was sent. An administrator will review it and reply here.');
                redirect('staff/petition.php');
            } catch (PDOException $ex) {
                if ($ex->getCode() !== '23000') throw $ex;
                $errors[] = 'A petition is already open for your shelter.';
            }
        }
    } elseif ($act === 'reply') {
        if (!$open) $errors[] = 'There is no open petition to reply to.';
        else {
            petition_add_message((int)$open['petition_id'], (int)$u['user_id'], 'shelter', $body);
            rate_hit('petition:msg:' . $sid);
            notify_users(admin_ids(), 'petition', 'New message from ' . $shelter['shelter_name'], cut_text($body, 200), 'admin/petitions.php?id=' . (int)$open['petition_id']);
            flash('success', 'Message sent.');
            redirect('staff/petition.php');
        }
    }
    $open = petition_open_for($sid);
}
$last = $open ?: petition_latest_for($sid);
$msgs = $last ? petition_messages((int)$last['petition_id']) : [];
include __DIR__ . '/../includes/header.php';
?>
<h1>Request reactivation</h1>
<div class="panel"><h2><?= e($shelter['shelter_name']) ?> <?= badge('suspended') ?></h2>
  <p><strong>Why it was suspended<?= $shelter['suspended_at'] ? ' (' . e(fdate($shelter['suspended_at'])) . ')' : '' ?>:</strong><br><?= e($shelter['suspension_reason'] ?: 'The administrator did not record a reason. Ask in your petition.') ?></p>
  <p class="muted small">While suspended, your listings and announcements are hidden and you cannot take new inquiries. You can still log in and use this page.</p></div>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>

<?php if ($last): ?>
<div class="panel"><div class="split"><h2>Your petition</h2><?= petition_status_badge($last['status']) ?></div>
  <p class="small muted">Sent <?= e(fdate($last['created_at'])) ?><?= $last['resolved_at'] ? ' &middot; decided ' . e(fdate($last['resolved_at'])) : '' ?></p>
  <?= petition_thread_html($msgs) ?>
</div>
<?php endif; ?>

<?php if (!$isAdmin): ?>
  <div class="flash flash-info">Only your shelter administrator can send a petition or reply to PawsAdopt. Please ask them to use this page.</div>
<?php elseif ($open): ?>
  <form method="post" class="stack panel narrow-form"><?= csrf_field() ?><input type="hidden" name="action" value="reply">
    <h2>Add a message</h2>
    <label>Your message<textarea name="body" rows="4" minlength="10" maxlength="<?= PETITION_MAX_LEN ?>" required placeholder="Answer a question from the administrator, or add details."></textarea></label>
    <button class="btn">Send message</button></form>
<?php else: ?>
  <form method="post" class="stack panel narrow-form"><?= csrf_field() ?><input type="hidden" name="action" value="open">
    <h2><?= $last && $last['status'] === 'denied' ? 'Send a new petition' : 'Petition to be reactivated' ?></h2>
    <p class="muted">Explain what happened and what you have fixed or will change. Be specific; it helps the administrator decide quickly.</p>
    <label>Your petition<textarea name="body" rows="6" minlength="10" maxlength="<?= PETITION_MAX_LEN ?>" required placeholder="For example: the listings in question were removed, the staff member responsible no longer has access, and we now check every listing before posting."></textarea></label>
    <button class="btn">Send petition</button></form>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
