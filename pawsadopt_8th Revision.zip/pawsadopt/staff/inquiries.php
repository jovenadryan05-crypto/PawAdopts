<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!shelter_ready($u)) { flash('info', 'Your shelter must be approved first.'); redirect('staff/dashboard.php'); }
$title = 'Adoption inquiries'; $page = 'inq'; $opt = profile_options();
// UC-12 Process adoption inquiries. Every step is recorded in the timeline and emailed / notified to the adopter.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $msg = trim($_POST['response_message'] ?? '');
    $inq = q('SELECT i.*, p.shelter_id, p.pet_name, p.status AS pet_status, s.shelter_name, a.email AS a_email, a.first_name AS a_first
              FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id JOIN users a ON a.user_id=i.adopter_id
              WHERE i.inquiry_id=?', [$id])->fetch();
    if (!$inq || $inq['shelter_id'] != $u['shelter_id']) { flash('error', 'Inquiry not found.'); redirect('staff/inquiries.php'); }
    $adopter = ['user_id' => $inq['adopter_id'], 'email' => $inq['a_email'], 'first_name' => $inq['a_first']];
    $from = shelter_sender(['shelter_id' => $u['shelter_id'], 'shelter_name' => $inq['shelter_name'], 'logo' => $u['shelter_logo'] ?? null], $u);   // the email shows the shelter's logo and the staff member
    $tell = fn(string $kind, ?string $note = null) => notify_adopter_update($adopter, $inq['pet_name'], $inq['shelter_name'], $kind, $note, $from);
    $pdo = db();
    if ($act === 'rejected' && $inq['status'] === 'pending') {
        q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=? AND status='pending'", [$msg ?: null, $u['user_id'], $id]);
        inquiry_event($id, 'rejected', (int)$u['user_id'], $msg);
        $tell('rejected', $msg ?: null);
        flash('success', 'Response sent to the adopter.');
    } elseif ($act === 'under_review' && $inq['status'] === 'pending') {
        if (q("SELECT 1 FROM inquiry_events WHERE inquiry_id=? AND event_type='under_review'", [$id])->fetch()) flash('info', 'This inquiry is already marked as under review.');
        else { inquiry_event($id, 'under_review', (int)$u['user_id']); $tell('under_review'); flash('success', 'Marked as under review. The adopter was notified.'); }
    } elseif ($act === 'meeting' && in_array($inq['status'], ['pending', 'approved'], true)) {
        $dt = DateTime::createFromFormat('Y-m-d\TH:i', $_POST['meeting_at'] ?? '', new DateTimeZone('Asia/Manila'));
        if (!$dt) flash('error', 'Choose a valid date and time for the meeting.');
        elseif ($dt->getTimestamp() < time() + 300 || $dt->getTimestamp() > time() + 120 * 86400) flash('error', 'The meeting must be at least 5 minutes from now and within 120 days.');
        elseif (!in_array($inq['pet_status'], ['available', 'pending'], true)) flash('error', 'This pet is no longer available, so a meeting cannot be scheduled.');
        else {
            inquiry_event($id, 'meeting_scheduled', (int)$u['user_id'], $msg, $dt->format('Y-m-d H:i:s'));
            $tell('meeting', $dt->format('D, M j \a\t g:i A') . ($msg ? ' - ' . $msg : ''));
            flash('success', 'Meeting scheduled. The adopter was notified.');
        }
    } elseif ($act === 'approved' && $inq['status'] === 'pending') {
        $pdo->beginTransaction();
        try {
            $petStatus = q('SELECT status FROM pets WHERE pet_id=? FOR UPDATE', [$inq['pet_id']])->fetchColumn();
            if ($petStatus !== 'available') { $pdo->rollBack(); flash('error', 'This pet is no longer available (' . $petStatus . '), so the inquiry cannot be approved.'); }
            else {
                q("UPDATE adoption_inquiries SET status='approved', decision='approved', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=? AND status='pending'", [$msg ?: null, $u['user_id'], $id]);
                q("UPDATE pets SET status='pending' WHERE pet_id=?", [$inq['pet_id']]);
                inquiry_event($id, 'approved', (int)$u['user_id'], $msg);
                $pdo->commit();
                $tell('approved', $msg ?: null);
                flash('success', 'Approved. The adopter was notified and the pet is now reserved.');
            }
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($ex->getCode() !== '23000') throw $ex;
            flash('error', 'Another inquiry is already approved for this pet.');
        }
    } elseif ($act === 'adopted' && $inq['status'] === 'approved') {
        $others = q("SELECT a.user_id, a.email, a.first_name FROM adoption_inquiries i JOIN users a ON a.user_id=i.adopter_id WHERE i.pet_id=? AND i.status='pending'", [$inq['pet_id']])->fetchAll();
        $err = set_pet_status((int)$inq['pet_id'], 'adopted');          // also writes the 'adopted' / 'closed_adopted' timeline events
        if (!$err) foreach ($others as $o) notify_adopter_update($o, $inq['pet_name'], $inq['shelter_name'], 'adopted_other', null, $from);
        flash($err ? 'error' : 'success', $err ?: 'Pet marked as adopted. Other pending inquiries were closed and those adopters were emailed. You can now share their success story.');
    } elseif ($act === 'revoke' && $inq['status'] === 'approved' && $inq['pet_status'] === 'pending') {
        q("UPDATE adoption_inquiries SET status='rejected', decision='rejected', response_message=?, responded_by=?, responded_at=NOW() WHERE inquiry_id=?", [$msg ?: 'The shelter has withdrawn its approval.', $u['user_id'], $id]);
        inquiry_event($id, 'approval_revoked', (int)$u['user_id'], $msg ?: 'The shelter has withdrawn its approval.');
        $err = set_pet_status((int)$inq['pet_id'], 'available');
        if (!$err) $tell('revoked', $msg ?: null);
        flash($err ? 'error' : 'success', $err ?: 'Approval revoked. The pet is available again.');
    } else flash('error', 'That inquiry was already handled.');
    redirect('staff/inquiries.php' . (isset($_GET['s']) ? '?s=' . urlencode($_GET['s']) : ''));
}
$filter = $_GET['s'] ?? 'pending';
$valid = ['pending', 'approved', 'rejected', 'withdrawn', 'all'];
if (!in_array($filter, $valid, true)) $filter = 'pending';
$rows = q('SELECT i.*, p.pet_name, p.size, p.needs_yard, p.energy_level, p.experience_needed, p.good_with_pets, p.status AS pet_status, a.first_name, a.last_name, a.email, a.contact_number, a.profile_photo, a.city, a.bio, a.housing_type, a.other_pets, a.pet_experience,
           (SELECT COUNT(*) FROM inquiry_messages m WHERE m.inquiry_id=i.inquiry_id AND m.read_at IS NULL AND m.sender_id=i.adopter_id) AS unread,
           (SELECT COUNT(*) FROM inquiry_messages m WHERE m.inquiry_id=i.inquiry_id) AS msgs,
           (SELECT story_id FROM success_stories st WHERE st.inquiry_id=i.inquiry_id) AS story_id
           FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN users a ON a.user_id=i.adopter_id
           WHERE p.shelter_id=? ' . ($filter === 'all' ? '' : 'AND i.status=?') . ' ORDER BY i.submitted_at DESC',
           $filter === 'all' ? [$u['shelter_id']] : [$u['shelter_id'], $filter])->fetchAll();
$events = inquiry_events_for(array_column($rows, 'inquiry_id'));
include __DIR__ . '/../includes/header.php';
?>
<h1>Adoption inquiries</h1>
<div class="tabs"><?php foreach ($valid as $s): ?><a class="<?= $filter === $s ? 'on' : '' ?>" href="?s=<?= $s ?>"><?= ucfirst($s) ?></a><?php endforeach; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'all' ? '' : e($filter) . ' ' ?>inquiries</h2></div><?php endif; ?>
<?php foreach ($rows as $r): $evs = $events[$r['inquiry_id']] ?? []; $reviewed = in_array('under_review', array_column($evs, 'event_type'), true); ?>
<article class="panel inq">
  <div class="split"><h2><?= e($r['pet_name']) ?> <span class="muted small">from <?= e($r['first_name'] . ' ' . $r['last_name']) ?></span></h2><?= badge($r['status']) ?></div>
  <p class="small muted"><?= e($r['email']) ?> &middot; <?= e($r['contact_number']) ?> &middot; sent <?= fdate($r['submitted_at']) ?> &middot; pet is <?= e($r['pet_status']) ?></p>
  <?php if ($r['city'] || $r['bio'] || $r['housing_type'] || $r['other_pets'] || $r['pet_experience'] || $r['profile_photo']): ?>
  <div class="about"><?= avatar($r) ?><div>
    <?php if ($r['city']): ?><p><strong>City:</strong> <?= e($r['city']) ?></p><?php endif; ?>
    <?php if ($r['housing_type']): ?><p><strong>Home:</strong> <?= e($opt['housing'][$r['housing_type']] ?? '') ?></p><?php endif; ?>
    <?php if ($r['other_pets']): ?><p><strong>Other pets:</strong> <?= e($r['other_pets']) ?></p><?php endif; ?>
    <?php if ($r['pet_experience']): ?><p><strong>Experience:</strong> <?= e($opt['experience'][$r['pet_experience']] ?? '') ?></p><?php endif; ?>
    <?php if ($r['bio']): ?><p class="muted"><?= nl2br(e($r['bio'])) ?></p><?php endif; ?>
  </div></div>
  <?php endif; ?>
  <?php $rd = readiness_rows($r['readiness']); $rf = readiness_flags($r['readiness']); $mt = pet_match($r, $r); ?>
  <?php if ($rd || $mt): ?>
  <div class="ready-box"><h3>Home-readiness checklist <?= match_badge($mt) ?></h3>
    <?php if ($rd): ?><dl class="ready"><?php foreach ($rd as $k => $v): ?><div><dt><?= e($k) ?></dt><dd><?= e($v) ?></dd></div><?php endforeach; ?></dl><?php else: ?><p class="muted small">This inquiry was sent before the checklist existed.</p><?php endif; ?>
    <?php if ($rf): ?><p class="small warn-text"><strong>Worth a look:</strong> <?= e(implode('; ', $rf)) ?>.</p><?php endif; ?>
    <?php if ($mt && ($mt['reasons'] || $mt['cautions'])): ?><ul class="reasons small"><?php foreach ($mt['reasons'] as $x): ?><li class="yes"><?= e($x) ?></li><?php endforeach; ?><?php foreach ($mt['cautions'] as $x): ?><li class="warn"><?= e($x) ?></li><?php endforeach; ?></ul><?php endif; ?>
  </div>
  <?php endif; ?>
  <p class="quote"><?= nl2br(e($r['message'])) ?></p>
  <?php if ($r['responded_at']): ?><div class="reply"><strong>Response (<?= fdate($r['responded_at']) ?>)</strong><p><?= nl2br(e($r['response_message'] ?: 'No message.')) ?></p></div><?php endif; ?>
  <h3>Timeline</h3><?= render_timeline($evs) ?>
  <p><a class="btn btn-ghost btn-sm" href="<?= url('chat.php?inquiry=' . $r['inquiry_id']) ?>"><?= $r['msgs'] ? 'Open conversation' : 'Start a conversation' ?><?= count_badge((int)$r['unread']) ?></a>
  <?php if ($r['status'] === 'approved' && $r['pet_status'] === 'adopted'): ?> <a class="btn btn-ghost btn-sm" href="<?= url('staff/stories.php?inquiry=' . $r['inquiry_id']) ?>"><?= $r['story_id'] ? 'Edit success story' : 'Share their success story' ?></a><?php endif; ?></p>
  <?php if (in_array($r['status'], ['pending', 'approved'], true) && in_array($r['pet_status'], ['available', 'pending'], true)): ?>
  <details class="more"><summary>Schedule a meeting</summary>
    <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>"><input type="hidden" name="action" value="meeting">
      <div class="two"><label>Date and time (Philippine time)<input type="datetime-local" name="meeting_at" required></label>
      <label>Note (place, what to bring)<input name="response_message" maxlength="200"></label></div>
      <button class="btn btn-sm">Schedule and notify the adopter</button>
    </form>
  </details>
  <?php endif; ?>
  <?php if ($r['status'] === 'pending'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <label>Message to adopter (optional, also emailed)<textarea name="response_message" rows="3" maxlength="1000" placeholder="Next steps, a meeting time, or why it is not a fit."></textarea></label>
    <div class="actions">
      <?php if (!$reviewed): ?><button class="btn btn-ghost" name="action" value="under_review">Mark as under review</button><?php endif; ?>
      <?php if ($r['pet_status'] === 'available'): ?><button class="btn" name="action" value="approved">Approve</button>
      <?php else: ?><span class="muted small">This pet is not available, so this inquiry can only be rejected.</span><?php endif; ?>
      <button class="btn btn-danger" name="action" value="rejected" data-confirm="Reject this inquiry?">Reject</button></div>
  </form>
  <?php elseif ($r['status'] === 'approved' && $r['pet_status'] === 'pending'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['inquiry_id'] ?>">
    <label>Optional note (used if you revoke)<input name="response_message" maxlength="200"></label>
    <div class="actions"><button class="btn btn-ghost" name="action" value="adopted" data-confirm="Mark this pet as adopted? Other pending inquiries will be closed.">Mark pet as adopted</button>
    <button class="btn btn-danger" name="action" value="revoke" data-confirm="Revoke this approval and make the pet available again?">Revoke approval</button></div>
  </form>
  <?php endif; ?>
</article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
