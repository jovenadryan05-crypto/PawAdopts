<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$u = require_role('staff');
if (!$u['shelter_id'] || empty($u['is_shelter_admin'])) { http_response_code(403); exit('403: only the shelter administrator can manage employee accounts.'); }
$title = 'Shelter team'; $page = 'team'; $errors = []; $sid = (int)$u['shelter_id'];
// Employees cannot register themselves. The shelter administrator creates each account here and hands over the credentials.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    if ($act === 'create') {
        $f = fn($k) => trim($_POST[$k] ?? '');
        $first = clean_name($f('first_name')); $last = clean_name($f('last_name')); $email = strtolower($f('email')); $phone = ph_mobile($f('contact_number')); $pos = $f('position');
        if (rate_blocked('team:create:' . $u['user_id'], 20, 3600)) $errors[] = 'You created several accounts recently. Please wait a while.';
        if ($err = name_error('First name', $first)) $errors[] = $err;
        if ($err = name_error('Last name', $last)) $errors[] = $err;
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address for the employee.';
        if (!$phone) $errors[] = 'Enter the employee\'s Philippine mobile number (11 digits starting with 09).';
        if (str_len($pos) > 80) $errors[] = 'Job title must be 80 characters or fewer.';
        if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) $errors[] = 'That email is already registered.';
        if (!$errors) {
            $pw = temp_password();
            q('INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role,shelter_id,position,must_change_password,created_by) VALUES (?,?,?,?,?,?,?,?,1,?)',
              [$first, $last, $email, password_hash($pw, PASSWORD_DEFAULT), $phone, 'staff', $sid, $pos ?: 'Shelter staff', $u['user_id']]);
            rate_hit('team:create:' . $u['user_id']);
            $_SESSION['new_credentials'] = ['name' => $first . ' ' . $last, 'email' => $email, 'password' => $pw];   // shown once, never stored in plain text
            redirect('staff/team.php');
        }
    } else {
        $target = q("SELECT * FROM users WHERE user_id = ? AND shelter_id = ? AND role = 'staff' AND is_shelter_admin = 0 AND account_status <> 'deleted'", [(int)($_POST['id'] ?? 0), $sid])->fetch();
        if (!$target) flash('error', 'That employee was not found in your shelter.');
        elseif ($act === 'reset') {
            $pw = temp_password(); set_password((int)$target['user_id'], $pw, true); bump_session((int)$target['user_id']);
            $_SESSION['new_credentials'] = ['name' => $target['first_name'] . ' ' . $target['last_name'], 'email' => $target['email'], 'password' => $pw, 'reset' => true];
        } elseif ($act === 'deactivate' || $act === 'activate') {
            q('UPDATE users SET account_status = ? WHERE user_id = ?', [$act === 'deactivate' ? 'suspended' : 'active', $target['user_id']]);
            flash('success', $target['first_name'] . '\'s account ' . ($act === 'deactivate' ? 'is deactivated and cannot log in.' : 'is active again.'));
        }
        redirect('staff/team.php');
    }
}
$cred = $_SESSION['new_credentials'] ?? null; unset($_SESSION['new_credentials']);
$team = q("SELECT * FROM users WHERE shelter_id = ? AND role = 'staff' AND account_status <> 'deleted' ORDER BY is_shelter_admin DESC, created_at", [$sid])->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Shelter team</h1>
<p class="muted">You are the administrator of <strong><?= e($u['shelter_name']) ?></strong>. Create an account for each employee who should handle pets, inquiries and posts, then give them their login credentials. Employees are asked to set their own password at first login.</p>
<?php if ($cred): ?>
<div class="panel credentials" role="alert">
  <h2><?= !empty($cred['reset']) ? 'New temporary password' : 'Account created' ?> for <?= e($cred['name']) ?></h2>
  <p>Give these credentials to the employee. <strong>The password is shown only once</strong> and is not stored anywhere readable.</p>
  <dl class="facts"><div><dt>Email (username)</dt><dd><?= e($cred['email']) ?></dd></div><div><dt>Temporary password</dt><dd><code class="pw"><?= e($cred['password']) ?></code></dd></div></dl>
  <p class="small muted">They log in at <?= e(SITE_URL . '/login.php') ?>, accept the Terms, and choose a new password.</p>
</div>
<?php endif; ?>
<?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
<div class="cols">
  <form method="post" class="stack panel"><?= csrf_field() ?><input type="hidden" name="action" value="create"><h2>Add an employee</h2>
    <div class="two"><label>First name<input name="first_name" value="<?= old('first_name') ?>" data-name maxlength="60" required></label>
    <label>Last name<input name="last_name" value="<?= old('last_name') ?>" data-name maxlength="60" required></label></div>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required></label>
    <label>Mobile number<input type="tel" name="contact_number" value="<?= old('contact_number') ?>" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="09XXXXXXXXX" data-ph required></label>
    <label>Job title (optional)<input name="position" value="<?= old('position') ?>" maxlength="80" placeholder="e.g. Adoption coordinator"></label>
    <button class="btn">Create account and generate password</button>
  </form>
  <div>
    <h2>Your team</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Name</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>
      <?php foreach ($team as $m): ?>
      <tr><td class="who"><?= avatar($m, 'sm') ?><span><?= e($m['first_name'] . ' ' . $m['last_name']) ?><br><span class="small muted"><?= e($m['email']) ?></span></span></td>
        <td><?= $m['is_shelter_admin'] ? '<span class="badge b-approved">Administrator</span>' : e($m['position'] ?: 'Staff') ?></td>
        <td><?= badge($m['account_status']) ?><?= $m['must_change_password'] ? ' <span class="small muted">temp password</span>' : '' ?></td>
        <td class="row-actions"><?php if (!$m['is_shelter_admin']): ?>
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $m['user_id'] ?>">
            <button class="btn btn-sm btn-ghost" name="action" value="reset" data-confirm="Generate a new temporary password? Their current password stops working.">New password</button>
            <?php if ($m['account_status'] === 'active'): ?><button class="btn btn-sm btn-danger" name="action" value="deactivate" data-confirm="Deactivate this account? They will no longer be able to log in.">Deactivate</button>
            <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="activate">Reactivate</button><?php endif; ?></form>
        <?php endif; ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
