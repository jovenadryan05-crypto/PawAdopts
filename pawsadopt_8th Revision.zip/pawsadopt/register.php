<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
if (user()) redirect(home_for(user()));
$title = 'Create account'; $errors = [];
// UC-01 Register account. Two kinds of sign-up:
//   - an ADOPTER registers themselves;
//   - a SHELTER registers its organisation (the shelter administrator account is created with it). Employees cannot sign up on their
//     own: the shelter administrator creates their accounts and hands them the credentials (staff/team.php).
// Admin accounts are created by the system.
// The first screen asks WHICH of the two the person is (register.php without ?as=); the form that follows only contains the fields for that choice,
// so an adopter never sees (or can fill in) the shelter fields, and a shelter cannot be created by accident.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_switch'])) captcha_new($_POST['captcha_switch'] === 'text' ? 'text' : 'image');
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = fn($k) => trim($_POST[$k] ?? '');
    $captchaOk = captcha_check($_POST['captcha'] ?? '');
    $role = $f('role'); $email = strtolower($f('email')); $phone = ph_mobile($f('contact_number'));
    $first = clean_name($f('first_name')); $last = clean_name($f('last_name'));
    $isShelter = $role === 'shelter';
    if (rate_blocked('register:ip:' . client_ip(), 5, 3600)) $errors[] = 'Too many sign-ups from this connection. Please try again later.';
    if (!$captchaOk) $errors[] = 'The security check was not correct. Please try the new one.';
    if (!in_array($role, ['adopter', 'shelter'], true)) $errors[] = 'Choose whether you are registering as an adopter or as a shelter.';
    if ($err = name_error('First name', $first)) $errors[] = $err;
    if ($err = name_error('Last name', $last)) $errors[] = $err;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!$phone) $errors[] = 'Contact number must be a Philippine mobile number: 11 digits starting with 09 (e.g. 09171234567).';
    if ($err = password_error($_POST['password'] ?? '')) $errors[] = $err;
    elseif ($err = password_context_error($_POST['password'] ?? '', ['first_name' => $first, 'last_name' => $last, 'email' => $email])) $errors[] = $err;
    elseif (($_POST['password'] ?? '') !== ($_POST['confirm'] ?? '')) $errors[] = 'Passwords do not match.';
    $sh = ['name' => $f('shelter_name'), 'address' => $f('address'), 'city' => $f('city'), 'province' => $f('province'), 'email' => $f('shelter_email'), 'phone' => ph_contact($f('shelter_number'))];
    if ($isShelter) {
        [$lat, $lng, $pinErr] = pin_from_post($_POST['pin'] ?? '');
        if ($pinErr) $errors[] = $pinErr; elseif ($lat === null) $errors[] = 'Set the exact map pin of your shelter, so adopters can find you.';
        if ($sh['name'] === '' || $sh['address'] === '') $errors[] = 'Shelter name and street address are required.';
        if (str_len($sh['name']) > 120) $errors[] = 'Shelter name must be 120 characters or fewer.';
        if ($sh['city'] === '' || $sh['province'] === '') $errors[] = 'City and province are required, so adopters can find your pets by location.';
        if (str_len($sh['city']) > 80 || str_len($sh['province']) > 80) $errors[] = 'City and province must be 80 characters or fewer.';
        if (!filter_var($sh['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid shelter contact email.';
        if (!$sh['phone']) $errors[] = 'Enter a Philippine mobile number (09XXXXXXXXX) or a landline with area code for the shelter.';
        if (empty($_FILES['document']['name'])) $errors[] = 'Upload a verification document (business permit, registration or similar).';
    }
    if (empty($_POST['adult'])) $errors[] = 'You must confirm that you are 18 years old or above.';
    if (empty($_POST['agree'])) $errors[] = 'You must accept the Terms and Conditions and the Privacy Notice.';
    if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) $errors[] = 'That email is already registered.';
    $doc = null;
    if (!$errors && $isShelter) { $doc = save_upload($_FILES['document'] ?? [], 'docs', true); if (!$doc) $errors[] = 'The verification document could not be saved. Use a PDF, JPG or PNG under 5 MB.'; }
    if (!$errors) {
        $pdo = db(); $pdo->beginTransaction();
        try {
            $shelterId = null;
            if ($isShelter) {
                q('INSERT INTO shelters (shelter_name,address,city,province,latitude,longitude,contact_email,contact_number,verification_documents,invite_code) VALUES (?,?,?,?,?,?,?,?,?,?)',
                  [$sh['name'], $sh['address'], $sh['city'], $sh['province'], $lat, $lng, $sh['email'], $sh['phone'], $doc, strtoupper(bin2hex(random_bytes(4)))]);
                $shelterId = (int)$pdo->lastInsertId();
            }
            q('INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role,shelter_id,is_shelter_admin,position,consent_at,terms_version) VALUES (?,?,?,?,?,?,?,?,?,NOW(),?)',
              [$first, $last, $email, password_hash($_POST['password'], PASSWORD_DEFAULT), $phone, $isShelter ? 'staff' : 'adopter', $shelterId, $isShelter ? 1 : 0, $isShelter ? 'Shelter administrator' : null, TERMS_VERSION]);
            $pdo->commit();
        } catch (Throwable $t) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $t; }
        rate_hit('register:ip:' . client_ip());
        if ($isShelter) {
            notify_users(admin_ids(), 'shelter_review', 'New shelter awaiting review', $sh['name'], 'admin/shelters.php');
            flash('success', 'Shelter registered. An administrator will review your document. Log in to create accounts for your employees.');
        } else flash('success', 'Account created. Log in, then verify your email so you can send inquiries.');
        redirect('login.php');
    }
}
$curRole = $_POST['role'] ?? ($_GET['as'] ?? '');
$curRole = in_array($curRole, ['adopter', 'shelter'], true) ? $curRole : '';       // '' = nothing chosen yet: show the two choices first
$isShelterForm = $curRole === 'shelter';
include __DIR__ . '/includes/header.php';
?>
<?php if ($curRole === ''): ?>
<div class="auth">
  <h1>Create your account</h1>
  <?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
  <p class="muted">First, tell us who you are. Each kind of account has its own sign-up.</p>
  <div class="role-choice">
    <a class="role-card" href="<?= url('register.php?as=adopter') ?>">
      <span class="role-icon"><?= icon('dog') ?></span>
      <h2>I want to adopt a pet</h2>
      <p>Browse animals from verified shelters, send adoption inquiries and chat with the shelter.</p>
      <span class="btn">Sign up as an adopter</span>
    </a>
    <a class="role-card" href="<?= url('register.php?as=shelter') ?>">
      <span class="role-icon"><?= icon('building-2') ?></span>
      <h2>I represent an animal shelter</h2>
      <p>Register your organisation with a verification document. An administrator reviews it before you can list pets.</p>
      <span class="btn btn-ghost">Register a shelter</span>
    </a>
  </div>
  <p class="muted">Already registered? <a href="<?= url('login.php') ?>">Log in</a>. Shelter employee? Ask your shelter administrator for your login credentials; employees cannot sign up on their own.</p>
</div>
<?php else: ?>
<div class="auth">
  <p class="small"><a href="<?= url('register.php') ?>">&larr; Not what you meant? Choose again</a></p>
  <h1><?= $isShelterForm ? 'Register your shelter' : 'Create your adopter account' ?></h1>
  <p><span class="badge <?= $isShelterForm ? 'b-announcement' : 'b-approved' ?>">Registering as <?= $isShelterForm ? 'a shelter' : 'an adopter' ?></span></p>
  <?php foreach ($errors as $er): ?><div class="flash flash-error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" enctype="multipart/form-data" class="stack" data-match="password,confirm" data-validate><?= csrf_field() ?>
    <input type="hidden" name="role" value="<?= e($curRole) ?>">
    <?php if ($isShelterForm): ?>
    <div class="flash flash-info">You become the shelter's <strong>administrator</strong>. Employees cannot sign up on their own: after approval, <strong>you</strong> create each employee's account and give them their login credentials.</div>
    <h2 class="sec">Your details (shelter administrator)</h2>
    <?php endif; ?>
    <div class="two"><label>First name<input name="first_name" value="<?= old('first_name') ?>" data-name pattern="[A-Za-z&#192;-&#255;&#209;&#241;][A-Za-z&#192;-&#255;&#209;&#241;\s'.\-]*" maxlength="60" title="Letters only (spaces, hyphens, apostrophes and periods are allowed)" required></label>
    <label>Last name<input name="last_name" value="<?= old('last_name') ?>" data-name pattern="[A-Za-z&#192;-&#255;&#209;&#241;][A-Za-z&#192;-&#255;&#209;&#241;\s'.\-]*" maxlength="60" title="Letters only (spaces, hyphens, apostrophes and periods are allowed)" required></label></div>
    <label>Email<input type="email" name="email" value="<?= old('email') ?>" required></label>
    <label>Mobile number<input type="tel" name="contact_number" value="<?= old('contact_number') ?>" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="09XXXXXXXXX" title="11 digits, starting with 09" data-ph required>
      <span class="hint">Philippine mobile number: 11 digits, starting with 09.</span></label>
    <div class="two"><label>Password<input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><span class="hint">8+ characters with a letter and a number.</span></label>
    <label>Confirm password<input type="password" name="confirm" minlength="8" maxlength="72" autocomplete="new-password" required></label></div>

    <?php if ($isShelterForm): ?>
    <div class="stack">
      <h2 class="sec">Your shelter</h2>
      <label>Shelter name<input name="shelter_name" value="<?= old('shelter_name') ?>" maxlength="120" required></label>
      <label>Street address<input name="address" value="<?= old('address') ?>" required></label>
      <div class="two"><label>City or municipality<input name="city" maxlength="80" value="<?= old('city') ?>" required></label>
      <label>Province<input name="province" maxlength="80" value="<?= old('province') ?>" required></label></div>
      <?= pin_field($_POST['pin'] ?? '') ?>
      <div class="two"><label>Shelter contact email<input type="email" name="shelter_email" value="<?= old('shelter_email') ?>" required></label>
      <label>Shelter contact number<input type="tel" name="shelter_number" value="<?= old('shelter_number') ?>" inputmode="numeric" maxlength="13" placeholder="09XXXXXXXXX" required><span class="hint">Mobile or landline with area code.</span></label></div>
      <label>Verification document (PDF, JPG, PNG; max 5 MB)<input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png,.webp" required><span class="hint">Business permit, registration or similar. Only administrators can see it.</span></label>
    </div>
    <?php endif; ?>

    <label class="check"><input type="checkbox" name="adult" value="1" <?= !empty($_POST['adult']) ? 'checked' : '' ?> required> I am 18 years old or above.</label>
    <label class="check"><input type="checkbox" name="agree" value="1" <?= !empty($_POST['agree']) ? 'checked' : '' ?> required> <span>I have read and agree to the <a href="<?= url('terms.php') ?>" target="_blank" rel="noopener">Terms and Conditions</a> and the <a href="<?= url('privacy.php') ?>" target="_blank" rel="noopener">Privacy Notice</a>.</span></label>
    <?= captcha_widget() ?>
    <button class="btn"><?= $isShelterForm ? 'Submit shelter for review' : 'Create account' ?></button>
    <?= captcha_switch_button() ?>
  </form>
  <p class="muted">Already registered? <a href="<?= url('login.php') ?>">Log in</a>.</p>
</div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
