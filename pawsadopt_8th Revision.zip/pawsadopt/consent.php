<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_login();
if (($u['terms_version'] ?? null) === TERMS_VERSION) redirect(home_for($u));
$title = 'Terms and Privacy'; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['agree'])) $error = 'You need to accept the Terms and Privacy Notice to continue using PawsAdopt.';
    else {
        q('UPDATE users SET consent_at = NOW(), terms_version = ? WHERE user_id = ?', [TERMS_VERSION, $u['user_id']]);
        flash('success', 'Thank you. Your acceptance has been recorded.');
        redirect(home_for($u));
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Before you continue</h1>
  <p>We have <?= $u['terms_version'] ? 'updated' : 'added' ?> our Terms and Conditions and Privacy Notice (Data Privacy Act, RA 10173). Please review them and accept to keep using PawsAdopt.</p>
  <p><a href="<?= url('terms.php') ?>" target="_blank" rel="noopener">Read the Terms and Conditions</a><br><a href="<?= url('privacy.php') ?>" target="_blank" rel="noopener">Read the Privacy Notice</a></p>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <label class="check"><input type="checkbox" name="agree" value="1" required> I have read and agree to the Terms and Conditions and the Privacy Notice.</label>
    <button class="btn">Accept and continue</button>
  </form>
  <form method="post" action="<?= url('logout.php') ?>"><?= csrf_field() ?><button class="linklike dark">Log out instead</button></form>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
