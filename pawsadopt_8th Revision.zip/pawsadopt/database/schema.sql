-- PawsAdopt schema (6 tables, one per DFD data store D1-D6)
DROP DATABASE IF EXISTS pawsadopt;
CREATE DATABASE pawsadopt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pawsadopt;

-- D1 USERS (shelter_id FK is added after SHELTERS exists: users <-> shelters is circular)
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id     INT NULL COMMENT 'NULL, staff only',
  first_name     VARCHAR(60)  NOT NULL,
  last_name      VARCHAR(60)  NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  contact_number VARCHAR(30)  NOT NULL,
  role           ENUM('adopter','staff','admin') NOT NULL,
  account_status ENUM('active','suspended','deleted') NOT NULL DEFAULT 'active',
  profile_photo  VARCHAR(255) NULL,
  bio            VARCHAR(500) NULL,
  city           VARCHAR(80)  NULL,
  `position`     VARCHAR(80)  NULL COMMENT 'staff job title',
  housing_type   ENUM('house_owned','house_rented','apartment','condo','other') NULL,
  other_pets     VARCHAR(150) NULL,
  pet_experience ENUM('first_time','some','experienced') NULL,
  consent_at     DATETIME NULL COMMENT 'when the user accepted Terms + Privacy Notice',
  terms_version  VARCHAR(20) NULL,
  email_verified_at DATETIME NULL,
  pending_email  VARCHAR(150) NULL COMMENT 'new email waiting for its confirmation codes (profile security)',
  pending_email_at DATETIME NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  session_version INT NOT NULL DEFAULT 1 COMMENT 'bumped on password change to log out other sessions',
  is_shelter_admin TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 = registered the shelter; creates employee accounts',
  created_by     INT NULL COMMENT 'shelter admin who created this employee account',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- D2 SHELTERS
CREATE TABLE shelters (
  shelter_id             INT AUTO_INCREMENT PRIMARY KEY,
  shelter_name           VARCHAR(120) NOT NULL,
  address                VARCHAR(255) NOT NULL,
  contact_email          VARCHAR(150) NOT NULL,
  contact_number         VARCHAR(30)  NOT NULL,
  verification_documents VARCHAR(255) NOT NULL,
  verification_status    ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  account_status         ENUM('active','suspended') NOT NULL DEFAULT 'active',
  reviewed_by            INT NULL COMMENT 'NULL until reviewed',
  reviewed_at            DATETIME NULL,
  rejection_reason       VARCHAR(255) NULL,
  city                   VARCHAR(80) NULL,
  province               VARCHAR(80) NULL,
  latitude               DECIMAL(9,6) NULL COMMENT 'exact pin set by the shelter administrator',
  longitude              DECIMAL(9,6) NULL,
  suspension_reason      VARCHAR(255) NULL,
  suspended_at           DATETIME NULL,
  invite_code            CHAR(8) NULL UNIQUE COMMENT 'legacy (batch 1-4); employees are now created by the shelter admin',
  logo                   VARCHAR(255) NULL,
  about                  TEXT NULL,
  created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_shelter_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE users ADD CONSTRAINT fk_user_shelter
  FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE SET NULL;

-- D3 PETS
CREATE TABLE pets (
  pet_id      INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id  INT NOT NULL,
  listed_by   INT NOT NULL,
  pet_name    VARCHAR(80) NOT NULL,
  species     VARCHAR(40) NOT NULL,
  breed       VARCHAR(80) NULL,
  sex         ENUM('male','female','unknown') NOT NULL DEFAULT 'unknown',
  age_months  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  description TEXT NULL,
  size        ENUM('small','medium','large') NULL,
  vaccinated     ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  neutered       ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  good_with_kids ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  good_with_pets    ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  needs_yard        ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  energy_level      ENUM('low','medium','high') NULL,
  experience_needed ENUM('first_time','some','experienced') NULL,
  status      ENUM('draft','available','pending','adopted','removed') NOT NULL DEFAULT 'available' COMMENT 'draft = no photo yet, not public',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pet_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_pet_user    FOREIGN KEY (listed_by)  REFERENCES users(user_id)       ON DELETE RESTRICT,
  INDEX idx_pet_search (status, species)
) ENGINE=InnoDB;

-- D4 PET_PHOTOS
CREATE TABLE pet_photos (
  photo_id    INT AUTO_INCREMENT PRIMARY KEY,
  pet_id      INT NOT NULL,
  photo_url   VARCHAR(255) NOT NULL,
  is_primary  TINYINT(1) NOT NULL DEFAULT 0,
  content_hash CHAR(40) NULL,
  uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_photo_hash (content_hash),
  CONSTRAINT fk_photo_pet FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- D5 ADOPTION_INQUIRIES (the response fields live here, per the ERD)
CREATE TABLE adoption_inquiries (
  inquiry_id       INT AUTO_INCREMENT PRIMARY KEY,
  pet_id           INT NOT NULL,
  adopter_id       INT NOT NULL,
  message          TEXT NOT NULL,
  status           ENUM('pending','approved','rejected','withdrawn') NOT NULL DEFAULT 'pending',
  submitted_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  responded_by     INT NULL COMMENT 'NULL until responded',
  decision         ENUM('approved','rejected') NULL,
  response_message TEXT NULL,
  responded_at     DATETIME NULL,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  -- DB-level guards: one active inquiry per adopter+pet, and only one approved inquiry per pet
  active_key       VARCHAR(30) AS (IF(status IN ('pending','approved'), CONCAT(pet_id,'-',adopter_id), NULL)) VIRTUAL,
  approved_key     INT AS (IF(status = 'approved', pet_id, NULL)) VIRTUAL,
  chat_locked        TINYINT(1) NOT NULL DEFAULT 0,
  chat_reported_at   DATETIME NULL,
  chat_reported_by   INT NULL,
  chat_report_reason VARCHAR(200) NULL,
  readiness          TEXT NULL COMMENT 'JSON snapshot of the adopter readiness checklist',
  no_response_flagged_at DATETIME NULL COMMENT 'set once, when all three check-ins went unanswered',
  UNIQUE KEY uq_active_inquiry (active_key),
  UNIQUE KEY uq_one_approved (approved_key),
  CONSTRAINT fk_inq_pet     FOREIGN KEY (pet_id)       REFERENCES pets(pet_id)   ON DELETE CASCADE,
  CONSTRAINT fk_inq_adopter FOREIGN KEY (adopter_id)   REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_inq_staff   FOREIGN KEY (responded_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- D7 INQUIRY_MESSAGES (conversation between adopter and shelter about an inquiry)
CREATE TABLE inquiry_messages (
  message_id INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  sender_id  INT NOT NULL,
  body       VARCHAR(1000) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at    DATETIME NULL COMMENT 'set when the other side opens the conversation',
  CONSTRAINT fk_msg_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_sender  FOREIGN KEY (sender_id)  REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_msg_thread (inquiry_id, message_id),
  INDEX idx_msg_unread (inquiry_id, read_at)
) ENGINE=InnoDB;

-- D8 INQUIRY_EVENTS (adoption timeline; inquiries.status is deliberately left alone)
CREATE TABLE inquiry_events (
  event_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  event_type ENUM('submitted','under_review','approved','rejected','approval_revoked','withdrawn','meeting_scheduled','adopted','closed_adopted','closed_removed') NOT NULL,
  actor_id   INT NULL,
  note       VARCHAR(255) NULL,
  meeting_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_event_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_event_actor   FOREIGN KEY (actor_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_event_inquiry (inquiry_id, event_id)
) ENGINE=InnoDB;

-- D6 ANNOUNCEMENTS_DONATIONS
CREATE TABLE announcements_donations (
  post_id       INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id    INT NOT NULL,
  posted_by     INT NOT NULL,
  post_type     ENUM('announcement','donation') NOT NULL,
  title         VARCHAR(150) NOT NULL,
  content       TEXT NOT NULL,
  target_amount DECIMAL(12,2) NULL,
  status        ENUM('published','closed','hidden') NOT NULL DEFAULT 'published',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_post_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_post_user    FOREIGN KEY (posted_by)  REFERENCES users(user_id)       ON DELETE RESTRICT
) ENGINE=InnoDB;

-- D9 SUCCESS_STORIES (public only with the adopter's explicit consent)
CREATE TABLE success_stories (
  story_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL UNIQUE,
  shelter_id INT NOT NULL,
  posted_by  INT NOT NULL,
  title      VARCHAR(150) NOT NULL,
  body       TEXT NOT NULL,
  consent    ENUM('requested','full','anonymous','declined') NOT NULL DEFAULT 'requested' COMMENT 'full = name and photo, anonymous = story only',
  consent_at DATETIME NULL,
  status     ENUM('published','hidden') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_story_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_story_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_story_author  FOREIGN KEY (posted_by)  REFERENCES users(user_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Support tables (not part of the 6 DFD data stores: security and audit infrastructure)
CREATE TABLE rate_limits (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  bucket     VARCHAR(190) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bucket_time (bucket, created_at)
) ENGINE=InnoDB;

CREATE TABLE password_resets (
  reset_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  purpose    ENUM('reset','verify','admin_login','pw_change','email_old','email_new') NOT NULL DEFAULT 'reset',
  code_hash  VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts   TINYINT NOT NULL DEFAULT 0,
  used_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
  notification_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  type       VARCHAR(30)  NOT NULL,
  title      VARCHAR(120) NOT NULL,
  body       VARCHAR(255) NULL,
  link       VARCHAR(200) NULL,
  read_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, read_at, notification_id)
) ENGINE=InnoDB;

CREATE TABLE admin_audit_log (
  log_id      INT AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT NULL,
  action      VARCHAR(60) NOT NULL,
  target_type VARCHAR(40) NOT NULL,
  target_id   INT NULL,
  details     VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_audit_time (created_at)
) ENGINE=InnoDB;

-- Batch 5 tables
CREATE TABLE adopter_readiness (
  user_id            INT PRIMARY KEY,
  landlord_permission ENUM('own_home','yes_written','yes_verbal','not_yet','no') NOT NULL,
  monthly_budget     ENUM('under_1000','1000_3000','3000_5000','over_5000') NOT NULL,
  caregiver          ENUM('me','family','shared','someone_else') NOT NULL,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ready_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE adoption_followups (
  followup_id  INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id   INT NOT NULL,
  milestone    ENUM('1_week','1_month','3_months') NOT NULL,
  due_at       DATETIME NOT NULL,
  notified_at  DATETIME NULL COMMENT 'in-app reminder created',
  emailed_at   DATETIME NULL COMMENT 'email reminder sent',
  submitted_at DATETIME NULL,
  wellbeing    ENUM('thriving','good','adjusting','struggling') NULL,
  notes        VARCHAR(1000) NULL,
  photo        VARCHAR(255) NULL,
  share_ok     TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'adopter allows notes + photo on the public Success Stories page',
  UNIQUE KEY uq_followup (inquiry_id, milestone),
  INDEX idx_followup_due (due_at, submitted_at),
  CONSTRAINT fk_followup_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE password_history (
  history_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pwh_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_pwh_user (user_id, history_id)
) ENGINE=InnoDB;

-- Batch 6 tables
-- 2. Welfare checks: what a shelter did after an adopter ignored all three check-ins (call / visit / message)
CREATE TABLE IF NOT EXISTS welfare_checks (
  check_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  staff_id   INT NULL,
  method     ENUM('call','visit','message') NOT NULL,
  outcome    ENUM('ok','needs_help','unreachable','returned') NOT NULL,
  note       VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_wc_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_wc_staff   FOREIGN KEY (staff_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_wc_inquiry (inquiry_id, check_id)
) ENGINE=InnoDB;

-- 3. Reactivation petitions: a suspended shelter asks the administrators to lift the suspension; both sides can send messages
CREATE TABLE IF NOT EXISTS shelter_petitions (
  petition_id  INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id   INT NOT NULL,
  opened_by    INT NULL,
  suspension_reason VARCHAR(255) NULL COMMENT 'snapshot of the reason when the petition was opened',
  status       ENUM('open','approved','denied') NOT NULL DEFAULT 'open',
  resolved_by  INT NULL,
  resolved_at  DATETIME NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  open_key     INT AS (IF(status = 'open', shelter_id, NULL)) VIRTUAL,
  UNIQUE KEY uq_one_open_petition (open_key),
  CONSTRAINT fk_petition_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_petition_opener   FOREIGN KEY (opened_by)  REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_petition_resolver FOREIGN KEY (resolved_by) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_petition_status (status, created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS shelter_petition_messages (
  message_id  INT AUTO_INCREMENT PRIMARY KEY,
  petition_id INT NOT NULL,
  sender_id   INT NULL,
  sender_side ENUM('shelter','admin') NOT NULL,
  body        VARCHAR(1500) NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pm_petition FOREIGN KEY (petition_id) REFERENCES shelter_petitions(petition_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_sender   FOREIGN KEY (sender_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_pm_thread (petition_id, message_id)
) ENGINE=InnoDB;

-- Default administrator (change this password after first login)
-- email: admin@pawsadopt.local   password: Admin@12345
INSERT INTO users (first_name,last_name,email,password_hash,contact_number,role,must_change_password)
VALUES ('System','Admin','admin@pawsadopt.local','$2y$10$HEZtbE8PQ5Tn/6bXMEcAY.1DvrTzw9MsodnMSiA7bSiWxMyhrHgQ.','09000000000','admin',1);
