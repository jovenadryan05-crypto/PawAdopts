-- Batch 3: conversations between adopter and shelter about an inquiry. Run ONCE (safe to re-run on MariaDB/XAMPP).
USE pawsadopt;

CREATE TABLE IF NOT EXISTS inquiry_messages (
  message_id INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  sender_id  INT NOT NULL,
  body       VARCHAR(1000) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at    DATETIME NULL COMMENT 'set when the other side opens the conversation',
  CONSTRAINT fk_msg_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_sender  FOREIGN KEY (sender_id)  REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_msg_thread (inquiry_id, message_id),
  INDEX idx_msg_unread (inquiry_id, read_at)
) ENGINE=InnoDB;

-- Moderation: a participant can report a conversation; an administrator may then read it (read-only) and lock it.
ALTER TABLE adoption_inquiries
  ADD COLUMN IF NOT EXISTS chat_locked        TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS chat_reported_at   DATETIME NULL,
  ADD COLUMN IF NOT EXISTS chat_reported_by   INT NULL,
  ADD COLUMN IF NOT EXISTS chat_report_reason VARCHAR(200) NULL;
-- The Terms/Privacy text changed (conversations), so every user is asked to accept it again at their next login.
