-- Batch 4: email verification + admin 2FA codes, notifications, location & pet details, adoption timeline, success stories.
-- Run ONCE (safe to re-run on MariaDB/XAMPP). Back up first.
USE pawsadopt;

-- 1. Email verification (existing users must verify once) and the purpose of each one-time code
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at DATETIME NULL;
ALTER TABLE password_resets ADD COLUMN IF NOT EXISTS purpose ENUM('reset','verify','admin_login') NOT NULL DEFAULT 'reset';

-- 2. Shelter location (pets inherit it) and extra pet details
ALTER TABLE shelters ADD COLUMN IF NOT EXISTS city VARCHAR(80) NULL, ADD COLUMN IF NOT EXISTS province VARCHAR(80) NULL;
ALTER TABLE pets
  ADD COLUMN IF NOT EXISTS vaccinated     ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS neutered       ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS good_with_kids ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS size           ENUM('small','medium','large') NULL;

-- 3. In-app notifications
CREATE TABLE IF NOT EXISTS notifications (
  notification_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  type       VARCHAR(30)  NOT NULL,
  title      VARCHAR(120) NOT NULL,
  body       VARCHAR(255) NULL,
  link       VARCHAR(200) NULL,
  read_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, read_at, notification_id)
) ENGINE=InnoDB;

-- 4. Adoption timeline (inquiries.status is NOT changed, so the unique keys keep working)
CREATE TABLE IF NOT EXISTS inquiry_events (
  event_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  event_type ENUM('submitted','under_review','approved','rejected','approval_revoked','withdrawn','meeting_scheduled','adopted','closed_adopted','closed_removed') NOT NULL,
  actor_id   INT NULL,
  note       VARCHAR(255) NULL,
  meeting_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_event_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_event_actor   FOREIGN KEY (actor_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_event_inquiry (inquiry_id, event_id)
) ENGINE=InnoDB;
-- backfill from existing inquiries
INSERT INTO inquiry_events (inquiry_id, event_type, actor_id, created_at)
  SELECT i.inquiry_id, 'submitted', i.adopter_id, i.submitted_at FROM adoption_inquiries i
  WHERE NOT EXISTS (SELECT 1 FROM inquiry_events e WHERE e.inquiry_id = i.inquiry_id AND e.event_type = 'submitted');
INSERT INTO inquiry_events (inquiry_id, event_type, actor_id, note, created_at)
  SELECT i.inquiry_id, i.decision, i.responded_by, LEFT(i.response_message, 255), i.responded_at FROM adoption_inquiries i
  WHERE i.decision IS NOT NULL AND i.responded_at IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM inquiry_events e WHERE e.inquiry_id = i.inquiry_id AND e.event_type IN ('approved','rejected'));
INSERT INTO inquiry_events (inquiry_id, event_type, actor_id, created_at)
  SELECT i.inquiry_id, 'withdrawn', i.adopter_id, i.updated_at FROM adoption_inquiries i
  WHERE i.status = 'withdrawn' AND NOT EXISTS (SELECT 1 FROM inquiry_events e WHERE e.inquiry_id = i.inquiry_id AND e.event_type = 'withdrawn');

-- 5. Success stories (public only with the adopter's explicit consent)
CREATE TABLE IF NOT EXISTS success_stories (
  story_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL UNIQUE,
  shelter_id INT NOT NULL,
  posted_by  INT NOT NULL,
  title      VARCHAR(150) NOT NULL,
  body       TEXT NOT NULL,
  consent    ENUM('requested','full','anonymous','declined') NOT NULL DEFAULT 'requested' COMMENT 'full = name and photo, anonymous = story only',
  consent_at DATETIME NULL,
  status     ENUM('published','hidden') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_story_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_story_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_story_author  FOREIGN KEY (posted_by)  REFERENCES users(user_id) ON DELETE RESTRICT
) ENGINE=InnoDB;
-- The Terms/Privacy text changed again (email verification, notifications, success stories): everyone accepts the new version at next login.
