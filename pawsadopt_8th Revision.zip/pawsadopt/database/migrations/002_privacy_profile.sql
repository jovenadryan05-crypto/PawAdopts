-- Batch 2: privacy consent, richer profiles, account deletion. Run ONCE (safe to re-run on MariaDB/XAMPP).
USE pawsadopt;
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS profile_photo   VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS bio             VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS city            VARCHAR(80)  NULL,
  ADD COLUMN IF NOT EXISTS `position`      VARCHAR(80)  NULL COMMENT 'staff job title',
  ADD COLUMN IF NOT EXISTS housing_type    ENUM('house_owned','house_rented','apartment','condo','other') NULL,
  ADD COLUMN IF NOT EXISTS other_pets      VARCHAR(150) NULL,
  ADD COLUMN IF NOT EXISTS pet_experience  ENUM('first_time','some','experienced') NULL,
  ADD COLUMN IF NOT EXISTS consent_at      DATETIME NULL COMMENT 'when the user accepted Terms + Privacy Notice',
  ADD COLUMN IF NOT EXISTS terms_version   VARCHAR(20) NULL;
ALTER TABLE users MODIFY account_status ENUM('active','suspended','deleted') NOT NULL DEFAULT 'active';
-- Existing users have terms_version = NULL, so each is asked to accept the Terms/Privacy Notice at their next login.
