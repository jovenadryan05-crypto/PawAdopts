-- Batch 7. Back up first, then run this once in phpMyAdmin (SQL tab). Fresh installs: schema.sql already includes it.
-- 1. The foster & emergency-rescue board is gone: drop its tables (volunteer profiles, offers and cases are permanently deleted).
DROP TABLE IF EXISTS case_offers;
DROP TABLE IF EXISTS foster_volunteers;
DROP TABLE IF EXISTS rescue_cases;
DELETE FROM notifications WHERE type IN ('case', 'offer');
-- Announcements that a shelter published together with a rescue case point to the removed board: hide them.
UPDATE announcements_donations SET status = 'hidden' WHERE post_type = 'announcement' AND content LIKE '%See the Foster & rescue board to help.';

-- 2. Safer email and password changes: a pending new email, and three more kinds of one-time code.
ALTER TABLE users
  ADD COLUMN pending_email VARCHAR(150) NULL COMMENT 'new email waiting for its confirmation codes (profile security)' AFTER email_verified_at,
  ADD COLUMN pending_email_at DATETIME NULL AFTER pending_email;
ALTER TABLE password_resets
  MODIFY purpose ENUM('reset','verify','admin_login','pw_change','email_old','email_new') NOT NULL DEFAULT 'reset';
