-- Batch 5: shelter accounts + employee credentials, compatibility match, readiness checklist, post-adoption check-ins,
-- foster & emergency board, shelter profiles/transparency, photo rules, password history.
-- Run ONCE (safe to re-run on MariaDB/XAMPP). Back up first.
USE pawsadopt;

-- 1. Shelter accounts: the shelter administrator registers the shelter and creates accounts for employees
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_shelter_admin TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 = registered the shelter; creates employee accounts',
  ADD COLUMN IF NOT EXISTS created_by INT NULL COMMENT 'shelter admin who created this employee account';
-- existing shelters: the earliest staff member becomes the shelter administrator
UPDATE users u JOIN (SELECT shelter_id, MIN(user_id) AS first_id FROM users WHERE role='staff' AND shelter_id IS NOT NULL GROUP BY shelter_id) f
  ON f.first_id = u.user_id SET u.is_shelter_admin = 1;

-- 2. Shelter public profile
ALTER TABLE shelters
  ADD COLUMN IF NOT EXISTS logo  VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS about TEXT NULL;

-- 3. Pets: compatibility fields, draft status (no photo = not live), photo hash for duplicate checks
ALTER TABLE pets
  MODIFY COLUMN status ENUM('draft','available','pending','adopted','removed') NOT NULL DEFAULT 'available',
  ADD COLUMN IF NOT EXISTS good_with_pets    ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS needs_yard        ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS energy_level      ENUM('low','medium','high') NULL,
  ADD COLUMN IF NOT EXISTS experience_needed ENUM('first_time','some','experienced') NULL;
ALTER TABLE pet_photos ADD COLUMN IF NOT EXISTS content_hash CHAR(40) NULL, ADD INDEX IF NOT EXISTS idx_photo_hash (content_hash);
-- live listings without a photo become drafts (staff add a photo, then publish)
UPDATE pets p SET p.status='draft' WHERE p.status='available' AND NOT EXISTS (SELECT 1 FROM pet_photos ph WHERE ph.pet_id=p.pet_id);

-- 4. Adoption readiness checklist (one per adopter, copied onto each inquiry as a snapshot)
CREATE TABLE IF NOT EXISTS adopter_readiness (
  user_id            INT PRIMARY KEY,
  landlord_permission ENUM('own_home','yes_written','yes_verbal','not_yet','no') NOT NULL,
  monthly_budget     ENUM('under_1000','1000_3000','3000_5000','over_5000') NOT NULL,
  caregiver          ENUM('me','family','shared','someone_else') NOT NULL,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ready_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;
ALTER TABLE adoption_inquiries ADD COLUMN IF NOT EXISTS readiness TEXT NULL COMMENT 'JSON snapshot of the checklist at inquiry time';

-- 5. Post-adoption check-ins (1 week, 1 month, 3 months)
CREATE TABLE IF NOT EXISTS adoption_followups (
  followup_id  INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id   INT NOT NULL,
  milestone    ENUM('1_week','1_month','3_months') NOT NULL,
  due_at       DATETIME NOT NULL,
  notified_at  DATETIME NULL COMMENT 'in-app reminder created',
  emailed_at   DATETIME NULL COMMENT 'email reminder sent',
  submitted_at DATETIME NULL,
  wellbeing    ENUM('thriving','good','adjusting','struggling') NULL,
  notes        VARCHAR(1000) NULL,
  photo        VARCHAR(255) NULL,
  share_ok     TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'adopter allows notes + photo on the public Success Stories page',
  UNIQUE KEY uq_followup (inquiry_id, milestone),
  INDEX idx_followup_due (due_at, submitted_at),
  CONSTRAINT fk_followup_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE
) ENGINE=InnoDB;
-- adoptions that already happened get their check-ins too
INSERT IGNORE INTO adoption_followups (inquiry_id, milestone, due_at)
  SELECT e.inquiry_id, m.milestone, e.created_at + INTERVAL m.days DAY
  FROM inquiry_events e JOIN (SELECT '1_week' milestone, 7 days UNION SELECT '1_month', 30 UNION SELECT '3_months', 90) m
  WHERE e.event_type='adopted';

-- 6. Foster and emergency-rescue board
CREATE TABLE IF NOT EXISTS rescue_cases (
  case_id      INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id   INT NOT NULL,
  posted_by    INT NOT NULL,
  case_type    ENUM('emergency_rescue','foster_needed') NOT NULL,
  urgency      ENUM('critical','high','normal') NOT NULL DEFAULT 'normal',
  title        VARCHAR(150) NOT NULL,
  description  TEXT NOT NULL,
  species      VARCHAR(40) NULL,
  needs        VARCHAR(255) NULL COMMENT 'what is needed: supplies, medical care, transport',
  needed_by    DATE NULL,
  duration_weeks SMALLINT UNSIGNED NULL,
  pet_id       INT NULL,
  donation_post_id INT NULL,
  status       ENUM('open','filled','closed','hidden') NOT NULL DEFAULT 'open',
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_case_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_case_user    FOREIGN KEY (posted_by)  REFERENCES users(user_id) ON DELETE RESTRICT,
  CONSTRAINT fk_case_pet     FOREIGN KEY (pet_id)     REFERENCES pets(pet_id) ON DELETE SET NULL,
  CONSTRAINT fk_case_post    FOREIGN KEY (donation_post_id) REFERENCES announcements_donations(post_id) ON DELETE SET NULL,
  INDEX idx_case_board (status, urgency, created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS foster_volunteers (
  user_id      INT PRIMARY KEY,
  species_ok   VARCHAR(100) NOT NULL,
  capacity     TINYINT UNSIGNED NOT NULL DEFAULT 1,
  medical_ok   TINYINT(1) NOT NULL DEFAULT 0,
  availability VARCHAR(255) NULL,
  status       ENUM('active','paused') NOT NULL DEFAULT 'active',
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_fv_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS case_offers (
  offer_id   INT AUTO_INCREMENT PRIMARY KEY,
  case_id    INT NOT NULL,
  user_id    INT NOT NULL,
  message    VARCHAR(500) NULL,
  status     ENUM('offered','accepted','declined','withdrawn') NOT NULL DEFAULT 'offered',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_offer (case_id, user_id),
  CONSTRAINT fk_offer_case FOREIGN KEY (case_id) REFERENCES rescue_cases(case_id) ON DELETE CASCADE,
  CONSTRAINT fk_offer_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Password history: a new password cannot match the current one or the last 5
CREATE TABLE IF NOT EXISTS password_history (
  history_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pwh_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_pwh_user (user_id, history_id)
) ENGINE=InnoDB;
