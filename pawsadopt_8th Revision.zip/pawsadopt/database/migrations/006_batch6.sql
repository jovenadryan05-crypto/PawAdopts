-- Batch 6. Back up first, then run this once in phpMyAdmin (SQL tab). Fresh installs: schema.sql already includes it.

-- 1. Exact map pin for each shelter (set by the shelter administrator) + why/when a shelter was suspended
ALTER TABLE shelters
  ADD COLUMN latitude  DECIMAL(9,6) NULL AFTER province,
  ADD COLUMN longitude DECIMAL(9,6) NULL AFTER latitude,
  ADD COLUMN suspension_reason VARCHAR(255) NULL,
  ADD COLUMN suspended_at DATETIME NULL;

-- 2. Welfare checks: what a shelter did after an adopter ignored all three check-ins (call / visit / message)
CREATE TABLE IF NOT EXISTS welfare_checks (
  check_id   INT AUTO_INCREMENT PRIMARY KEY,
  inquiry_id INT NOT NULL,
  staff_id   INT NULL,
  method     ENUM('call','visit','message') NOT NULL,
  outcome    ENUM('ok','needs_help','unreachable','returned') NOT NULL,
  note       VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_wc_inquiry FOREIGN KEY (inquiry_id) REFERENCES adoption_inquiries(inquiry_id) ON DELETE CASCADE,
  CONSTRAINT fk_wc_staff   FOREIGN KEY (staff_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_wc_inquiry (inquiry_id, check_id)
) ENGINE=InnoDB;
ALTER TABLE adoption_inquiries ADD COLUMN no_response_flagged_at DATETIME NULL COMMENT 'set once, when all three check-ins went unanswered';

-- 3. Reactivation petitions: a suspended shelter asks the administrators to lift the suspension; both sides can send messages
CREATE TABLE IF NOT EXISTS shelter_petitions (
  petition_id  INT AUTO_INCREMENT PRIMARY KEY,
  shelter_id   INT NOT NULL,
  opened_by    INT NULL,
  suspension_reason VARCHAR(255) NULL COMMENT 'snapshot of the reason when the petition was opened',
  status       ENUM('open','approved','denied') NOT NULL DEFAULT 'open',
  resolved_by  INT NULL,
  resolved_at  DATETIME NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  open_key     INT AS (IF(status = 'open', shelter_id, NULL)) VIRTUAL,
  UNIQUE KEY uq_one_open_petition (open_key),
  CONSTRAINT fk_petition_shelter FOREIGN KEY (shelter_id) REFERENCES shelters(shelter_id) ON DELETE CASCADE,
  CONSTRAINT fk_petition_opener   FOREIGN KEY (opened_by)  REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_petition_resolver FOREIGN KEY (resolved_by) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_petition_status (status, created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS shelter_petition_messages (
  message_id  INT AUTO_INCREMENT PRIMARY KEY,
  petition_id INT NOT NULL,
  sender_id   INT NULL,
  sender_side ENUM('shelter','admin') NOT NULL,
  body        VARCHAR(1500) NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pm_petition FOREIGN KEY (petition_id) REFERENCES shelter_petitions(petition_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_sender   FOREIGN KEY (sender_id)   REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_pm_thread (petition_id, message_id)
) ENGINE=InnoDB;
