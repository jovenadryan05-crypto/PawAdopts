<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Find a pet'; $page = 'browse';
$me = user(); $adopter = $me && $me['role'] === 'adopter' ? $me : null;

// UC-08 Browse and search pets (only available pets from approved, active shelters)
$where = ["p.status = 'available'", "s.verification_status = 'approved'", "s.account_status = 'active'"];
$args = [];
$search = trim($_GET['q'] ?? '');
if ($search !== '') { $where[] = '(p.pet_name LIKE ? OR p.breed LIKE ? OR p.description LIKE ?)'; array_push($args, "%$search%", "%$search%", "%$search%"); }
$species = trim($_GET['species'] ?? '');
if ($species !== '') { $where[] = 'p.species = ?'; $args[] = $species; }
$sex = $_GET['sex'] ?? '';
if (in_array($sex, ['male', 'female'], true)) { $where[] = 'p.sex = ?'; $args[] = $sex; }
$age = $_GET['age'] ?? '';
$ageRanges = ['baby' => [0, 11], 'young' => [12, 35], 'adult' => [36, 95], 'senior' => [96, 9999]];
if (isset($ageRanges[$age])) { $where[] = 'p.age_months BETWEEN ? AND ?'; array_push($args, ...$ageRanges[$age]); }
$shelter = (int)($_GET['shelter'] ?? 0);
if ($shelter) { $where[] = 'p.shelter_id = ?'; $args[] = $shelter; }

$ids = array_slice(array_unique(array_filter(array_map('intval', explode(',', (string)($_GET['ids'] ?? ''))), fn($v) => $v > 0)), 0, 100);   // saved pets (kept in the visitor's browser)
if ($ids) { $where[] = 'p.pet_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')'; array_push($args, ...$ids); }
$place = $_GET['place'] ?? '';
if (strpos($place, '~') !== false) { [$pc, $pp] = explode('~', $place, 2); $where[] = 's.city = ? AND s.province = ?'; array_push($args, $pc, $pp); }
$size = $_GET['size'] ?? '';
if (in_array($size, ['small', 'medium', 'large'], true)) { $where[] = 'p.size = ?'; $args[] = $size; }
foreach (['vaccinated', 'neutered', 'good_with_kids', 'good_with_pets'] as $flag) if (!empty($_GET[$flag])) $where[] = "p.$flag = 'yes'";
if (!empty($_GET['no_yard'])) $where[] = "p.needs_yard = 'no'";
$energy = $_GET['energy'] ?? '';
if (in_array($energy, ['low', 'medium', 'high'], true)) { $where[] = 'p.energy_level = ?'; $args[] = $energy; }
$sort = ($_GET['sort'] ?? '') === 'match' && $adopter ? 'match' : 'new';
$cond = implode(' AND ', $where);
$total = (int)q("SELECT COUNT(*) FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE $cond", $args)->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$pg = min(max(1, (int)($_GET['p'] ?? 1)), $pages);
$offset = ($pg - 1) * PER_PAGE;
$select = "SELECT p.*, s.shelter_name, s.city, s.province,
            (SELECT photo_url FROM pet_photos WHERE pet_id = p.pet_id ORDER BY is_primary DESC, photo_id LIMIT 1) AS photo
          FROM pets p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE $cond";
if ($sort === 'match') {   // best match first: score in PHP (explainable rules), then page the sorted list
    $pets = q($select . ' ORDER BY p.created_at DESC LIMIT 400', $args)->fetchAll();
    foreach ($pets as &$pp) $pp['_match'] = pet_match($pp, $adopter); unset($pp);
    usort($pets, fn($a, $b) => ($b['_match']['score'] ?? -1) <=> ($a['_match']['score'] ?? -1));
    $pets = array_slice($pets, $offset, PER_PAGE);
} else {
    $pets = q($select . ' ORDER BY p.created_at DESC LIMIT ' . PER_PAGE . ' OFFSET ' . $offset, $args)->fetchAll();
    foreach ($pets as &$pp) $pp['_match'] = $adopter ? pet_match($pp, $adopter) : null; unset($pp);
}

$speciesList = q("SELECT DISTINCT species FROM pets WHERE status='available' ORDER BY species")->fetchAll(PDO::FETCH_COLUMN);
$shelters = q("SELECT shelter_id, shelter_name FROM shelters WHERE verification_status='approved' AND account_status='active' ORDER BY shelter_name")->fetchAll();
$places = q("SELECT DISTINCT city, province FROM shelters WHERE verification_status='approved' AND account_status='active' AND city IS NOT NULL AND city <> '' ORDER BY province, city")->fetchAll();
$qs = $_GET; unset($qs['p']);
$activeFilters = count(array_filter([$search, $species, $sex, $age, $shelter, $place, $size, $energy, !empty($_GET['vaccinated']), !empty($_GET['neutered']), !empty($_GET['good_with_kids']), !empty($_GET['good_with_pets']), !empty($_GET['no_yard'])]));

include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <h1>Someone is waiting for a home like yours.</h1>
  <p>Browse animals from verified shelters, ask a question, and start the adoption conversation.</p>
</section>

<button type="button" class="btn btn-ghost drawer-trigger" data-drawer-open="#filterDrawer" aria-expanded="false" aria-controls="filterDrawer"><?= icon('search') ?>Search and filters<?= $activeFilters ? '<span class="count">' . $activeFilters . '</span>' : '' ?></button>
<form id="filterDrawer" class="filters drawer" method="get" action="<?= url('pets.php') ?>" data-skeleton-for="#petResults" aria-label="Search and filters">
  <div class="drawer__head"><h2>Search and filters</h2><button type="button" class="drawer__close" data-drawer-close aria-label="Close filters"><?= icon('x') ?></button></div>
  <label class="grow">Search<input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, breed or description"></label>
  <label>Species
    <select name="species"><option value="">Any</option>
      <?php foreach ($speciesList as $sp): ?><option <?= $species === $sp ? 'selected' : '' ?>><?= e($sp) ?></option><?php endforeach; ?>
    </select></label>
  <label>Sex
    <select name="sex"><option value="">Any</option>
      <option value="male" <?= $sex==='male'?'selected':'' ?>>Male</option><option value="female" <?= $sex==='female'?'selected':'' ?>>Female</option></select></label>
  <label>Age
    <select name="age"><option value="">Any</option>
      <?php foreach (['baby'=>'Under 1 year','young'=>'1 to 2 years','adult'=>'3 to 7 years','senior'=>'8+ years'] as $k=>$v): ?>
        <option value="<?= $k ?>" <?= $age===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
    </select></label>
  <label>Shelter
    <select name="shelter"><option value="">Any</option>
      <?php foreach ($shelters as $s): ?><option value="<?= $s['shelter_id'] ?>" <?= $shelter==$s['shelter_id']?'selected':'' ?>><?= e($s['shelter_name']) ?></option><?php endforeach; ?>
    </select></label>
  <label>Location
    <select name="place"><option value="">Anywhere</option>
      <?php foreach ($places as $pl): $val = $pl['city'] . '~' . $pl['province']; ?><option value="<?= e($val) ?>" <?= $place === $val ? 'selected' : '' ?>><?= e($pl['city'] . ', ' . $pl['province']) ?></option><?php endforeach; ?>
    </select></label>
  <label>Size
    <select name="size"><option value="">Any</option><?php foreach (['small', 'medium', 'large'] as $z): ?><option value="<?= $z ?>" <?= $size === $z ? 'selected' : '' ?>><?= ucfirst($z) ?></option><?php endforeach; ?></select></label>
  <div class="checks">
    <label><input type="checkbox" name="vaccinated" value="1" <?= !empty($_GET['vaccinated']) ? 'checked' : '' ?>> Vaccinated</label>
    <label><input type="checkbox" name="neutered" value="1" <?= !empty($_GET['neutered']) ? 'checked' : '' ?>> Spayed / neutered</label>
    <label><input type="checkbox" name="good_with_kids" value="1" <?= !empty($_GET['good_with_kids']) ? 'checked' : '' ?>> Good with kids</label>
    <label><input type="checkbox" name="good_with_pets" value="1" <?= !empty($_GET['good_with_pets']) ? 'checked' : '' ?>> Good with other pets</label>
    <label><input type="checkbox" name="no_yard" value="1" <?= !empty($_GET['no_yard']) ? 'checked' : '' ?>> No yard needed</label>
  </div>
  <label>Energy
    <select name="energy"><option value="">Any</option><?php foreach (['low', 'medium', 'high'] as $z): ?><option value="<?= $z ?>" <?= $energy === $z ? 'selected' : '' ?>><?= ucfirst($z) ?></option><?php endforeach; ?></select></label>
  <?php if ($adopter): ?><label>Sort by
    <select name="sort"><option value="new">Newest</option><option value="match" <?= $sort === 'match' ? 'selected' : '' ?>>Best match for me</option></select></label><?php endif; ?>
  <button class="btn">Search</button>
  <?php if ($_GET): ?><a class="btn btn-ghost" href="<?= url('pets.php') ?>">Clear</a><?php endif; ?>
</form>
<div class="drawer-backdrop" data-drawer-backdrop="#filterDrawer" data-drawer-close aria-hidden="true"></div>

<div class="split results-bar"><p class="muted" role="status"><?= $total ?> pet<?= $total === 1 ? '' : 's' ?> available<?= $adopter && !$adopter['housing_type'] && !$adopter['pet_experience'] ? ' &middot; <a href="' . e(url('profile.php')) . '">Add your home details</a> to see how well each pet matches you' : '' ?></p>
  <a class="btn btn-ghost btn-sm saved-link" href="<?= e(url('pets.php')) ?>" data-saved-link="<?= e(url('pets.php')) ?>"><?= icon('heart') ?>Saved<span class="count" data-fav-count hidden></span></a></div>
<?php if ($ids): ?><p class="small muted">Showing your saved pets. <a href="<?= url('pets.php') ?>">Show all pets</a></p><?php endif; ?>
<div id="petResults" data-skeleton="grid">

<?php if (!$pets): ?>
  <?= $ids
      ? empty_state('bowl', 'No saved pets to show', 'Pets you save with the heart appear here while they are still available.', [['href' => url('pets.php'), 'label' => 'Explore available pets', 'icon' => 'paw-print']])
      : empty_state('search', 'No pets match those filters', 'Remove a filter or try a different breed. New animals are listed all the time.', [['href' => url('pets.php'), 'label' => 'Reset filters', 'icon' => 'rotate-cw'], ['href' => url('shelters.php'), 'label' => 'Browse shelters', 'icon' => 'building-2']]) ?>
<?php else: ?>
  <div class="grid">
  <?php foreach ($pets as $p): ?>
    <article class="card pet-card">
      <div class="thumb"><?php if ($p['photo']): ?><img src="<?= url($p['photo']) ?>" alt="<?= e($p['pet_name']) ?>" loading="lazy"><?php else: ?><span class="ph"><?= icon('paw-print') ?></span><?php endif; ?></div>
      <?= heart_button((int)$p['pet_id'], $p['pet_name']) ?>
      <div class="card-body">
        <h3><a class="pet-card__link" href="<?= url('pet.php?id=' . $p['pet_id']) ?>"><?= e($p['pet_name']) ?></a></h3>
        <p class="muted"><?= e($p['breed'] ?: $p['species']) ?> &middot; <?= e(ucfirst($p['sex'])) ?> &middot; <?= age_label((int)$p['age_months']) ?></p>
        <p class="small"><?= e($p['shelter_name']) ?><?= $p['city'] ? ' &middot; ' . e($p['city']) : '' ?></p>
        <?= match_badge($p['_match']) ?>
        <?= pet_tags($p) ?>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
  <?php if ($pages > 1): ?>
  <nav class="pager" aria-label="Pages">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <a class="<?= $i === $pg ? 'on' : '' ?>" href="<?= url('pets.php?' . http_build_query($qs + ['p' => $i])) ?>"><?= $i ?></a>
    <?php endfor; ?>
  </nav>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
