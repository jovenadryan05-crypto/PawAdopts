<?php
require __DIR__ . '/includes/bootstrap.php';
csrf_check();
$u = require_role();
if (email_verified($u)) { flash('info', 'Your email address is already verified.'); redirect(home_for($u)); }
$title = 'Verify your email'; $error = '';
// Email verification by one-time code (same hashed, 10-minute, 5-try codes as password reset)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'send') {
        if (otp_issue($u, 'verify', 'Verify your PawsAdopt email', 'Use this code to confirm your email address.')) flash('success', 'We sent a 6-digit code to ' . $u['email'] . '. It expires in 10 minutes.');
        else flash('error', 'You asked for several codes recently. Please wait a while and try again.');
        redirect('verify_email.php');
    }
    $res = otp_verify((int)$u['user_id'], 'verify', $_POST['code'] ?? '');
    if ($res === 'ok') { q('UPDATE users SET email_verified_at = NOW() WHERE user_id = ?', [$u['user_id']]); flash('success', 'Email verified. You can now send inquiries and messages.'); redirect(home_for($u)); }
    $error = $res === 'bad' ? 'That code is not correct.' : 'No active code: it expired, was already used, or was tried too many times. Send a new one.';
}
include __DIR__ . '/includes/header.php';
?>
<div class="auth narrow">
  <h1>Verify your email</h1>
  <p>Verified emails keep inquiries and messages trustworthy. You can browse without verifying, but you need it to send inquiries and chat with shelters.</p>
  <p class="muted">We will send a code to <b><?= e($u['email']) ?></b>. Wrong address? <a href="<?= url('profile.php') ?>">Change it in your profile</a>.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send"><button class="btn btn-ghost">Send me a code</button></form>
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack panel"><?= csrf_field() ?><input type="hidden" name="action" value="verify">
    <label>6-digit code<input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" required></label>
    <button class="btn">Verify</button>
  </form>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
