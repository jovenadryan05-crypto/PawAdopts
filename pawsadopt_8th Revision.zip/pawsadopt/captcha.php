<?php
// Draws the CAPTCHA image for the challenge stored in the visitor's session.
// Uses only core GD functions (no imagerotate, which many hosts do not have), so it works on XAMPP and on shared hosting.
require __DIR__ . '/includes/bootstrap.php';
if (!captcha_gd_ok()) { http_response_code(404); exit; }
if (isset($_GET['new'])) captcha_new('image');               // "new image" button: replace the challenge, then draw it
$c = $_SESSION['captcha'] ?? null;
if (!$c || $c['mode'] !== 'image') { http_response_code(404); exit; }
session_write_close();

try {
    $W = 180; $H = 60;
    $bg = [random_int(236, 248), random_int(238, 250), random_int(240, 252)];
    $mk = function ($w, $h) use ($bg) { $i = imagecreatetruecolor($w, $h); imagefilledrectangle($i, 0, 0, $w, $h, imagecolorallocate($i, ...$bg)); return $i; };
    $text = $mk($W, $H);
    $answer = $c['answer']; $n = strlen($answer);
    $fw = imagefontwidth(5); $fh = imagefontheight(5);
    for ($i = 0; $i < $n; $i++) {
        $g = $mk($fw, $fh);                                            // one character on a tiny canvas, then scaled up unevenly
        imagechar($g, 5, 0, 0, $answer[$i], imagecolorallocate($g, random_int(10, 80), random_int(10, 80), random_int(50, 130)));
        $w = random_int(24, 31); $h = random_int(36, 44);
        imagecopyresampled($text, $g, 8 + $i * 34 + random_int(-2, 2), random_int(4, max(4, $H - $h - 4)), 0, 0, $w, $h, $fw, $fh);
        imagedestroy($g);
    }
    $im = $mk($W, $H);                                                 // wave distortion: shift every column up or down a little
    $phase = random_int(0, 628) / 100; $amp = random_int(2, 4); $len = random_int(8, 13);
    for ($x = 0; $x < $W; $x++) imagecopy($im, $text, $x, (int)round(sin($x / $len + $phase) * $amp), $x, 0, 1, $H);
    for ($i = 0; $i < 5; $i++) imageline($im, random_int(0, 15), random_int(0, $H), random_int($W - 15, $W), random_int(0, $H), imagecolorallocate($im, random_int(70, 150), random_int(70, 150), random_int(70, 150)));
    for ($i = 0; $i < 160; $i++) imagesetpixel($im, random_int(0, $W - 1), random_int(0, $H - 1), imagecolorallocate($im, random_int(60, 190), random_int(60, 190), random_int(60, 190)));
    header('Content-Type: image/png'); header('Cache-Control: no-store, max-age=0');
    imagepng($im);
} catch (Throwable $t) {
    error_log('CAPTCHA image failed: ' . $t->getMessage());
    http_response_code(500);
}
