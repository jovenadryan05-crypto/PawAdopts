<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$admin = require_role('admin');
$title = 'Shelters'; $page = 'shelters';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $reason = trim($_POST['reason'] ?? '');
    $sh = q('SELECT * FROM shelters WHERE shelter_id=?', [$id])->fetch();
    if (!$sh) { flash('error', 'Shelter not found.'); redirect('admin/shelters.php'); }
    // UC-06 Approve or reject shelter
    if ($act === 'approve' && $sh['verification_status'] !== 'approved') {
        q("UPDATE shelters SET verification_status='approved', rejection_reason=NULL, reviewed_by=?, reviewed_at=NOW() WHERE shelter_id=?", [$admin['user_id'], $id]);
        audit('shelter_approved', 'shelter', $id, $sh['shelter_name']);
        send_mail_later($sh['contact_email'], 'Your shelter was approved on PawsAdopt', mail_layout('Your shelter was approved',
            '<p>Good news: <b>' . e($sh['shelter_name']) . '</b> has been verified. You can now list pets, answer inquiries and post announcements.</p><p>Remember to create accounts for your employees under <b>Team</b>.</p>' . mail_button('Open your dashboard', 'staff/dashboard.php'), user_sender($admin)));
        notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter was approved', $sh['shelter_name'], 'staff/dashboard.php');
        flash('success', 'Shelter approved and notified by email.');
    } elseif ($act === 'reject' && $sh['verification_status'] === 'pending') {
        if ($reason === '') flash('error', 'Give the shelter a reason for the rejection.');
        else {
            q("UPDATE shelters SET verification_status='rejected', rejection_reason=?, reviewed_by=?, reviewed_at=NOW() WHERE shelter_id=?", [$reason, $admin['user_id'], $id]);
            audit('shelter_rejected', 'shelter', $id, $sh['shelter_name'] . ': ' . $reason);
            send_mail_later($sh['contact_email'], 'Your PawsAdopt shelter registration needs changes', mail_layout('Your registration needs changes',
                '<p>We could not approve <b>' . e($sh['shelter_name']) . '</b> yet.</p><p><b>Reason:</b> ' . e($reason) . '</p><p>Update your details and resubmit from your dashboard.</p>' . mail_button('Open your dashboard', 'staff/dashboard.php'), user_sender($admin)));
            notify_users(shelter_staff_ids($id), 'shelter', 'Your shelter registration needs changes', $reason, 'staff/dashboard.php');
            flash('success', 'Shelter rejected and notified by email.');
        }
    } elseif ($act === 'suspend' && $sh['verification_status'] === 'approved' && $sh['account_status'] === 'active') {       // UC-15 manage accounts
        if ($reason === '') flash('error', 'Give the shelter a reason for the suspension. The shelter sees it and can petition to be reactivated.');
        else { shelter_suspend($sh, $admin, $reason); flash('success', 'Shelter suspended and notified; its listings are hidden.'); }
    } elseif ($act === 'activate' && $sh['account_status'] === 'suspended') {
        shelter_reactivate($sh, $admin);
        flash('success', 'Shelter reactivated and notified.' );
    }
    redirect('admin/shelters.php?s=' . urlencode($_GET['s'] ?? 'pending'));
}
$filter = $_GET['s'] ?? 'pending';
$valid = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($filter, $valid, true)) $filter = 'pending';
$cond = $filter === 'all' ? '' : 'WHERE s.verification_status=?'; $args = $filter === 'all' ? [] : [$filter];
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM shelters s $cond", $args)->fetchColumn(), 15);
$rows = q("SELECT s.*, (SELECT COUNT(*) FROM pets p WHERE p.shelter_id=s.shelter_id) AS pet_count,
            (SELECT petition_id FROM shelter_petitions sp WHERE sp.shelter_id=s.shelter_id AND sp.status='open') AS open_petition,
            (SELECT CONCAT(first_name,' ',last_name) FROM users WHERE shelter_id=s.shelter_id ORDER BY is_shelter_admin DESC, user_id LIMIT 1) AS staff_name
           FROM shelters s $cond ORDER BY s.created_at DESC LIMIT 15 OFFSET $off", $args)->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Shelters</h1>
<div class="tabs"><?php foreach ($valid as $s): ?><a class="<?= $filter === $s ? 'on' : '' ?>" href="?s=<?= $s ?>"><?= ucfirst($s) ?></a><?php endforeach; ?></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'all' ? '' : e($filter) . ' ' ?>shelters</h2></div><?php endif; ?>
<?php foreach ($rows as $s): ?>
<article class="panel">
  <div class="split"><h2><?= e($s['shelter_name']) ?></h2><span><?= badge($s['verification_status']) ?> <?php if ($s['account_status'] === 'suspended') echo badge('suspended'); ?></span></div>
  <p class="small muted"><?= e($s['address']) ?> &middot; <?= e($s['contact_email']) ?> &middot; <?= e($s['contact_number']) ?><br>
    Registered by <?= e($s['staff_name'] ?: 'unknown') ?> (shelter administrator) on <?= fdate($s['created_at']) ?> &middot; <?= (int)$s['pet_count'] ?> pet(s)</p>
  <?php if ($s['account_status'] === 'suspended'): ?><p class="small"><strong>Suspended<?= $s['suspended_at'] ? ' ' . e(fdate($s['suspended_at'])) : '' ?>:</strong> <?= e($s['suspension_reason'] ?: 'No reason recorded.') ?>
    <?php if ($s['open_petition']): ?> &middot; <a href="<?= url('admin/petitions.php?id=' . (int)$s['open_petition']) ?>"><strong>Reactivation petition waiting</strong></a><?php endif; ?></p><?php endif; ?>
  <?php if ($s['rejection_reason']): ?><p class="small"><strong>Rejection reason:</strong> <?= e($s['rejection_reason']) ?></p><?php endif; ?>
  <p><a href="<?= url('admin/document.php?id=' . $s['shelter_id']) ?>" target="_blank" rel="noopener">View verification document</a> &middot; <a href="<?= url('shelter.php?id=' . $s['shelter_id']) ?>">Public profile</a> &middot;
    <?php if (has_pin($s)): ?><a href="<?= e(map_open_url($s, '')) ?>" target="_blank" rel="noopener">Check map pin (<?= e(pin_text($s)) ?>)</a><?php else: ?><span class="muted">No map pin set</span><?php endif; ?></p>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['shelter_id'] ?>">
    <?php if ($s['verification_status'] !== 'approved'): ?>
      <label>Rejection reason (required to reject)<input name="reason" maxlength="255" placeholder="e.g. Document is unreadable"></label>
    <?php elseif ($s['account_status'] === 'active'): ?>
      <label>Suspension reason (required to suspend; the shelter will see it)<input name="reason" maxlength="255" placeholder="e.g. Reports of listings for animals the shelter does not have"></label>
    <?php endif; ?>
    <div class="actions">
      <?php if ($s['verification_status'] !== 'approved'): ?><button class="btn" name="action" value="approve">Approve</button><?php endif; ?>
      <?php if ($s['verification_status'] === 'pending'): ?><button class="btn btn-danger" name="action" value="reject">Reject</button><?php endif; ?>
      <?php if ($s['verification_status'] === 'approved'): ?>
        <?php if ($s['account_status'] === 'active'): ?><button class="btn btn-danger" name="action" value="suspend" data-confirm="Suspend this shelter and hide its listings?">Suspend shelter</button>
        <?php else: ?><button class="btn btn-ghost" name="action" value="activate">Reactivate shelter</button><?php endif; ?>
      <?php endif; ?>
    </div>
  </form>
</article>
<?php endforeach; ?>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
