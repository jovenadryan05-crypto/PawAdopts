<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
require_role('admin');
$title = 'Moderation'; $page = 'mod';
$tab = in_array($_GET['tab'] ?? 'pets', ['pets', 'posts', 'chats', 'stories'], true) ? ($_GET['tab'] ?? 'pets') : 'pets';
// UC-15 Moderate content: remove/restore pet listings, hide/publish posts, review reported conversations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? '';
    if ($act === 'remove_pet') { set_pet_status($id, 'removed'); audit('pet_removed', 'pet', $id); }
    if ($act === 'restore_pet' && q("SELECT 1 FROM pets WHERE pet_id=? AND status='removed'", [$id])->fetch()) { set_pet_status($id, 'available'); audit('pet_restored', 'pet', $id); }
    if ($act === 'hide_post') { q("UPDATE announcements_donations SET status='hidden' WHERE post_id=?", [$id]); audit('post_hidden', 'post', $id); }
    if ($act === 'show_post') { q("UPDATE announcements_donations SET status='published' WHERE post_id=? AND status='hidden'", [$id]); audit('post_unhidden', 'post', $id); }
    if ($act === 'hide_story') { q("UPDATE success_stories SET status='hidden' WHERE story_id=?", [$id]); audit('story_hidden', 'story', $id); }
    if ($act === 'show_story') { q("UPDATE success_stories SET status='published' WHERE story_id=?", [$id]); audit('story_unhidden', 'story', $id); }
    if ($act === 'chat_lock')    { q('UPDATE adoption_inquiries SET chat_locked=1 WHERE inquiry_id=?', [$id]); audit('chat_locked', 'inquiry', $id); }
    if ($act === 'chat_unlock')  { q('UPDATE adoption_inquiries SET chat_locked=0 WHERE inquiry_id=?', [$id]); audit('chat_unlocked', 'inquiry', $id); }
    if ($act === 'chat_dismiss') { q('UPDATE adoption_inquiries SET chat_reported_at=NULL, chat_reported_by=NULL, chat_report_reason=NULL WHERE inquiry_id=?', [$id]); audit('chat_report_dismissed', 'inquiry', $id); }
    flash('success', 'Moderation action applied.');
    redirect('admin/moderation.php?' . http_build_query(['tab' => $tab, 'p' => (int)($_GET['p'] ?? 1)]));
}
$countSql = ['pets' => 'SELECT COUNT(*) FROM pets', 'stories' => 'SELECT COUNT(*) FROM success_stories', 'posts' => 'SELECT COUNT(*) FROM announcements_donations',
             'chats' => 'SELECT COUNT(*) FROM adoption_inquiries WHERE chat_reported_at IS NOT NULL OR chat_locked=1'][$tab];
[$pg, $pages, $off] = paginate((int)q($countSql)->fetchColumn(), 20);
$pets = $tab === 'pets' ? q("SELECT p.*, s.shelter_name FROM pets p JOIN shelters s ON s.shelter_id=p.shelter_id ORDER BY p.created_at DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
$posts = $tab === 'posts' ? q("SELECT a.*, s.shelter_name FROM announcements_donations a JOIN shelters s ON s.shelter_id=a.shelter_id ORDER BY a.created_at DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
$stories = $tab === 'stories' ? q("SELECT st.*, p.pet_name, sh.shelter_name FROM success_stories st JOIN adoption_inquiries i ON i.inquiry_id=st.inquiry_id JOIN pets p ON p.pet_id=i.pet_id JOIN shelters sh ON sh.shelter_id=st.shelter_id ORDER BY st.created_at DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
$chats = $tab === 'chats' ? q("SELECT i.inquiry_id, i.chat_locked, i.chat_reported_at, i.chat_report_reason, p.pet_name, s.shelter_name,
            CONCAT(a.first_name,' ',a.last_name) AS adopter, CONCAT(r.first_name,' ',r.last_name) AS reporter,
            (SELECT COUNT(*) FROM inquiry_messages m WHERE m.inquiry_id=i.inquiry_id) AS msgs
          FROM adoption_inquiries i JOIN pets p ON p.pet_id=i.pet_id JOIN shelters s ON s.shelter_id=p.shelter_id JOIN users a ON a.user_id=i.adopter_id LEFT JOIN users r ON r.user_id=i.chat_reported_by
          WHERE i.chat_reported_at IS NOT NULL OR i.chat_locked=1 ORDER BY i.chat_reported_at DESC, i.inquiry_id DESC LIMIT 20 OFFSET $off")->fetchAll() : [];
include __DIR__ . '/../includes/header.php';
?>
<h1>Content moderation</h1>
<div class="tabs"><a class="<?= $tab === 'pets' ? 'on' : '' ?>" href="?tab=pets">Pet listings</a><a class="<?= $tab === 'posts' ? 'on' : '' ?>" href="?tab=posts">Announcements &amp; donations</a><a class="<?= $tab === 'chats' ? 'on' : '' ?>" href="?tab=chats">Reported conversations</a><a class="<?= $tab === 'stories' ? 'on' : '' ?>" href="?tab=stories">Success stories</a></div>
<?php if ($tab === 'chats'): ?><p class="muted">Conversations are private. You can only open one after a participant reports it, and every view is written to the audit log.</p><?php endif; ?>
<div class="table-wrap"><table>
<?php if ($tab === 'pets'): ?>
<thead><tr><th>Pet</th><th>Shelter</th><th>Listed</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($pets as $p): ?><tr>
  <td><a href="<?= url('pet.php?id=' . $p['pet_id']) ?>"><?= e($p['pet_name']) ?></a> <span class="muted small"><?= e($p['species']) ?></span></td><td><?= e($p['shelter_name']) ?></td><td><?= fdate($p['created_at']) ?></td><td><?= badge($p['status']) ?></td>
  <td class="row-actions"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['pet_id'] ?>">
    <?php if ($p['status'] !== 'removed'): ?><button class="btn btn-sm btn-danger" name="action" value="remove_pet" data-confirm="Remove this listing? Open inquiries will be closed.">Remove</button>
    <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="restore_pet">Restore</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php elseif ($tab === 'posts'): ?>
<thead><tr><th>Post</th><th>Shelter</th><th>Type</th><th>Posted</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($posts as $p): ?><tr>
  <td><?= e($p['title']) ?></td><td><?= e($p['shelter_name']) ?></td><td><?= e(ucfirst($p['post_type'])) ?></td><td><?= fdate($p['created_at']) ?></td><td><?= badge($p['status']) ?></td>
  <td class="row-actions"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['post_id'] ?>">
    <?php if ($p['status'] !== 'hidden'): ?><button class="btn btn-sm btn-danger" name="action" value="hide_post" data-confirm="Hide this post from the public?">Hide</button>
    <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="show_post">Unhide</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php elseif ($tab === 'stories'): ?>
<thead><tr><th>Story</th><th>Pet</th><th>Shelter</th><th>Adopter consent</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($stories as $s): ?><tr>
  <td><?= e($s['title']) ?></td><td><?= e($s['pet_name']) ?></td><td><?= e($s['shelter_name']) ?></td><td><?= e($s['consent']) ?></td><td><?= badge($s['status']) ?></td>
  <td class="row-actions"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['story_id'] ?>">
    <?php if ($s['status'] === 'published'): ?><button class="btn btn-sm btn-danger" name="action" value="hide_story" data-confirm="Hide this story from the public page?">Hide</button>
    <?php else: ?><button class="btn btn-sm btn-ghost" name="action" value="show_story">Unhide</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php else: ?>
<thead><tr><th>Conversation</th><th>Reported</th><th>Reason</th><th>Messages</th><th>State</th><th></th></tr></thead><tbody>
<?php foreach ($chats as $c): ?><tr>
  <td><?= e($c['pet_name']) ?> <span class="muted small"><?= e($c['adopter']) ?> &amp; <?= e($c['shelter_name']) ?></span></td>
  <td><?= $c['chat_reported_at'] ? e(fdate($c['chat_reported_at'])) . '<br><span class="muted small">by ' . e($c['reporter'] ?: 'unknown') . '</span>' : '-' ?></td>
  <td><?= e($c['chat_report_reason'] ?: '-') ?></td><td><?= (int)$c['msgs'] ?></td>
  <td><?= $c['chat_locked'] ? badge('locked') : badge($c['chat_reported_at'] ? 'reported' : 'open') ?></td>
  <td class="row-actions">
    <?php if ($c['chat_reported_at']): ?><a class="btn btn-sm btn-ghost" href="<?= url('chat.php?inquiry=' . $c['inquiry_id']) ?>">Open (read-only)</a><?php endif; ?>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['inquiry_id'] ?>">
      <?php if ($c['chat_locked']): ?><button class="btn btn-sm btn-ghost" name="action" value="chat_unlock">Unlock</button>
      <?php else: ?><button class="btn btn-sm btn-danger" name="action" value="chat_lock" data-confirm="Lock this conversation? Neither side will be able to send messages.">Lock</button><?php endif; ?>
      <?php if ($c['chat_reported_at']): ?><button class="btn btn-sm btn-ghost" name="action" value="chat_dismiss">Dismiss report</button><?php endif; ?></form></td></tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody></table></div>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
