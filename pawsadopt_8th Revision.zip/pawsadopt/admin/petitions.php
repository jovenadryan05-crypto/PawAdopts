<?php
require __DIR__ . '/../includes/bootstrap.php';
csrf_check();
$admin = require_role('admin');
$title = 'Reactivation petitions'; $page = 'petitions';
// Petitions from suspended shelters: read the thread, reply, then reactivate the shelter or deny the petition.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? ''; $body = trim($_POST['body'] ?? '');
    $p = q("SELECT p.*, s.shelter_name, s.contact_email, s.shelter_id, s.account_status AS shelter_status FROM shelter_petitions p JOIN shelters s ON s.shelter_id = p.shelter_id WHERE p.petition_id = ?", [$pid])->fetch();
    if (!$p) { flash('error', 'Petition not found.'); redirect('admin/petitions.php'); }
    $sh = q('SELECT * FROM shelters WHERE shelter_id = ?', [$p['shelter_id']])->fetch();
    $tellStaff = fn(string $t, string $b) => notify_users(shelter_staff_ids((int)$p['shelter_id']), 'petition', $t, cut_text($b, 200), 'staff/petition.php');
    $mail = fn(string $subject, string $heading, string $text) => send_mail_later($p['contact_email'], $subject, mail_layout($heading, '<p>' . e($text) . '</p>' . ($body !== '' ? mail_quote($body) : '') . mail_button('Open your petition', 'staff/petition.php'), user_sender($admin)));
    if ($p['status'] !== 'open') flash('info', 'That petition was already decided.');
    elseif ($act === 'reply' || $act === 'deny') {
        if ($err = petition_body_error($body)) flash('error', $act === 'deny' ? 'Explain the decision to the shelter (at least a sentence).' : $err);
        else {
            petition_add_message($pid, (int)$admin['user_id'], 'admin', $body);
            if ($act === 'deny') {
                q("UPDATE shelter_petitions SET status='denied', resolved_by=?, resolved_at=NOW() WHERE petition_id=? AND status='open'", [$admin['user_id'], $pid]);
                audit('petition_denied', 'shelter', (int)$p['shelter_id'], $p['shelter_name'] . ': ' . $body);
                $tellStaff('Your reactivation petition was denied', $body);
                $mail('Your reactivation petition on PawsAdopt', 'Your petition was not approved', 'The administrator reviewed the petition for ' . $p['shelter_name'] . ' and did not approve it yet. You can send a new petition after addressing the points below.');
                flash('success', 'Petition denied and the shelter was told why.');
            } else {
                $tellStaff('New message about your petition', $body);
                $mail('A message about your reactivation petition', 'A message from the administrator', 'The administrator replied to the petition for ' . $p['shelter_name'] . '.');
                flash('success', 'Message sent to the shelter.');
            }
        }
    } elseif ($act === 'approve') {
        if ($sh['account_status'] !== 'suspended') flash('info', 'That shelter is already active.');
        else { shelter_reactivate($sh, $admin, $body !== '' ? $body : null); flash('success', 'Shelter reactivated, the petition was approved and the shelter was notified.'); }
    }
    redirect('admin/petitions.php?' . (in_array($act, ['approve', 'deny'], true) && $p['status'] === 'open' ? 's=decided&' : '') . 'id=' . $pid);
}
$filter = ($_GET['s'] ?? 'open') === 'decided' ? 'decided' : 'open'; $focus = (int)($_GET['id'] ?? 0);
$cond = $filter === 'open' ? "p.status = 'open'" : "p.status <> 'open'";
[$pg, $pages, $off] = paginate((int)q("SELECT COUNT(*) FROM shelter_petitions p WHERE $cond")->fetchColumn(), 10);
$rows = q("SELECT p.*, s.shelter_name, s.account_status AS shelter_status, s.suspension_reason AS current_reason, u.first_name, u.last_name
           FROM shelter_petitions p JOIN shelters s ON s.shelter_id = p.shelter_id LEFT JOIN users u ON u.user_id = p.opened_by
           WHERE $cond ORDER BY " . ($filter === 'open' ? 'p.created_at ASC' : 'p.resolved_at DESC') . " LIMIT 10 OFFSET $off")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Reactivation petitions</h1>
<div class="tabs"><a class="<?= $filter === 'open' ? 'on' : '' ?>" href="?s=open">Open (<?= petition_open_count() ?>)</a><a class="<?= $filter === 'decided' ? 'on' : '' ?>" href="?s=decided">Decided</a></div>
<?php if (!$rows): ?><div class="empty"><h2>No <?= $filter === 'open' ? 'open' : 'decided' ?> petitions</h2></div><?php endif; ?>
<?php foreach ($rows as $r): ?>
<article class="panel<?= $focus === (int)$r['petition_id'] ? ' focus' : '' ?>" id="p<?= (int)$r['petition_id'] ?>">
  <div class="split"><h2><?= e($r['shelter_name']) ?></h2><?= petition_status_badge($r['status']) ?></div>
  <p class="small muted">Sent <?= e(fdate($r['created_at'])) ?> by <?= e(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')) ?: 'the shelter administrator') ?> &middot; <a href="<?= url('shelter.php?id=' . (int)$r['shelter_id']) ?>">Public profile</a></p>
  <p class="small"><strong>Suspended for:</strong> <?= e($r['suspension_reason'] ?: 'No reason recorded.') ?></p>
  <?= petition_thread_html(petition_messages((int)$r['petition_id'])) ?>
  <?php if ($r['status'] === 'open'): ?>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['petition_id'] ?>">
    <label>Your message to the shelter<textarea name="body" rows="3" maxlength="<?= PETITION_MAX_LEN ?>" placeholder="Ask a question, or explain your decision. Required to deny; optional when approving."></textarea></label>
    <div class="actions">
      <button class="btn btn-ghost" name="action" value="reply">Send message</button>
      <button class="btn" name="action" value="approve" data-confirm="Reactivate this shelter and approve the petition?">Reactivate shelter</button>
      <button class="btn btn-danger" name="action" value="deny" data-confirm="Deny this petition? The shelter stays suspended and sees your message.">Deny petition</button>
    </div>
  </form>
  <?php endif; ?>
</article>
<?php endforeach; ?>
<?= pager($pg, $pages) ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
