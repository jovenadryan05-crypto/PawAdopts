/* PawsAdopt UI layer (v9)
   Toast · favorites · FAB · live validation · filter drawer · confirm dialog · skeletons · view transitions.
   - Loaded after app.js. Everything is progressive: without this file the pages still work.
   - CSP-safe: no inline styles or handlers; custom properties are set through the CSSOM (el.style.setProperty).
   - Motion lives in style.css (transform / opacity only). This file only toggles classes and ARIA state. */
(function () {
  'use strict';

  var reduced = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  var FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function svgIcon(body, cls) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('class', 'icon' + (cls ? ' ' + cls : '')); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '2'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false'); s.innerHTML = body;   // body is a constant from this file, never user text
    return s;
  }
  var PATHS = {
    ok: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    bad: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    check: '<path d="M20 6 9 17l-5-5"/>'
  };
  function trapTab(e, box) {
    if (e.key !== 'Tab') return;
    var f = Array.prototype.filter.call(box.querySelectorAll(FOCUSABLE), function (n) { return n.offsetParent !== null || n === document.activeElement; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ---------------------------------------------------------------
     View transitions (same-document). Cross-document ones are pure CSS (@view-transition).
     Browsers without the API just run the update.
     --------------------------------------------------------------- */
  function transition(update) {
    if (document.startViewTransition && !reduced.matches) { try { return document.startViewTransition(update); } catch (err) { /* fall through */ } }
    update();
  }
  window.pawsTransition = transition;

  /* ---------------------------------------------------------------
     Toast:  pawsToast.success('Saved'), .error('Message', {title}), .info(...)
     opts: title, duration (ms, default 5000), action {label, onClick}
     --------------------------------------------------------------- */
  var region = document.getElementById('toastRegion');
  if (!region) { region = el('div', 'toast-region'); region.id = 'toastRegion'; region.setAttribute('role', 'region'); region.setAttribute('aria-label', 'Notifications'); region.setAttribute('aria-live', 'polite'); document.body.appendChild(region); }

  function dismiss(t) {
    if (!t || t.dataset.gone) return;
    t.dataset.gone = '1'; clearTimeout(t._timer);
    var done = function () { if (t.parentNode) t.parentNode.removeChild(t); };
    if (reduced.matches) { done(); return; }
    t.classList.add('is-leaving'); t.addEventListener('animationend', done, { once: true }); setTimeout(done, 400);   // timeout = safety net
  }
  function toast(type, message, opts) {
    opts = opts || {};
    var ms = opts.duration || (type === 'error' ? 8000 : 5000);
    var live = region.querySelectorAll('.toast:not(.is-leaving)'); if (live.length >= 4) dismiss(live[0]);
    var t = el('div', 'toast toast--' + type);
    t.setAttribute('role', type === 'error' ? 'alert' : 'status');
    var ic = el('span', 'toast__icon'); ic.appendChild(svgIcon(type === 'success' ? PATHS.ok : type === 'error' ? PATHS.bad : PATHS.info));
    var body = el('div', 'toast__body');
    if (opts.title) body.appendChild(el('strong', 'toast__title', opts.title));
    if (message) body.appendChild(el('span', 'toast__msg', message));
    if (opts.action) {
      var a = el('button', 'toast__action', opts.action.label); a.type = 'button';
      a.addEventListener('click', function () { try { opts.action.onClick && opts.action.onClick(); } finally { dismiss(t); } });
      body.appendChild(a);
    }
    var close = el('button', 'toast__close'); close.type = 'button'; close.setAttribute('aria-label', 'Dismiss notification'); close.appendChild(svgIcon(PATHS.x));
    close.addEventListener('click', function () { dismiss(t); });
    var bar = el('span', 'toast__bar'); bar.setAttribute('aria-hidden', 'true'); bar.style.setProperty('--toast-ms', ms + 'ms');
    t.appendChild(ic); t.appendChild(body); t.appendChild(close); t.appendChild(bar);

    // timer with pause/resume so hovering or focusing a toast gives people time to read it
    var remaining = ms, startedAt = 0;
    function start() { startedAt = Date.now(); clearTimeout(t._timer); t._timer = setTimeout(function () { dismiss(t); }, remaining); t.classList.remove('is-paused'); }
    function pause() { if (t.dataset.gone) return; clearTimeout(t._timer); remaining -= Date.now() - startedAt; t.classList.add('is-paused'); }
    t.addEventListener('mouseenter', pause); t.addEventListener('mouseleave', function () { if (!t.contains(document.activeElement)) start(); });
    t.addEventListener('focusin', pause); t.addEventListener('focusout', function () { if (!t.matches(':hover')) start(); });
    t.addEventListener('keydown', function (e) { if (e.key === 'Escape') { dismiss(t); } });
    region.appendChild(t); start();
    return t;
  }
  window.pawsToast = {
    show: toast, dismiss: dismiss,
    success: function (m, o) { return toast('success', m, o); },
    error: function (m, o) { return toast('error', m, o); },
    info: function (m, o) { return toast('info', m, o); }
  };
  // Server success flashes ("Application submitted") become toasts. Errors and info stay inline: people must be able to re-read them.
  document.querySelectorAll('.main .flash-success').forEach(function (f) {
    var text = f.textContent.trim(); if (!text) return;
    f.parentNode.removeChild(f); toast('success', text);
  });

  /* ---------------------------------------------------------------
     Favorites: stored on this device (localStorage), not in the database.
     --------------------------------------------------------------- */
  var KEY = 'pawsFavs';
  function readFavs() { try { var v = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(v) ? v.map(Number).filter(Boolean) : []; } catch (err) { return []; } }
  function writeFavs(list) { try { localStorage.setItem(KEY, JSON.stringify(list.slice(0, 100))); return true; } catch (err) { return false; } }
  function syncFavs() {
    var favs = readFavs();
    document.querySelectorAll('[data-fav]').forEach(function (b) { b.setAttribute('aria-pressed', String(favs.indexOf(Number(b.dataset.fav)) !== -1)); });
    document.querySelectorAll('[data-fav-count]').forEach(function (n) { n.textContent = favs.length; n.hidden = !favs.length; });
    document.querySelectorAll('a[data-saved-link]').forEach(function (a) {
      var base = a.getAttribute('data-saved-link'); a.setAttribute('href', favs.length ? base + (base.indexOf('?') === -1 ? '?' : '&') + 'ids=' + favs.join(',') : base);
    });
  }
  function setFav(id, on) {
    var favs = readFavs(), i = favs.indexOf(id);
    if (on && i === -1) favs.unshift(id); else if (!on && i !== -1) favs.splice(i, 1);
    return writeFavs(favs);
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-fav]');
    if (b) {
      e.preventDefault(); e.stopPropagation();
      var id = Number(b.dataset.fav), name = b.dataset.name || 'This pet', on = b.getAttribute('aria-pressed') !== 'true';
      if (!setFav(id, on)) { toast('error', 'Your browser is blocking saved pets, so this one was not saved.'); return; }
      syncFavs();
      if (!reduced.matches) { b.classList.remove('is-pop'); void b.offsetWidth; b.classList.add('is-pop'); b.addEventListener('animationend', function () { b.classList.remove('is-pop'); }, { once: true, capture: true }); }
      toast(on ? 'success' : 'info', on ? name + ' is saved on this device.' : name + ' was removed from your saved pets.', {
        title: on ? 'Added to favorites' : 'Removed from favorites',
        duration: 4000,
        action: { label: 'Undo', onClick: function () { setFav(id, !on); syncFavs(); } }
      });
      return;
    }
    var saved = e.target.closest('a[data-saved-link]');
    if (saved && !readFavs().length) { e.preventDefault(); toast('info', 'Tap the heart on a pet to keep it here.', { title: 'No saved pets yet' }); }
  });
  window.addEventListener('storage', function (e) { if (e.key === KEY) syncFavs(); });
  window.addEventListener('pageshow', syncFavs);
  syncFavs();

  /* ---------------------------------------------------------------
     FAB: a disclosure button. Esc and outside click close it, focus leaving closes it.
     --------------------------------------------------------------- */
  document.querySelectorAll('[data-fab]').forEach(function (fab) {
    var toggle = fab.querySelector('.fab__toggle');
    function set(open, returnFocus) {
      fab.classList.toggle('is-open', open); toggle.setAttribute('aria-expanded', String(open));
      if (!open && returnFocus) toggle.focus();
    }
    toggle.addEventListener('click', function () { set(!fab.classList.contains('is-open')); });
    fab.addEventListener('keydown', function (e) { if (e.key === 'Escape' && fab.classList.contains('is-open')) { e.stopPropagation(); set(false, true); } });
    fab.addEventListener('focusout', function (e) { if (fab.classList.contains('is-open') && e.relatedTarget && !fab.contains(e.relatedTarget)) set(false); });
    fab.addEventListener('click', function (e) {
      if (e.target.closest('[data-fab-close]')) set(false);
      var link = e.target.closest('.fab__link'); if (link && link.getAttribute('href').charAt(0) === '#') set(false);   // in-page jump (e.g. the inquiry form)
    });
  });

  /* ---------------------------------------------------------------
     Live validation. Opt in with <form data-validate>.
     Floating fields (.field) get a check or alert icon; plain <label><input></label> pairs get an inline message.
     --------------------------------------------------------------- */
  var uid = 0;
  function labelText(ctl) {
    var f = ctl.closest('.field'), l = f ? f.querySelector('.field__label') : ctl.closest('label');
    if (!l) return 'this field';
    var t = ''; Array.prototype.forEach.call(l.childNodes, function (n) { if (n.nodeType === 3) t += n.nodeValue; else if (n.nodeType === 1 && !/^(INPUT|TEXTAREA|SELECT|SPAN|SVG|BUTTON)$/i.test(n.tagName)) t += n.textContent; });
    return (t.trim() || 'this field').replace(/\s*\*$/, '');
  }
  function messageFor(ctl) {
    var name = ctl.getAttribute('data-label') || labelText(ctl), lower = name.charAt(0).toLowerCase() + name.slice(1), v = ctl.validity;
    if (v.valueMissing) return ctl.type === 'checkbox' ? 'Tick this box to continue.' : name.length <= 28 ? name + ' is required.' : 'This field is required.';
    if (v.typeMismatch) return ctl.type === 'email' ? 'Enter an email like name@example.com.' : name.length <= 28 ? 'Enter a valid ' + lower + '.' : 'Check the format of this field.';
    if (v.tooShort) return 'Use at least ' + ctl.minLength + ' characters (you have ' + ctl.value.length + ').';
    if (v.tooLong) return 'Use at most ' + ctl.maxLength + ' characters.';
    if (v.patternMismatch) return ctl.getAttribute('data-error') || ctl.title || (name.length <= 28 ? 'Check the format of your ' + lower + '.' : 'Check the format of this field.');
    if (v.rangeUnderflow || v.rangeOverflow) return 'Pick a value between ' + ctl.min + ' and ' + ctl.max + '.';
    return ctl.validationMessage || 'Check this field.';
  }
  function holder(ctl) { return ctl.closest('.field') || ctl.closest('label') || ctl.parentNode; }
  function msgBox(ctl) {
    var h = holder(ctl), box = h.querySelector('.field__msg, .field-msg');
    if (!box) { box = el('p', h.classList.contains('field') ? 'field__msg' : 'field-msg'); box.id = 'msg' + (++uid); h.appendChild(box); }
    if (!box.id) box.id = 'msg' + (++uid);
    var d = (ctl.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean); if (d.indexOf(box.id) === -1) { d.push(box.id); ctl.setAttribute('aria-describedby', d.join(' ')); }
    return box;
  }
  function shake(node) { if (reduced.matches) return; node.classList.remove('is-shaking'); void node.offsetWidth; node.classList.add('is-shaking'); node.addEventListener('animationend', function () { node.classList.remove('is-shaking'); }, { once: true }); }
  function showState(ctl, withShake) {
    var h = holder(ctl), box = msgBox(ctl), ok = ctl.checkValidity();
    ctl.setAttribute('aria-invalid', ok ? 'false' : 'true');
    box.textContent = '';
    if (!ok) { h.setAttribute('data-state', 'invalid'); box.appendChild(el('span', '', messageFor(ctl))); if (withShake) shake(h); return; }
    var filled = ctl.type === 'checkbox' || ctl.type === 'radio' ? ctl.checked : ctl.value !== '';
    if (filled) h.setAttribute('data-state', 'valid'); else h.removeAttribute('data-state');   // an empty optional field shows nothing
  }
  function decorate(ctl) {      // add the check / alert icons to floating fields once
    var f = ctl.closest('.field'); if (!f || f.querySelector('.field__status')) return;
    var s = el('span', 'field__status'); s.setAttribute('aria-hidden', 'true');
    var ok = el('span', 'field__icon field__icon--ok'); ok.appendChild(svgIcon(PATHS.check));
    var bad = el('span', 'field__icon field__icon--bad'); bad.appendChild(svgIcon('<line x1="12" x2="12" y1="7" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/>'));
    s.appendChild(ok); s.appendChild(bad); f.appendChild(s);
  }
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.noValidate = true;     // we show our own, friendlier messages; the server still validates everything
    var controls = Array.prototype.filter.call(form.elements, function (c) { return /^(INPUT|TEXTAREA|SELECT)$/.test(c.tagName) && !/^(hidden|submit|button|file)$/.test(c.type); });
    controls.forEach(function (c) {
      decorate(c); var touched = false;
      c.addEventListener('blur', function () { if (c.value !== '' || touched) { touched = true; showState(c, false); } });
      c.addEventListener('input', function () {
        if (touched || c.getAttribute('aria-invalid') === 'true') showState(c, false);
        if (form.dataset.match) { var n = form.dataset.match.split(','), other = form.elements[n[1]]; if (other && other !== c && other.value) showState(other, false); }   // password vs confirm
      });
      c.addEventListener('change', function () { touched = true; showState(c, false); });
    });
    form.addEventListener('submit', function (e) {
      var bad = controls.filter(function (c) { return !c.checkValidity(); });
      if (!bad.length) return;
      e.preventDefault(); e.stopImmediatePropagation();
      bad.forEach(function (c) { showState(c, true); });
      bad[0].focus();
      toast('error', bad.length === 1 ? 'Fix the highlighted field to continue.' : 'Fix the ' + bad.length + ' highlighted fields to continue.', { title: 'Almost there', duration: 5000 });
    });
  });

  /* ---------------------------------------------------------------
     Drawer: the pets filter form becomes a slide-out panel on small screens.
     Markup: <button class="drawer-trigger" data-drawer-open="#id" aria-expanded="false" aria-controls="id">
             <form id="id" class="filters drawer">…<button data-drawer-close>…</button></form>   <div class="drawer-backdrop" data-drawer-close>
     --------------------------------------------------------------- */
  var mq = window.matchMedia ? window.matchMedia('(max-width: 860px)') : { matches: false };
  document.querySelectorAll('[data-drawer-open]').forEach(function (trigger) {
    var drawer = document.querySelector(trigger.getAttribute('data-drawer-open')); if (!drawer) return;
    var backdrop = document.querySelector('[data-drawer-backdrop="#' + drawer.id + '"]');
    function isOpen() { return drawer.classList.contains('is-open'); }
    function open() {
      drawer.classList.add('is-open'); if (backdrop) backdrop.classList.add('is-open'); document.body.classList.add('no-scroll');
      trigger.setAttribute('aria-expanded', 'true'); drawer.setAttribute('role', 'dialog'); drawer.setAttribute('aria-modal', 'true');
      var first = drawer.querySelector('input:not([type=hidden]),select,textarea') || drawer; setTimeout(function () { first.focus(); }, reduced.matches ? 0 : 60);
    }
    function close(restore) {
      drawer.classList.remove('is-open'); if (backdrop) backdrop.classList.remove('is-open'); document.body.classList.remove('no-scroll');
      trigger.setAttribute('aria-expanded', 'false'); drawer.removeAttribute('role'); drawer.removeAttribute('aria-modal');
      if (restore) trigger.focus();
    }
    trigger.addEventListener('click', function () { isOpen() ? close(true) : open(); });
    document.addEventListener('click', function (e) { if (isOpen() && e.target.closest('[data-drawer-close]') && (drawer.contains(e.target) || e.target === backdrop)) close(true); });
    drawer.addEventListener('keydown', function (e) { if (e.key === 'Escape') { e.stopPropagation(); close(true); } else if (isOpen()) trapTab(e, drawer); });
    drawer.setAttribute('tabindex', '-1');
    var leave = function () { if (!mq.matches && isOpen()) close(false); };
    if (mq.addEventListener) mq.addEventListener('change', leave); else if (mq.addListener) mq.addListener(leave);
    window.addEventListener('pageshow', function (e) { if (e.persisted && isOpen()) close(false); });   // back button: never return to an open drawer
  });

  /* ---------------------------------------------------------------
     Confirm dialog (replaces window.confirm). pawsConfirm(message, {title, ok, danger}) -> Promise<boolean>
     app.js routes every [data-confirm] button through it.
     --------------------------------------------------------------- */
  var dlg = null;
  function buildDialog() {
    var d = el('dialog', 'modal'); d.setAttribute('aria-labelledby', 'confirmTitle'); d.setAttribute('aria-describedby', 'confirmText');
    var body = el('div', 'modal__body');
    var h = el('h2', 'modal__title'); h.id = 'confirmTitle';
    var p = el('p', 'modal__text'); p.id = 'confirmText';
    var row = el('div', 'modal__actions');
    var no = el('button', 'btn btn-ghost', 'Cancel'); no.type = 'button'; no.setAttribute('data-act', 'no');
    var yes = el('button', 'btn', 'Confirm'); yes.type = 'button'; yes.setAttribute('data-act', 'yes');
    row.appendChild(no); row.appendChild(yes); body.appendChild(h); body.appendChild(p); body.appendChild(row); d.appendChild(body); document.body.appendChild(d);
    return d;
  }
  window.pawsConfirm = function (message, opts) {
    opts = opts || {};
    if (!window.HTMLDialogElement || typeof HTMLDialogElement.prototype.showModal !== 'function') return Promise.resolve(window.confirm(message));
    dlg = dlg || buildDialog();
    return new Promise(function (resolve) {
      var d = dlg, title = d.querySelector('.modal__title'), text = d.querySelector('.modal__text'), yes = d.querySelector('[data-act=yes]'), no = d.querySelector('[data-act=no]');
      title.textContent = opts.title || (opts.danger ? 'This cannot be undone' : 'Please confirm'); text.textContent = message;
      yes.textContent = opts.ok || (opts.danger ? 'Yes, continue' : 'Confirm'); yes.className = 'btn ' + (opts.danger ? 'btn-danger-solid' : '');
      var settled = false;
      function finish(result) {
        if (settled) return; settled = true;
        d.removeEventListener('click', onClick); d.removeEventListener('cancel', onCancel); d.removeEventListener('keydown', onKey);
        var shut = function () { d.classList.remove('is-closing'); if (d.open) d.close(); resolve(result); };
        if (reduced.matches) shut(); else { d.classList.add('is-closing'); d.addEventListener('animationend', function h(ev) { if (ev.target !== d) return; d.removeEventListener('animationend', h); shut(); }); setTimeout(function () { if (d.open) shut(); }, 400); }
      }
      function onClick(e) { var b = e.target.closest('[data-act]'); if (b) finish(b.dataset.act === 'yes'); else if (e.target === d) finish(false); }
      function onCancel(e) { e.preventDefault(); finish(false); }
      function onKey(e) { trapTab(e, d); }
      d.addEventListener('click', onClick); d.addEventListener('cancel', onCancel); d.addEventListener('keydown', onKey);
      d.showModal(); no.focus();          // destructive actions never start focused
    });
  };

  /* ---------------------------------------------------------------
     Skeletons: while a filter search or a pager link is loading, the results swap to shimmer cards of the same shape.
     Markup: <div id="petResults" data-skeleton="grid"> … </div>; the form needs data-skeleton-for="#petResults".
     --------------------------------------------------------------- */
  function skeletonCard() {
    var c = el('div', 'card pet-card sk-card'); c.appendChild(el('div', 'sk-block'));
    var b = el('div', 'card-body'); b.appendChild(el('span', 'sk-line title')); b.appendChild(el('span', 'sk-line w-70')); b.appendChild(el('span', 'sk-line w-50')); c.appendChild(b); return c;
  }
  function skeletonProfile() {
    var w = el('div', 'sk-profile'); w.appendChild(el('span', 'sk-circle lg'));
    var s = el('div', 'sk-stack'); s.appendChild(el('span', 'sk-line title')); s.appendChild(el('span', 'sk-line w-50')); s.appendChild(el('span', 'sk-line w-70')); w.appendChild(s); return w;
  }
  function skeletonChat() {
    var w = el('div', 'sk-chat'); ['', 'me', '', 'me'].forEach(function (k) { w.appendChild(el('span', 'sk-block' + (k ? ' ' + k : ''))); }); return w;
  }
  var swapped = [];
  function showSkeleton(box) {
    if (!box || box.getAttribute('aria-busy') === 'true') return;
    var kind = box.getAttribute('data-skeleton') || 'grid', count = Math.min(12, Math.max(6, box.querySelectorAll('.pet-card').length || 6));
    swapped.push({ box: box, html: box.innerHTML });
    box.setAttribute('aria-busy', 'true'); box.textContent = '';
    var live = el('span', 'sr-only skeleton-live', 'Loading'); box.appendChild(live);
    if (kind === 'profile') box.appendChild(skeletonProfile());
    else if (kind === 'chat') box.appendChild(skeletonChat());
    else { var g = el('div', 'grid'); for (var i = 0; i < count; i++) g.appendChild(skeletonCard()); box.appendChild(g); }
  }
  window.pawsSkeleton = { show: showSkeleton };
  function afterDelay(box) { var t = setTimeout(function () { showSkeleton(box); }, 120); window.addEventListener('pagehide', function () { clearTimeout(t); }, { once: true }); }
  document.addEventListener('submit', function (e) {
    var f = e.target, sel = f.getAttribute && f.getAttribute('data-skeleton-for'); if (!sel) return;
    setTimeout(function () { if (!e.defaultPrevented) afterDelay(document.querySelector(sel)); }, 0);
  });
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-skeleton] .pager a[href]'); if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target && a.target !== '_self') return;
    afterDelay(a.closest('[data-skeleton]'));
  });
  window.addEventListener('pageshow', function (e) {      // back button (bfcache): put the real content back
    if (!e.persisted) return;
    while (swapped.length) { var s = swapped.pop(); s.box.innerHTML = s.html; s.box.removeAttribute('aria-busy'); }
    syncFavs();
  });
})();

/* =====================================================================
   Theme (light / dark)   v10
   ---------------------------------------------------------------------
   theme-init.js has already put data-theme on <html> before first paint; this module only
   handles the toggle, persistence and live updates.
     pawsTheme.get()            -> "light" | "dark"   (the theme in effect)
     pawsTheme.set("dark")      -> force + remember;  set("system") -> forget, follow the OS
     pawsTheme.toggle()
   Fires a "pawstheme" event on document ({detail:{theme, source}}) for anything that must redraw.
   ===================================================================== */
(function () {
  'use strict';
  var KEY = 'pawsTheme', root = document.documentElement;
  var COLORS = { light: '#ffffff', dark: '#0a0f1e' };
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  var reduce = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };

  function stored() { try { var v = localStorage.getItem(KEY); return v === 'light' || v === 'dark' ? v : null; } catch (err) { return null; } }
  function system() { return mq && mq.matches ? 'dark' : 'light'; }
  function current() { return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }

  function paint(theme) {          // the only place that touches the DOM
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = theme;
    var meta = document.getElementById('themeColorMeta'); if (meta) meta.setAttribute('content', COLORS[theme]);
    Array.prototype.forEach.call(document.querySelectorAll('[data-theme-toggle]'), function (b) {
      b.setAttribute('aria-checked', theme === 'dark' ? 'true' : 'false');
    });
  }
  function apply(theme, source) {
    if (theme === current() && source !== 'init') return;
    var done = function () { paint(theme); document.dispatchEvent(new CustomEvent('pawstheme', { detail: { theme: theme, source: source } })); };
    if (source !== 'init' && document.startViewTransition && !reduce.matches) {
      root.classList.add('theme-switching');                    // before the snapshot: header/FAB join the cross-fade
      try {
        var vt = document.startViewTransition(done);
        var clear = function () { root.classList.remove('theme-switching'); };
        vt.finished.then(clear, clear);
        return;
      } catch (err) { root.classList.remove('theme-switching'); }
    }
    done();
  }
  function set(mode) {
    if (mode === 'system') { try { localStorage.removeItem(KEY); } catch (err) {} apply(system(), 'user'); return; }
    if (mode !== 'light' && mode !== 'dark') return;
    try { localStorage.setItem(KEY, mode); } catch (err) {}
    apply(mode, 'user');
  }
  window.pawsTheme = { get: current, set: set, toggle: function () { set(current() === 'dark' ? 'light' : 'dark'); } };

  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-theme-toggle]')) window.pawsTheme.toggle();
  });
  // follow the OS only while the person has not chosen
  var onSystem = function () { if (!stored()) apply(system(), 'system'); };
  if (mq) { if (mq.addEventListener) mq.addEventListener('change', onSystem); else if (mq.addListener) mq.addListener(onSystem); }
  // another tab changed it
  window.addEventListener('storage', function (e) { if (e.key === KEY) apply(stored() || system(), 'storage'); });
  // back/forward cache restore
  window.addEventListener('pageshow', function (e) { if (e.persisted) paint(stored() || system()); });

  paint(current());                // sync aria-checked + theme-color with what theme-init chose
})();
