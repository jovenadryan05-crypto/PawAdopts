/* PawsAdopt theme bootstrap. Loaded synchronously in <head>, BEFORE the stylesheet, so the right
   theme is on <html> before the first paint (no flash). It is an external file because the
   Content-Security-Policy forbids inline scripts. Keep it tiny and dependency-free.
   Storage key: pawsTheme = "light" | "dark". No key = follow the operating system. */
(function () {
  var root = document.documentElement, theme = 'light';
  try {
    var saved = localStorage.getItem('pawsTheme');
    if (saved === 'light' || saved === 'dark') theme = saved;
    else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) theme = 'dark';
  } catch (err) {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) theme = 'dark';
  }
  root.setAttribute('data-theme', theme);
  root.style.colorScheme = theme;   // native controls + scrollbars match before CSS arrives
})();
