(function () {
  'use strict';

  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle'), nav = document.getElementById('nav');
  function setNav(open) { nav.classList.toggle('open', open); toggle.setAttribute('aria-expanded', String(open)); }
  if (toggle && nav) {
    toggle.addEventListener('click', function () { setNav(!nav.classList.contains('open')); });
    document.addEventListener('keydown', function (e) {                       // Esc closes the menu and returns focus to the toggle
      if (e.key === 'Escape' && nav.classList.contains('open')) { setNav(false); toggle.focus(); }
    });
    document.addEventListener('click', function (e) {                         // click outside closes it
      if (nav.classList.contains('open') && !nav.contains(e.target) && !toggle.contains(e.target)) setNav(false);
    });
  }

  // Lucide icons used by script-built controls (same set as includes/icons.php)
  var ICON = {
    eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>'
  };
  function svg(name) { return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + ICON[name] + '</svg>'; }

  // Confirm dialogs: <button data-confirm="Are you sure?">
  // v9: asks with the styled dialog from ui.js (window.pawsConfirm); falls back to the browser prompt if ui.js did not load.
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-confirm]');
    if (!el) return;
    if (el.getAttribute('data-confirmed') === '1') { el.removeAttribute('data-confirmed'); return; }       // second pass: already approved
    if (window.pawsConfirm) {
      e.preventDefault();
      window.pawsConfirm(el.getAttribute('data-confirm'), { danger: el.classList.contains('btn-danger') }).then(function (ok) {
        if (ok) { el.setAttribute('data-confirmed', '1'); el.click(); }
      });
      return;
    }
    if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
  });

  // Pet gallery: click a thumbnail to swap the main photo
  var main = document.getElementById('mainPhoto');
  document.querySelectorAll('.thumbs .t').forEach(function (t) {
    t.addEventListener('click', function () {
      if (main) { var swap = function () { main.src = t.dataset.src; }; if (window.pawsTransition) window.pawsTransition(swap); else swap(); }   // v9: crossfade where View Transitions exist
      document.querySelectorAll('.thumbs .t').forEach(function (o) { o.classList.remove('on'); });
      t.classList.add('on');
    });
  });

  // Password match check: <form data-match="password,confirm">
  document.querySelectorAll('form[data-match]').forEach(function (form) {
    var names = form.dataset.match.split(','), a = form.elements[names[0]], b = form.elements[names[1]];
    if (!a || !b) return;
    function check() { b.setCustomValidity(a.value && b.value && a.value !== b.value ? 'Passwords do not match.' : ''); }
    a.addEventListener('input', check); b.addEventListener('input', check);
  });

  // Image previews before upload: <input type="file" data-preview="#box">
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      var box = document.querySelector(input.dataset.preview);
      if (!box) return;
      box.innerHTML = '';
      Array.prototype.forEach.call(input.files, function (file) {
        if (file.size > 5 * 1024 * 1024) { alert(file.name + ' is over 5 MB and will be rejected.'); return; }
        var img = document.createElement('img'); img.alt = file.name; img.src = URL.createObjectURL(file); box.appendChild(img);
      });
    });
  });

  // Donation posts show the target amount field
  var type = document.getElementById('postType'), amount = document.getElementById('amountField');
  if (type && amount) {
    var sync = function () {
      var donation = type.value === 'donation';
      amount.hidden = !donation;
      amount.querySelector('input').required = donation;
    };
    type.addEventListener('change', sync); sync();
  }

  // PH mobile inputs: digits only, max 11 (09XXXXXXXXX)
  document.querySelectorAll('input[data-ph]').forEach(function (input) {
    input.addEventListener('input', function () { input.value = input.value.replace(/\D/g, '').slice(0, 11); });
  });


  // Show / hide password: every password field gets an optional "Show" button (hidden by default)
  document.querySelectorAll('input[type=password]').forEach(function (input) {
    var wrap = document.createElement('span'); wrap.className = 'pw-wrap';
    input.parentNode.insertBefore(wrap, input); wrap.appendChild(input);
    var b = document.createElement('button'); b.type = 'button'; b.className = 'pw-toggle';
    b.innerHTML = svg('eye'); b.setAttribute('aria-label', 'Show password'); b.setAttribute('aria-pressed', 'false');
    wrap.appendChild(b);
    b.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      b.innerHTML = svg(show ? 'eyeOff' : 'eye'); b.setAttribute('aria-pressed', String(show)); b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });
  window.addEventListener('pageshow', function (e) {          // coming back with the browser's back button: hide passwords again
    if (!e.persisted) return;
    document.querySelectorAll('.pw-wrap').forEach(function (w) { var i = w.querySelector('input'), b = w.querySelector('button'); if (i) i.type = 'password'; if (b) { b.innerHTML = svg('eye'); b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', 'Show password'); } });
  });

  // Name fields accept letters only (plus space, hyphen, apostrophe, period): other characters are removed as you type
  var nameBad; try { nameBad = new RegExp("[^\\p{L}\\s'.\\-]", 'gu'); } catch (err) { nameBad = /[0-9_!@#$%^&*()+=\[\]{};:"\\|,<>\/?~`]/g; }
  document.querySelectorAll('input[data-name]').forEach(function (input) {
    input.addEventListener('input', function () { var v = input.value.replace(nameBad, ''); if (v !== input.value) input.value = v; });
  });

  // CAPTCHA: "New image" asks the server for a fresh challenge and reloads the picture without losing what was typed
  document.querySelectorAll('[data-captcha-refresh]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var img = document.getElementById('captchaImg'); if (!img) return;
      img.src = btn.dataset.captchaRefresh + '?new=1&t=' + Date.now();
      var box = btn.parentNode.querySelector('input[name=captcha]'); if (box) { box.value = ''; box.focus(); }
    });
  });

  // Double-submit guard: after a valid submit, disable the buttons so a double-click cannot send the form twice
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      setTimeout(function () { if (e.defaultPrevented) return; form.querySelectorAll('button:not([type=button])').forEach(function (b) { b.disabled = true; }); }, 0);
    });
  });
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('form button:disabled').forEach(function (b) { b.disabled = false; });
  });

  // Character counters on limited textareas
  document.querySelectorAll('textarea[maxlength]').forEach(function (t) {
    var c = document.createElement('span'); c.className = 'hint'; t.parentNode.appendChild(c);
    var update = function () { c.textContent = t.value.length + ' / ' + t.maxLength; };
    t.addEventListener('input', update); update();
  });

  // Page-transition loader: a thin progress bar appears only if a click/submit is still loading after 120ms (fast pages never flash it).
  // It never delays navigation, and it is static (no motion) when the visitor prefers reduced motion (see the CSS).
  var loader = document.getElementById('pageLoader'), loaderTimer = null, loaderMax = null;
  function hideLoader() { clearTimeout(loaderTimer); clearTimeout(loaderMax); if (loader) { loader.classList.remove('on'); loader.hidden = true; } }
  function showLoader() {
    if (!loader) return;
    clearTimeout(loaderTimer); clearTimeout(loaderMax);
    loaderTimer = setTimeout(function () { loader.hidden = false; requestAnimationFrame(function () { loader.classList.add('on'); }); }, 120);
    loaderMax = setTimeout(hideLoader, 10000);                 // safety net, e.g. a download that never navigates
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if ((a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('data-no-loader')) return;
    var u; try { u = new URL(a.href, location.href); } catch (err) { return; }
    if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search && u.hash)) return;
    showLoader();
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-no-loader') || f.target === '_blank') return;
    setTimeout(function () { if (!e.defaultPrevented) showLoader(); }, 0);
  });
  window.addEventListener('pageshow', hideLoader);

  // Notification bell badge
  window.pawsSetNotif = function (n) {
    document.querySelectorAll('[data-notif]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
  };

  // Unread-message badge in the navigation: refreshed every 30s while the tab is visible (also updated by chat.js)
  window.pawsSetUnread = function (n) {
    document.querySelectorAll('[data-unread]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
  };
  var unreadUrl = document.body.dataset.unreadUrl;
  if (unreadUrl && window.fetch) {
    setInterval(function () {
      if (document.hidden) return;
      fetch(unreadUrl, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) { if (d && d.ok) { window.pawsSetUnread(d.unread); if (typeof d.notifications !== 'undefined') window.pawsSetNotif(d.notifications); } })
        .catch(function () {});
    }, 30000);
  }

  // Login popup + chime (includes/login_popup.php). The sound plays right away when the browser allows it; browsers that block
  // sound before the first tap or key press (Safari, some Chrome settings) play it on that first interaction instead.
  var popup = document.getElementById('loginPopup');
  if (popup) {
    var soundSrc = popup.dataset.sound, muted = false, played = false, chime = null, waiting = false;
    try { muted = localStorage.getItem('pawsSoundOff') === '1'; } catch (err) {}
    var muteBtn = popup.querySelector('[data-sound-toggle]');
    var syncMute = function () { if (muteBtn) { muteBtn.textContent = muted ? 'Sound off' : 'Sound on'; muteBtn.setAttribute('aria-pressed', String(!muted)); } };
    var waitForGesture = function () {
      if (waiting) return; waiting = true;
      var go = function () { waiting = false; document.removeEventListener('pointerdown', go, true); document.removeEventListener('keydown', go, true); playChime(); };
      document.addEventListener('pointerdown', go, true); document.addEventListener('keydown', go, true);
    };
    var playChime = function () {
      if (muted || played || !soundSrc || !window.Audio) return;
      try {
        chime = chime || new Audio(soundSrc); chime.volume = 0.7;
        var pr = chime.play();
        if (pr && pr.then) pr.then(function () { played = true; }, waitForGesture); else played = true;
      } catch (err) {}
    };
    var closePopup = function () { if (popup.close) popup.close(); else popup.removeAttribute('open'); };
    popup.addEventListener('click', function (e) {
      if (e.target.closest('[data-popup-close]') || e.target === popup) closePopup();    // the Continue button, or a click on the dim backdrop
    });
    if (muteBtn) muteBtn.addEventListener('click', function () {
      muted = !muted;
      try { localStorage.setItem('pawsSoundOff', muted ? '1' : '0'); } catch (err) {}
      if (muted && chime) chime.pause(); else { played = false; playChime(); }
      syncMute();
    });
    syncMute();
    if (popup.showModal) popup.showModal(); else popup.setAttribute('open', '');
    playChime();
  }

  // Shelter map pin: "use my location", paste coordinates or a Google Maps / OpenStreetMap link, and a live preview
  document.querySelectorAll('[data-pin-field]').forEach(function (box) {
    var input = box.querySelector('[data-pin-input]'), btn = box.querySelector('[data-geo]'), status = box.querySelector('[data-geo-status]'), frame = box.querySelector('[data-pin-preview]');
    var n = '(-?\\d{1,3}(?:\\.\\d+)?)';
    var patterns = [new RegExp('^\\s*' + n + '\\s*[,;\\s]\\s*' + n + '\\s*$'), new RegExp('!3d' + n + '!4d' + n), new RegExp('@' + n + ',' + n),
      new RegExp('[?&](?:q|ll|query|center)=' + n + ',\\s*' + n), new RegExp('#map=\\d{1,2}/' + n + '/' + n), new RegExp('mlat=' + n + '&(?:amp;)?mlon=' + n)];
    function parse(raw) {
      var s = raw.trim(); try { s = decodeURIComponent(s); } catch (err) {}
      for (var i = 0; i < patterns.length; i++) {
        var m = patterns[i].exec(s);
        if (m) { var la = parseFloat(m[1]), lo = parseFloat(m[2]); return (la >= 4.5 && la <= 21.5 && lo >= 116 && lo <= 127) ? [la, lo] : null; }
      }
      return null;
    }
    function preview() {
      if (!frame || !input) return;
      var c = parse(input.value);
      input.setCustomValidity(input.value.trim() && !c ? 'Enter latitude, longitude inside the Philippines (e.g. 14.5995, 120.9842) or a full Google Maps link.' : '');
      if (c) { var src = 'https://maps.google.com/maps?q=' + c[0] + ',' + c[1] + '&z=18&output=embed'; if (frame.getAttribute('src') !== src) frame.setAttribute('src', src); frame.hidden = false; }
      else { frame.hidden = true; frame.removeAttribute('src'); }
    }
    var timer = null;
    if (input) input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(preview, 500); });
    if (btn) btn.addEventListener('click', function () {
      if (!navigator.geolocation) { status.textContent = 'Your browser cannot share its location. Paste the coordinates instead.'; return; }
      status.textContent = 'Finding your location...'; btn.disabled = true;
      navigator.geolocation.getCurrentPosition(function (pos) {
        btn.disabled = false;
        var la = pos.coords.latitude, lo = pos.coords.longitude, acc = Math.round(pos.coords.accuracy);
        if (!(la >= 4.5 && la <= 21.5 && lo >= 116 && lo <= 127)) { status.textContent = 'That location is outside the Philippines. Paste the shelter coordinates instead.'; return; }
        input.value = la.toFixed(6) + ', ' + lo.toFixed(6); preview();
        status.textContent = acc <= 50 ? 'Pin set (accurate to about ' + acc + ' m).' : 'Pin set, but only accurate to about ' + acc + ' m. For a better pin, go outdoors or use a phone, then try again.';
      }, function (err) {
        btn.disabled = false;
        status.textContent = err.code === 1 ? 'Location permission was denied. Allow it in your browser, or paste the coordinates.' : 'Could not get your location. Paste the coordinates instead.';
      }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    });
    preview();
  });

  // Success flashes fade after a few seconds
  document.querySelectorAll('.flash-success').forEach(function (f) {
    setTimeout(function () { f.classList.add('is-leaving'); setTimeout(function () { f.remove(); }, 450); }, 5000);   // opacity + transform only
  });
})();
